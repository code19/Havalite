<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Havalite CMS - live update</title>
</head>
<style>
#submit{ display:block; width:100%; border:1px solid #999; padding:7px 4%; text-align:center; -webkit-border-radius: 9px;
	-moz-border-radius: 9px; border-radius: 9px; background-color:#CCCCCC; font-size:18px; cursor:pointer;
}

</style>
<body>
<div id="top">
<form id="form1" name="form1" method="post" action="updater.php">
  <input type="hidden" name="update" value="ok" />
  <input type="submit" name="Submit" id="submit" value="Click here to Start your update now!" title="Start updatibg!" />
</form>
</div>

<?php

function copyfile($file, $newfile){
	$res = false;
	// create a new CURL resource
	$ch = curl_init();
	
	// set URL and other appropriate options
	curl_setopt($ch, CURLOPT_URL, $file);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	
	if(!ini_get('safe_mode') ){
		set_time_limit(120); # 2 minutes for PHP
	} 

	curl_setopt($ch, CURLOPT_TIMEOUT, 300); # and also for CURL
	
	$outfile = fopen($newfile, 'wb');
	curl_setopt($ch, CURLOPT_FILE, $outfile);
	
	// grab file from URL
	if(curl_exec($ch)) $res = true;
	fclose($outfile);
	
	// close CURL resource, and free up system resources
	curl_close($ch); 
	
	return $res;
}

function startUpdating(){
	$newfile = 'havaliteUpdate.zip';
	$file = 'http://havalite.com/downloads/'.$newfile;
	$extractfolder = '../../';
	
	if (!copyfile($file, $newfile)) {
		echo '<div style="color:#ff0000">Error: Failed to copy <a href="'.$file.'">'.$file.'</a><br>Please, download and update files by your self!</div>';
	}
	else{
		echo '<div style="color:#00CC00;">Copy: '.$newfile.' ..... done!</div>';
	
		if(class_exists('ZipArchive')){
			$zip = new ZipArchive;
			if ($zip->open($newfile) === TRUE) {
				$zip->extractTo($extractfolder);
				$zip->close();
				echo '<div style="color:#00CC00;">Update havalite system ..... done!</div><div>Refresh your havalite system to see changes!</div><p>&nbsp;</p><div>Thank you for using <a href="http://havalite.com">Havalite CMS</a></div>';
			} 
			else{
				echo '<div style="color:#ff0000">Error: I have no rights to exchange file!</div>';
			}
		}
		else echo '<div style="color:#ff0000">Sorry, but your system has NO support for ZIP files</div>';
	
	}
}

if(isset($_POST['update'])) echo startUpdating();
?>
</body>
</html>
