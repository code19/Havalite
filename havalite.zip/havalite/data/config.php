<?php

$db_path = 'havalite.db3';	// Database name
$db_sub = '';	// Add multiple databases which fit to your subdomain. E.g.: $db_sub = 'de=havalite_de.db3,fr=havalite_fr.db3, ar=havalite_ar.db3';
$activeHavalite = true;		// De- or Activate Havalite CMS


$dbPath = hava_dbpath();



/*******************************************************/
/********** *********************************/
// check if domain has a subdomain
function subdomain(){
	$domain = strtolower($_SERVER['SERVER_NAME']);
	$just_domain = preg_replace("/^(.*\.)?([^.]*\..*)$/", "$2", $_SERVER['HTTP_HOST']);
	$position = strrpos($domain, '.'.$just_domain);
	$subdomain = substr($domain, 0, $position);
	if($subdomain == "www") $subdomain = "";

	return trim($subdomain);
}

function hava_dbpath(){
	global $db_path, $db_sub;
	$sub = subdomain();
	$res = '';
	
	if(!empty($db_sub) and !empty($sub)){
		$sdb = preg_split('/,/', $db_sub); //echo $db_sub;
		for($i=0; $i<count($sdb); $i++){
			$sd = preg_split('/=/', $sdb[$i]);
			if($sub == trim($sd[0])){ 
				$res = trim($sd[1]);  
				break; 
			}
		}
	}
	else $res = $db_path;
	
	return $res;
}



?>