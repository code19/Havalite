<?php
require('config.php');

function getCurrentUrl(){
	$protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']),'https') === FALSE ? 'http' : 'https';
	$host     = $_SERVER['HTTP_HOST'];
	$script   = $_SERVER['SCRIPT_NAME'];
	$params   = $_SERVER['QUERY_STRING'];
	$currentUrl = $protocol . '://' . $host . $script . '?' . $params;
	$currentUrl = preg_replace('/\/havalite\/data\/.*/', '', $currentUrl);
	return $currentUrl;
}

if (isset($_GET['lang'])){ 
	$currLang = $_GET['lang'];
	saveData("UPDATE options SET val =? WHERE opt=?", array($currLang, 'language'));
}
else { $currLang = hava_current_lang(); }

require('../sys/languages/'.$currLang.'.php');

$win =  '/';
if(isset($_POST['user'])) $user = $_POST['user']; 
if(isset($_POST['passwd'])) $passwd 	= $_POST['passwd']; 
if(isset($_POST['passwd2'])) $passwd2 	= $_POST['passwd2']; 
if(isset($_POST['server'])){
	$server = $_POST['server']; // win or linux server
	if($server == '1') $win = '\\';
}
if(isset($_POST['email'])) $email = trim($_POST['email']);
if(isset($_POST['url'])) $url = checkUrl(trim($_POST['url']));
else $url = getCurrentUrl();

$dateNow 	= date("y-m-d H:i:s");
$authName 	= $hava_lang['hello']; 
$passwdFolder = dirname(__FILE__); 


$msg = '<p>'.$hava_lang['msg'].'<p>';

function checkUrl($url){
	if(empty($url)){ return NULL; }
	else{
		if (!preg_match('/http[s]*:\/\//', $url)) {
			$url = 'http://'.$url;
		}
		return $url;
	}
}

function make_htaccess(){
    global $user, $passwd, $authName, $passwdFolder, $win;
	$access .= 'AuthType Basic'."\n";
    $access .= 'AuthName "'.$authName . '"'."\n";
    $access .= 'AuthUserFile '.$passwdFolder .$win.'.htpasswd' . "\n";
    $access .= 'require user '.$user."\n";
    
	$accessFile = $passwdFolder.$win.".htaccess";
	
    $handle = fopen($accessFile, "w");
    fputs($handle, $access);
    fclose($handle);
}

function make_htpasswd(){
    global $user, $passwd, $authName, $passwdFolder, $win, $server;
	if($server == '2') $passwd = crypt($passwd);
    $htpasswd = $user.':'.$passwd;
    
    $handle = fopen($passwdFolder.$win.'.htpasswd', "w");
    fputs($handle, $htpasswd);
    fclose($handle);
}

function hava_current_lang(){
		global $db_path;
		$db = new PDO('sqlite:'.$db_path);
		
		$SQL = "SELECT * FROM options WHERE opt = 'language'";
		$SQL = $db->prepare($SQL);
		$SQL->execute();
		
		if($res = $SQL->fetch(PDO::FETCH_ASSOC)) return $res['val']; 
		else return false;
}

function saveData($SQL, $data = array()){
	if(isset($SQL)){
		global $db_path;
		$db = new PDO('sqlite:'.$db_path);
		$stm = $db->prepare($SQL);
		
		if($stm->execute($data)) return true;
		else return false;
	}
	else return false;
}

if(isset($user)){
	if(!$passwd) $msg = '<p id="error"><b>'.$hava_lang['err0'].': </b>'.$hava_lang['err1'].'</p>';									// Password
	elseif(strlen($passwd) < 6) $msg = '<p id="error"><b>'.$hava_lang['err0'].': </b>'.$hava_lang['err2'].'</p>';			// Password NOT less thatn  6
	elseif(!$passwd2) $msg = '<p id="error"><b>'.$hava_lang['err0'].': </b>'.$hava_lang['err3'].'</p>';								// Password2
	elseif($passwd != $passwd2) $msg = '<p id="error"><b>'.$hava_lang['err0'].': </b>'.$hava_lang['err4'].'<br>'.$hava_lang['err5'].'</p>';	// password != password2
	elseif(!$url) $msg = '<p id="error"><b>'.$hava_lang['err0'].': </b>'.$hava_lang['err6'].'</p>';				// URL
	elseif(!$email) $msg = '<p id="error"><b>'.$hava_lang['err0'].': </b>'.$hava_lang['err7'].'</p>';			// Email
	else{  
		//echo $passwdFolder.'/'.$db_path;
		if(!chmod($passwdFolder, 0755)) $msg = '<p id="error"><b>'.$hava_lang['err0'].': </b> Sorry, could NOT change mode for the folder: "<b>data</b>". You need to make it writeable by setting the mode to <b>0777</b>. Than try again here!</p>'; 
		if(!chmod($db_path, 0755)) $msg .= '<p id="error"><b>'.$hava_lang['err0'].': </b> Sorry, could NOT change mode for the database: "<b>'.$db_path.'</b>". You need to make it writeable by setting the mode to <b>0777</b>. Than try again here!</p>'; 
		if(preg_match('/\/$/', $url)) { $url = substr($url, 0, -1);	}
		$passwdmd5 = md5($passwd);
		
		if(saveData("UPDATE users SET pass = ?, email=?, website=? WHERE user = 'admin'", array($passwdmd5, $email, $url))){
			if(saveData("UPDATE options SET val=? WHERE opt='url'", array($url))){
				saveData("UPDATE options SET val=? WHERE opt='language'", array($currLang));
				saveData("UPDATE posts SET date =? WHERE id = 1", array($dateNow));
				$msg = '<p id="error">'.$hava_lang['err9'];
				
				make_htpasswd();
				make_htaccess();
				header('location: ../index.php'); 
				
			}
			else{ 
				$msg = '<p id="error"><b>'.$hava_lang['err0'].': </b> 2. '.$hava_lang['err8'].'</p>'; 
			}
		}
		else{ 
			$msg .= '<p id="error"><b>'.$hava_lang['err0'].': </b> 1. '.$hava_lang['err8'].'</p>'; 
		}
	}
}

$info = getenv("SERVER_SOFTWARE");
$info = substr($info,strpos($info,"(")+1,strpos($info,")")-(strpos($info,"(")+1));

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Havalite, a new Blog</title>
</head>
<style>
body{ font-family:Arial, Helvetica, sans-serif; margin:0px; color:#333333; }
#content{ font-size:12px; padding:10px; margin-top:100px; margin-left:-185px; position:absolute; left:50%;  }
em{ color:#666; font-size:10px; }
#user, #password, #email, #url, #but{ color:#3366CC; width:98%; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; }
input{ background-color:#fff; }
input:focus{ background-color:#EFF5D7; }
#but{ width:100%; border:1px solid #ccc; height:30px; cursor:pointer; background-color:#EFF5D7; color:#000; -webkit-box-shadow: 0px 0px 4px 0px #ccc; box-shadow: 0px 0px 4px 0px #ccc; }
#but:hover{ color:#3687C2; -webkit-box-shadow: 0px 0px 1px 0px #ccc; box-shadow: 0px 0px 1px 0px #ccc; }
#but1{ border:1px solid #ccc; cursor:pointer; background-color:#EFF5D7; color:#000; -webkit-box-shadow: 0px 0px 4px 0px #ccc; box-shadow: 0px 0px 4px 0px #ccc; }
#but1:hover{ color:#3687C2; -webkit-box-shadow: 0px 0px 1px 0px #ccc; box-shadow: 0px 0px 1px 0px #ccc; }

table{  direction:<?php echo $hava_lang['direction']; ?>;
	float:left; background: no-repeat #fff url(../sys/img/logo30.png);
	border:1px solid #ccc; padding:10px; 
}
#error{ color:res; display:block; border:1px solid red; background-color:#FFEBE8; padding:3px; }
table, img{ -webkit-box-shadow: 0px 0px 5px 0px #ccc; box-shadow: 0px 0px 5px 0px #ccc; }
img:hover{ 0px 0px 1px 0px #ccc; box-shadow: 0px 0px 1px 0px #ccc; }
#anotherLang{ color:#3687C2; font-family:Arial, Helvetica, sans-serif; font-size:10px; position:relative; }

#hideForm{ display:none; position:absolute; margin:0px; background-color:#fff; width:98%; height:80%; }
#langSelect{ 
	position:absolute; display:block; border:2px solid #666; padding:5px 40px 40px 40px; margin-top:100px; left:50%; margin-left:-190px; background:#fff;
	-webkit-box-shadow: 0px 0px 9px 0px #666; box-shadow: 0px 0px 9px 0px #666; background: no-repeat #fff url(../sys/img/logo30.png);
}

</style>

<script language="javascript" src="../sys/jquery/js/jquery-1.7.min.js"></script>
<script language="javascript">
$(document).ready( function(){
	$('#anotherLang').fadeOut(800);
	$('#anotherLangImg').hover( 
		function(){ $('#anotherLang').fadeIn(500); }, 
		function(){ $('#anotherLang').fadeOut(500); }
	);
	
	$('#langSelect').fadeOut(1);
	
	$('#anotherLangImg').click( function(){ 
		$('#hideForm').fadeIn(500); 
		$('#langSelect').fadeIn(500); 
	});
	$('.cancel').click( function(){ 
		$('#hideForm').fadeOut(500); 
		$('#langSelect').fadeOut(500); 
	});
	$('.change').click( function(){ 
		var langVal = $('#sysLang').val();
		window.location.href = 'install.php?lang=' + langVal;
	});
});
</script>
<body>
<div id="content">

<form action="install.php" method="post" name="accessform">

<table width="350" border="0" align="center" cellpadding="7" cellspacing="0">
<tr>
  <td colspan="2"><h2> <?php echo $hava_lang['welcome']; ?> </h2> <?php echo $msg; ?></td>
  
</tr>
<tr>
<td colspan="2"><h2><?php echo $hava_lang['admin']; ?></h2></td>
</tr>
<tr>
<td width="80" valign="top"><label for="user"><?php echo $hava_lang['user']; ?>:  </label></td><td valign="top"><input name="user" type="text" id="user" value="admin" size="20" readonly="readonly" style="color:#CCCCCC;" /></td>
</tr>
<tr>
<td width="80" valign="top"><label for="password"><?php echo $hava_lang['pass']; ?>: </label></td><td valign="top"><input name="passwd" type="password" id="password" size="20" value="<?php if(isset($passwd)) echo $passwd; ?>" /></td>
</tr>
<tr>
  <td valign="top"><?php echo $hava_lang['pass2']; ?>: </td>
  <td valign="top"><input name="passwd2" type="password" id="password" size="20"  value="<?php if(isset($passwd2)) echo $passwd2; ?>" /></td>
</tr>
<tr>
  <td valign="top"><?php echo $hava_lang['burl']; ?>: </td>
  <td valign="top"><input name="url" type="text" id="url" size="20"  value="<?php if(isset($url)) echo $url; ?>" /></td>
</tr>
<tr>
  <td width="80" valign="top"><?php echo $hava_lang['email']; ?>:</td>
  <td valign="top"><input name="email" type="text" id="email" size="20" value="<?php if(isset($email)) echo $email; ?>" /></td>
</tr>
<tr>
<td colspan="2"><label><strong><?php echo $hava_lang['system']; ?>:</strong> <input name="server" type="radio" value="1" <?php if(strtolower($info) == 'win32') echo 'checked="checked"'; ?> /> <?php echo $hava_lang['win']; ?> </label> <label><input name="server" type="radio" value="2" <?php if(strtolower($info) != 'win32') echo 'checked="checked"'; ?> /> <?php echo $hava_lang['linux']; ?></label>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(<?php echo $hava_lang['os']; ?>: <b><?php echo $info; ?></b>)</td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td align="right"><input id="but" type="submit" name="Submit" value="                   <?php echo $hava_lang['save']; ?>                 " /></td>
</tr>
</table>
<a href="#"><img id="anotherLangImg" src="../sys/img/logo31.png" alt="language" border="0" /></a>
<span id="anotherLang">Choose another language</span>
</form>
</div>

<div id="hideForm">&nbsp;</div>
<div id="langSelect">
<h2>Choose another language</h2>
<select name="sysLang" id="sysLang" onChange="colorize('sysLang');">
<?php
$langFolder = '../sys/languages/';

require_once($langFolder.'langList.php');

foreach($lang_list as $key => $value){
	if(file_exists($langFolder.$key.'.php')){
		$selOpt = '';
		if($key == $currLang) $selOpt = ' selected="selected"'; 
		echo '<option value="'.$key.'"'.$selOpt.'>'.$value.'</option>';
	}
}

?>
</select> <input type="submit" value=" Change " id="but1" class="change" /> <input type="submit" value=" Cancel " id="but1" class="cancel" />
</div>
</body>
</html>
