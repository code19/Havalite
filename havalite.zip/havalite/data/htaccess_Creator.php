<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>.htaccess creation</title>
</head>
<style>
body{ font-family:Arial, Helvetica, sans-serif; margin:0px; color:#333333; }
#content{ font-size:12px; padding:10px; }
em{ color:#666; font-size:10px; }
</style>
<body>
<div id="content">

<?php

$win =  '/';

if(isset($_POST['user'])) $user = $_POST['user']; // Den Benutzernamen für den Login
if(isset($_POST['password'])) $passwd = $_POST['password']; // Das Passwort für den Login
if(isset($_POST['authtext'])) $authName = $_POST['authtext']; // Der Text, der angezeigt wird wenn das Login-Fenster geöffnet wird.
if(isset($_POST['folder'])) $passwdFolder = $_POST['folder']; // $_SERVER['DOCUMENT_ROOT'].'/data/htaccess'; //Den kompletten Pfad zu der Datei .htpasswd, ohne abschließenden Slash (/)
if(isset($_POST['server'])){ 
	$server = $_POST['server']; // win server or linux
	if($server == '1') $win = '\\';
}

function make_htaccess(){
    global $user, $passwd, $authName, $passwdFolder, $win;
	$access .= 'AuthType Basic'."\n";
    $access .= 'AuthName "'.$authName . '"'."\n";
    $access .= 'AuthUserFile '.$passwdFolder .$win.'.htpasswd' . "\n";
    $access .= 'require user '.$user."\n";
    
	$accessFile = $passwdFolder.$win.".htaccess";
	
    $handle = fopen($accessFile, "w");
    fputs($handle, $access);
    fclose($handle);
}


function make_htpasswd(){
    global $user, $passwd, $authName, $passwdFolder, $win, $server;
	if($server == 2) $passwd = crypt($passwd);
    $htpasswd = $user.':'.$passwd;
    
    $handle = fopen($passwdFolder.$win.'.htpasswd', "w");
    fputs($handle, $htpasswd);
    fclose($handle);
}


function getUrl(){
	global $passwdFolder;
	$s = $_SERVER['DOCUMENT_ROOT'];
	$url = str_replace($s, '', $passwdFolder);
	return '<h3>'.$url.' created!</h3>';
}


if(isset($user, $passwd, $passwdFolder)){
	if(($passwdFolder != "") and (!file_exists($passwdFolder)))	mkdir($passwdFolder, 0777);
	make_htpasswd();
	make_htaccess();
	header('location: index.php'); 

}

$info = getenv("SERVER_SOFTWARE");
$info = substr($info,strpos($info,"(")+1,strpos($info,")")-(strpos($info,"(")+1));
$info = strtolower($info);
?>
<form action="htaccess_Creator.php" method="post" name="accessform">
  <label>User
Name:

  &nbsp;
  <input name="user" type="text" id="user" size="20" />
  </label>
  <p>
    <label>Password: &nbsp; 
    &nbsp;&nbsp;
    <input name="password" type="text" id="password" size="20" />
    </label>
  </p>
  <p>
    <label>Auth Text <em>(Not required) </em><br />
    <input name="authtext" type="text" id="authtext" value="Hello Admin!" size="60" />
    </label>
  </p>
  <p>
    <label>Data Folder <em>(Documet Root Full Path) </em><br />
    <input name="folder" type="text" id="folder" value="<?php echo dirname(__FILE__); ?>" size="60" />
    </label>
  </p>
  <p>
    <label>
    <strong>System:</strong> 
    <input name="server" type="radio" value="1" <?php if($info == 'win32') echo 'checked="checked"'; ?> />
    win </label>
    <label>
    <input name="server" type="radio" value="2" checked="checked" <?php if($info != 'win32') echo 'checked="checked"'; ?> />
    linux</label>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Current OS: <b><?php echo $info; ?></b>)</p>
  <p>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input id="but" type="submit" name="Submit" value="                   Create now                 " />
  </p>
</form>
</div>
</body>
</html>
