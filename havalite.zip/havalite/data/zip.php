<?php
// Zip Libary einbinden
require("zip.lib.php");

// neuse Zip Objekt erstellen
$zipfile = new zipfile();

if ($handle = opendir('.')) {
    while (false !== ($filename = readdir($handle))) {
        if (preg_match('/\\.db3/', $filename)) {

			$clearfilename = substr($filename, strrpos ($filename, "/"));
			
			// Datei einlesen
			$handler = fopen ($filename, "r");
			$content = fread ($handler, filesize ($filename));
			fclose ($handler);
			
			// Datei in Zipfile speichern
			$zipfile->addFile($content, $clearfilename, filemtime($filename));
        }
    }
    closedir($handle);
}

// Header für Download senden
header("HTTP/1.1 200 OK");
header("Content-Type: application/force-download");
header('Content-Disposition: attachment; filename="havalite.zip"');
header("Content-Transfer-Encoding: binary");

// Zip File senden
echo $zipfile->file(); 
?>