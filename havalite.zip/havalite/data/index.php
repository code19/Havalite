<?php
require_once('config.php');
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>

<style>
body{ font-family:Arial, Helvetica, sans-serif; }
table{ border:1px solid #eaeaea; }
td, th{ border:1px solid #eaeaea; }
a{ text-decoration:none; }
#fileperms{ color:#999999; font-size:12px; }

</style>
<h2>Safe Folder</h2>

<div>
<?php
$currentFile = $_SERVER["SCRIPT_NAME"];
$parts = Explode('/', $currentFile);
$currentFile = $parts[count($parts) - 1];
?>

<table width="100%" border="0" cellpadding="4" cellspacing="0" class="tablesorter" id="tablesorter">
<thead>
<tr>
	<th bgcolor="#CCCCCC" width="200" align="left" valign="top">File</th>
	<th bgcolor="#CCCCCC" width="50" align="left" valign="top">Permissions</th>
	<th bgcolor="#CCCCCC" align="left" valign="top">Info</th>
</tr>
</thead>
<tbody>

<?php
if ($handle = opendir('.')) {
    while (false !== ($file = readdir($handle))) {
        $filePerms = substr(decoct(fileperms($file)), 3);
		$configs = '';
		if ($file != "." && $file != ".." && $file != $currentFile) {
           if($file == 'config.php') $configs = 'Current database: <b>'.$dbPath.'</b>';
		   elseif($file == 'phpinfo.php') $configs = 'Your PHP Server Informations';
		   elseif($file == 'htaccess_Creator.php') $configs = 'Create or Chnage Safe Folder Password';
		   elseif($file == 'updater.php') $configs = 'Havalite live update';
		   elseif(preg_match('/.db3?/', $file)) $configs = 'Your database';
		   elseif($file == 'install.php') $configs = 'Only needed for new installation!';
		   elseif($file == '.htaccess' or $file== '.htpasswd') $configs = 'Important!';
		   elseif($file == 'phpliteadmin.php') $configs = 'phpliteadmin!';
		   echo '<tr><td><a href="'.$file.'">'.$file.'</a></td><td id="fileperms" align="center">'.$filePerms.'</td><td id="fileperms">'.$configs.'</td></tr>';
        }
    }
    closedir($handle);
}

?>
</tbody>
</table>
</div>

</body>
</html>
