<?php
require('hava_func.php');
header('location: '.hava_options('url').'/index.php?p=error');
?>