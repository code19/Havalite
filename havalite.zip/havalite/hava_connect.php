<?php
@require_once('havalite/data/config.php');
/*************** Havalite data ***********************/
$dbp = 'havalite/data/'.$dbPath;
$db = new PDO('sqlite:'.$dbp);
/*****************************************************/

$redefine_single_post = array();

$frontPage = hava_options('frontPage');
if((!isset($p)) and (!isset($s)) and (!isset($cat)) and (!isset($arch)) and ($frontPage == 'page')){
	$page_cat = hava_options('page_cat');
	$res = hava_single_query("SELECT * FROM posts WHERE cat = ? ORDER BY sort", $page_cat);
	$p = $res['id'];
}

// template url
if(!isset($templateUrl)) $templateUrl = 'havalite/themes/'.hava_options('theme').'/';


/* returns array
/* $SQL = The sql statment
/* $data = an array with sql values if WHERE statment exists, other wise set ''
*/
function hava_all_queries($SQL, $data = array()){
	if(isset($SQL)){
		global $db;
		$stm = $db->prepare($SQL);
		if(!$stm){ 
			$errorInfo = $db->errorInfo(); 
			echo $errorInfo[2].': '.$SQL;
			print_r($data);
		}
		if(!empty($data)) $stm->execute($data);
		else $stm->execute();
		$res = $stm->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	else return false;
}


/* returns single array
/* $SQL = The sql statment
/* $data = the sql value if WHERE statment exists, other wise set 'all'
/* $col = column name
*/
function hava_single_query($SQL, $data, $col=''){
	if(isset($SQL) and isset($data)){
		global $db;
		
		$SQL = $db->prepare($SQL);
		
		if($data == "all") $SQL->execute();
		else $SQL->execute(array($data));
		
		$res = $SQL->fetch(PDO::FETCH_ASSOC);
		
		if($col){ return $res[$col]; }
		else{ return $res; }
	}
	else return false;
}

/* save single query to db
/* $SQL = The sql statment
/* $data = an array with sql values
/* $insert, if true = retireve last inserted id
*/
function saveSqlite($SQL, $data, $insert=false){
	global $activeHavalite;
	if(isset($SQL) and checkSqlite($SQL) and $activeHavalite){
		global $db;
		$res = 'Failed';
		
		$stm = $db->prepare($SQL);
		if($stm->execute($data)){ 
			if($insert){ $res = $db->lastInsertId(); }
			else{ $res = 'Successfull'; }
		}
		
		return $res;
	}
}

/* get number of rows 
/* $SQL = sql statment
/* $data = an array with sql values
*/
function hava_num_rows($SQL, $data=array()){
	$count = 0;
	if(isset($SQL)){
		$result = hava_all_queries($SQL, $data);
		if($result){
			foreach($result as $row){ $count++; }
		}
		return $count;
	}
}

/* check SQL statment
*/
function checkSqlite($SQL){ 
	if (preg_match('/(--|union|users)/', $SQL)){ return false; } 
	else { return true; }
}

/* Check if the user is logged to preview Drafts
/* $log = the code which saved in the db when user logs in
*/
function checkPreview($log){
	if(isset($log)){
		$sq = hava_single_query("SELECT * FROM users WHERE log = ?", $log);
		if($sq['log'] != '') return $sq['log'];
		else return false;
	}
}

/* return all settings
/* $opt = the name of the option (title, tagline, description, url, language, theme etc.. 
*/
function hava_options($opt){
	if(isset($opt)){
		$result = hava_all_queries("SELECT * FROM options WHERE opt = ?", array($opt));
		$res = '';
		
		foreach($result as $row){ $res = $row['val']; }
		return $res;
	}
}

/* returns number of comments
/* $id = the post id
*/
function hava_num_comments($id){
	if(isset($id)){
		$num = hava_num_rows("SELECT * FROM comments WHERE post = ? AND approved = ?", array($id, 1));
		return $num;
	}
}

/* Url of the current theme 
/* $theme = set another theme url
*/
function hava_template_url($theme=''){
	global $templateUrl;
	if(empty($theme)) $theme =  hava_options('theme');
	$url = hava_options('url');
	if($url) $url = $url.'/';
	return $url.$templateUrl;
}


/* returns data for single post
/* $id = post id, leave empty '' or type 'all' to view all
/* $dataName = id, title, cat, tags, author, text, date, comments (true, false), prop (true=public, false=draft) 
/* $slice = a Number of chars from string. 0 = whole Text
*/
function hava_single_post($id, $dataName, $slice='0', $related='Related Posts'){
	global $preview, $redefine_single_post;
	$res = '';
	$opt = hava_options('similarPost');
	
	if(checkPreview($preview) != '') $prop = '';
	else $prop = " prop='1' AND";

	$result = hava_all_queries("SELECT * FROM posts WHERE ".$prop." id = ?", array($id));

	if($result){
		foreach($result as $row){ 
			if($slice > 0){ 
				$data = strip_tags($row[$dataName], '<p><br>');
				$res .= substr($data, 0, $slice); 
			}
			else { 
				$similar = '';
				if($dataName=='text' and $opt=='on'){ $similar =  hava_similar_post($id, $related); } 
				$res .= $row[$dataName].$similar; 
			}
		}
	}
	
	if(!empty($redefine_single_post) and $dataName=='text'){
		foreach($redefine_single_post as $rsp){
			if(function_exists($rsp)) $res = call_user_func($rsp, $res);
		}
	}

	return $res;
}


/* get similar post according to saved keywords
/* $postId = the id of the current post
*/
function hava_similar_post($postId, $related=''){
	$res= '';
	$post = hava_single_query("SELECT * FROM posts WHERE prop=1 AND id = ?", $postId, "tags");
	if(!empty($post)){
		$res= '<fieldset><legend>'.$related.'</legend>';
		$tag = preg_split('/[ |,]/', $post);
		for($i =0; $i<count($tag); $i++){
			$ta = trim($tag[$i]);
			if(!empty($ta)){
				$res .= '<a title="'.$ta.'" href=?s='.$ta.'>'.$ta.'</a> ';
			
			
			}
		}
		$res .= '</fieldset>';
	}
	return $res;
}

/* returns array of all public posts
/* $cat = get only posts of this category
/* $limit = limit number of posts
*/
function hava_posts($cat='', $limit=''){
	$page_cat = hava_options('page_cat');
	$postAmount = hava_options('post_amount');
	if(isset($limit) and $postAmount>0){ 
		$limitStr = " LIMIT ".$limit.", ".$postAmount; 
	}
	else $limitStr = '';
	
	if($cat){ $result = hava_all_queries("SELECT * FROM posts WHERE  prop='1' AND cat= ? AND cat !='".$page_cat."' ORDER BY date DESC".$limitStr, array($cat)); }
	else { $result = hava_all_queries("SELECT * FROM posts WHERE  prop='1' AND cat !='".$page_cat."' ORDER BY date DESC".$limitStr); }
	return $result;
}

/* get a navigation bar of (Next, previous) unter posts
/* $cat = get only posts of this category
/* $limit = limit number of posts
/* $arrowPrevSign = default is &laquo;&laquo; change to text or image if needed
/* $arrowNextSign = default is &raquo;&raquo; change to text or image if needed
*/
function hava_nav($cat='', $limit='', $arrowPrevSign='', $arrowNextSign=''){
	
	$postAmount = hava_options('post_amount');
	
	if($limit){ $limitRes = ' LIMIT '.$limit.', '.$postAmount; }
	else{ $limitRes = ' LIMIT '.$limit; }
	
	$num = '';
	if($cat){ $num = hava_num_rows("SELECT * FROM posts WHERE prop=1 AND cat=?", array($cat)); }
	else{ $num = hava_num_rows("SELECT * FROM posts WHERE prop=1"); }
	
	if($arrowPrevSign=='') $arrowPrevSign = '&laquo;&laquo;';
	if($arrowNextSign=='') $arrowNextSign = '&raquo;&raquo;';
	
	$res = '';
	$arrowPrevious = ''; $arrowNext = '';
	
	if($num > $postAmount){
		
		for($i=0; $i<$num; $i = $i+$postAmount){
			if($limit == $i){ $res .= '<span id="current_nav">'.$i.'</span>'; }
			else { $res .= '<a id="nav_link" href="?limit='.$i.'&cat='.$cat.'">'.$i.'</a>'; }
		}
		
		if($limit==0){ $arrowNext = '<a href="?limit='.($limit+$postAmount).'&cat='.$cat.'" id="arrow_next" title="Next">'.$arrowNextSign.'</a>'; }
		elseif($limit+$postAmount < $num and $limit > 0){ 
			$arrowNext = '<a href="?limit='.($limit+$postAmount).'&cat='.$cat.'" id="arrow_next" title="Next">'.$arrowNextSign.'</a>'; 
			$arrowPrevious = '<a href="?limit='.($limit-$postAmount).'&cat='.$cat.'" id="arrow_previous" title="Previous">'.$arrowPrevSign.'</a>'; }
		elseif($num <= $limit+$postAmount){ $arrowPrevious = '<a href="?limit='.($limit-$postAmount).'&cat='.$cat.'" id="arrow_previous" title="Previous">'.$arrowPrevSign.'</a>'; }
	}
	return $arrowPrevious.$res.$arrowNext;
}

/************************ Comments **************************/

/* returns array of all approved comments
/* $postId = id of the current post 
*/
function hava_comments($postId, $asc='ASC'){
	$ip = $_SERVER['REMOTE_ADDR']; 
	return hava_all_queries("SELECT * FROM comments WHERE post= ? AND (approved=1 or ip='".$ip."') ORDER BY date ".$asc, array($postId));
}


/* save comment 
/* $postId = id of the current post 
/* $name = name of subscriber
/* $email = his email
/* $comment = the comment text
/* $website = his websites if typed
*/
function save_comment($postId, $name, $email, $comment, $website=''){
	global $db, $activeHavalite;
	if($activeHavalite){
		$res = '';
		
		if(!$postId or !$name or !$email or !$comment){ $res = 0; }
		elseif(validate($email) == false) { $res = 0; }
		else{
			$ip = $_SERVER['REMOTE_ADDR']; 
			$date = date('Y-m-d H:i:s');
			$comment = correctLines($comment);

			$data = array($name, $website, $email, $comment, $postId, 0, $date, $ip);
			
			$stm = $db->prepare("INSERT INTO comments (name, website, email, comment, post, approved, date, ip) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
			
			if($stm->execute($data)){ 
				$lastId = $db->lastInsertId();
				$res = 1; 
				if(hava_options('notEmail') == 'on'){ $res = commentNotify($postId, $name, $email, $website, $ip, $comment, $lastId); }
			}
			else{ $res = 0;}
		}
		return $res;
	}
} 


/* Email validation 
/* $email = the email to check
*/
function validate($email){
	if (preg_match('/\\b[a-z|A-Z0-9\\._%-]+@[a-z|A-Z0-9\\._%-]+\\.[A-Z|a-z]{2,4}\\b/', $email)) { return 1;	} 
	else { return 0; }
}

/* Check if Url has -> http:// . If not, set it to the Url
/* $url = the url adresse 
*/
function correctUrl($url){
	if(!empty($url)){
		$url = preg_replace('/\/[ ]*$/', '', $url);
		if(!preg_match('/^http[s]*:\/\//', $url)) {
			$url = 'http://'.$url;
		}
	}
	return $url;
}

/* correct breaks and quotes in text
/* $text = the string to correct
*/
function correctLines($txt){
	$txt = nl2br($txt);
	$txt = preg_replace('/[\n\r]/', '', $txt);
	$txt = str_replace('"', '&quot;', $txt); 
	$txt = str_replace("'", "&acute;", $txt);
	return $txt;
}

/* correct quotes in text, from &quot; to &amp;quot;
/* $txt = the string to correct
*/
function correctQuotes($txt){
	$txt = str_replace('"', '&quot;', $txt); 
	$txt = str_replace("'", "&acute;", $txt);
	return $txt;
}

/* set quotes back , from &amp;quot; to &quot; 
/* $txt = the string to correct
*/
function recorrectQuotes($txt){
	$txt = str_replace('&quot;', '"', $txt); 
	$txt = str_replace("&acute;", "'", $txt);
	return $txt;
}


/******************* Email ************************/
/* send email notification to the admin by new comment
/* $postId = the post where is comment is written
/* $author = The subscriber name
/* $authorEmail = his email
/* $authorSite = his website if exists
/* $authorIp = his ip
/* $comment = his comment text
*/
function commentNotify($postId, $author, $authorEmail, $authorSite, $authorIp, $comment, $commentId=''){
	if(isset($postId, $author, $authorEmail, $authorSite, $authorIp, $comment)){
		global $db;
		$lang = hava_options('language');
		require_once('sys/languages/'.$lang.'.php');
		
		$result = $db->query("SELECT * FROM users WHERE user='admin'");
		$sq = $result->fetch(PDO::FETCH_ASSOC);	
		$email = $sq['email'];
		
		$postTitle = hava_single_query("SELECT * FROM posts WHERE id=?", $postId, "title");
		
		$url = hava_options('url');
		$sub = '['.hava_options('title').'] New Comment';
		
		$mes = '<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body style="direction:'.$hava_lang['direction'].';"><p>'.hava_options('title').' - '.$hava_lang['notEmail'].': <b><a href="'.$url.'/?p='.$postId.'">'.$postTitle.'</a></b></p>
	
'.$hava_lang['author'].' : '.$author.'<br>
'.$hava_lang['email'].' : '.$authorEmail.'<br>
'.$hava_lang['url'].'    : '.$authorSite.'<br>
Whois  : <a href="http://whois.arin.net/rest/ip/'.$authorIp.'">'.$authorIp.'</a><br>
<h3>'.$hava_lang['comment'].':</h3>
<div>'.$comment.'</div> 
	
<p><a href="'.$url.'/havalite/hava_comm.php?commId='.$commentId.'&approState=0">'.$hava_lang['comment'].' '.$hava_lang['approve'].'</a></p></body></html>';
    
		//$mes = htmlspecialchars_decode($mes,ENT_QUOTES);
		$emailUrl = $result = preg_replace('/http[s]*:\/\/(www\\.)*/', '', $url);

		$headers = "From: Havalite <havalite@".$emailUrl.">\r\n";
		 $headers .= "MIME-Version: 1.0\r\n";
		 $headers .= "Content-type: text/html; charset: utf8\r\n";
		if(mail($email, "=?utf-8?B?".base64_encode($sub)."?=", $mes, $headers)){ return 1; }
	}
}

/* create Gravatar link
/* $email = the email
/* $s = size of image
/* $d = default image (mm, identicon, monsterid, wavatar, retro OR url-adresse)
/* $class = css class, default is gravatar
*/
function hava_gravatar( $email, $s='', $d='', $class=false) {
	$gOpt = hava_options('gravatar');
	$gOpt = preg_split('/-/', $gOpt, 2);
	if(empty($s)) $s = $gOpt[0];
	if(empty($d)) $d = $gOpt[1];
	if($class) $class = ' class="gravatar" ';

	$url = 'http://www.gravatar.com/avatar/';
	$url .= md5( strtolower( trim( $email ) ) );
	$url .= "?s=".$s."&d=".$d."&r=g";
	$url = '<img id="gravatar" '.$class.' src="' . $url . '" />';
	
	return $url;
}


/* get date formate as set bei the user
/* $myDate = the date
/* $formate = define own formate or leave empty 
*/
function hava_date($myDate, $formate=''){
	if($formate == ''){ $formate = hava_options('date_time'); }
	$myDate = strtotime($myDate); 
	return date($formate, $myDate);
}


/****************************** Sidebar functions *************************/


/* Sort links in UL tag for sidebar
/* $element = set any id or class element
*/
function hava_sidebar_links($element=''){
	$result = hava_all_queries("SELECT * FROM links WHERE state=1 ORDER BY sort");
	$res = '<ul '.$element.'>';
	foreach($result as $row){
		$res .= '<li><a href="'.$row['url'].'" title="'.$row['description'].'" id="sidebar_links">'.$row['name'].'</a></li>';
	}
	return $res.'</ul>';
}

/* Sort categories in UL or SELECT tag for sidebar
/* $element = set any id or class element
/* $post = show number of posts for every category
/* $menu = false (UL tag), true = (SELECT tag)
*/
function hava_sidebar_cat($element='', $post=false, $menu = false){
	global $cat;
	$myUrl = hava_options('url').'/index.php';
	$result = hava_all_queries("SELECT * FROM cat ORDER BY sort");
	
	if($menu){ 
		$res = '<select onChange="top.location.href = this.value;" name="cat_select" '.$element.'>'; 
		$end = '</select>'; 
		$tag = '<option value';
		$eTag = '</option>';
	}
	else{ 
		$res = '<ul '.$element.'>'; 
		$end = '</ul>'; 
		$tag = '<li><a href';
		$eTag = '</a></li>';
	}
	
	foreach($result as $row){
		$num = hava_num_rows("SELECT * FROM posts WHERE prop = 1 and cat = ?", array($row['name']));
		
		$cat_sel = '';
		if(isset($cat) and $cat == $row['name']) $cat_sel = ' selected="selected"';
		
		if($row['prop'] == 1){}
		elseif($post){
			if($num>0) $res .= $tag.'="'.$myUrl.'?cat='.$row['name'].'" title="'.$row['desc'].'"'.$cat_sel.'>'.$row['name'].' ('.$num.')'.$eTag;
		}
		else{
			if($num>0) $res .= $tag.'="'.$myUrl.'?cat='.$row['name'].'" title="'.$row['desc'].'"'.$cat_sel.'>'.$row['name'].$eTag;
		}
	}
	return $res.$end;
}

/* Sort post titles in UL tag for sidebar
/* $limit = define a limit number
/* $writtenBy = change this text to what ever you want
/* $element = set any id or class element
*/
function hava_sidebar_posts($limit='', $writtenBy='', $element=''){
	$page_cat = hava_options('page_cat');
	if(!$limit){ $limit = hava_options('post_amount'); }
	if(!$writtenBy){ $writtenBy = 'written by:'; }
	$result = hava_all_queries("SELECT * FROM posts WHERE prop=1 AND cat != '".$page_cat."' ORDER BY date DESC LIMIT ".$limit);
	$res = '<ul '.$element.'>';
	$myUrl= hava_options('url').'/index.php';
	foreach($result as $row){
		$res .= '<li><a href="'.$myUrl.'?p='.$row['id'].'" title="'.$writtenBy.' '.$row['author'].'" id="sidebar_posts">'.$row['title'].'</a></li>';
	}
	return $res.'</ul>';
}

/* Sort pages in UL tag for sidebar
/* $writtenBy = change this text to what ever you want
/* $element = set any id or class element
/* $sort = sort by (sort, id, date)
*/
function hava_sidebar_pages($writtenBy='', $element='', $sort = ''){
	$myUrl = hava_options('url').'/index.php';
	$page_cat = hava_options('page_cat');
	$res = '<ul '.$element.'>';
	if(empty($sort)) $sort = '';
	else $sort = ' ORDER BY '.$sort;
	
	if(!$page_cat){ $res = 'No Category assigned for static pages!'; }
	else{
		$result = hava_all_queries("SELECT * FROM posts WHERE prop=1 AND cat= ?".$sort, array($page_cat));
		foreach($result as $row){
			$res .= '<li><a href="'.$myUrl.'?p='.$row['id'].'" title="'.$writtenBy.' '.$row['author'].'" id="sidebar_pages">'.$row['title'].'</a></li>';
		}
	}
	return $res.'</ul>';
}

/* Sort comments in UL tag for sidebar
/* $limit = define a limit number
/* $writtenBy = change this text to what ever you want
*/
function hava_sidebar_comments($limit='', $written_by='', $element=''){
	if(!$limit){ $limit = hava_options('limit_res'); }
	$result = hava_all_queries("SELECT * FROM comments WHERE approved=1 ORDER BY date DESC LIMIT ".$limit);
	$res = '<ul '.$element.'>';
	foreach($result as $row){
		$post = $row['post'];
		$pRes = hava_all_queries("SELECT * FROM posts WHERE id=?", array($post));
		foreach($pRes as $p){
			$res .= '<li title="'.$written_by.' '.$row['name'].'">'.$row['name'].' <a title="'.$p['title'].'" href="?p='.$p['id'].'#'.$row['id'].'">('.$p['title'].')</a></li>';
		}
	}
	return $res.'</ul>';
}

/* Create Search form
/* $input = text to show in input value
/* $submit = text to show in submit value
/* $img = set to image instead of button
*/
function hava_sidebar_search($input='', $submit ='Submit', $img=''){
	if(empty($img)) $type= 'type="submit"';
	else $type = 'type="image" src="'.$img.'"';
	
	$res = '<form method="get" id="the_search_form" action=""><span><input type="text" value="'.$input.'" name="s" id="search_input" /><input name="searchsubmit" '.$type.' value="'.$submit.'" title="'.$submit.'" id="search_submit" class="btn"  /></span></form>';
	return $res;

}

/* replace smiley chars to images
/* $msg = the text
*/
function smiley($msg) { 
	$folder = 'havalite/sys/img/smilies/';
	$msg = str_replace(':)','<img src="'.$folder.'icon_smile.gif" border="0">', $msg); 
	$msg = str_replace(':-)','<img src="'.$folder.'icon_smile.gif" border="0">', $msg);
	$msg = str_replace(';)','<img src="'.$folder.'icon_wink.gif" border="0">', $msg); 
	$msg = str_replace(';-)','<img src="'.$folder.'icon_wink.gif" border="0">', $msg); 
	$msg = str_replace(':|','<img src="'.$folder.'icon_neutral.gif" border="0">', $msg); 
	$msg = str_replace(':D','<img src="'.$folder.'icon_biggrin.gif" border="0">', $msg); 
	$msg = str_replace(':d','<img src="'.$folder.'icon_biggrin.gif" border="0">', $msg); 
	$msg = str_replace(':(','<img src="'.$folder.'icon_frown.gif" border="0">', $msg); 
	$msg = str_replace(':-(','<img src="'.$folder.'icon_frown.gif" border="0">', $msg);

    return $msg; 
} 

/*****************************************************************/
/************************** jQuery *******************************/
/* set jQuery script url in head of admin area
*/
function hava_jQuery($version = '1.7.2'){
	/* $scriptLine = '<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>'; */
	$scriptLine = '<script type="text/javascript" src="havalite/sys/jquery/js/jquery-'.$version.'.min.js"></script>';
	return $scriptLine;
}

/* set fancy box script url in head of admin area to view images
*/
function hava_fancyBox(){
	$scriptLine = '<script type="text/javascript" src="havalite/sys/jquery/fancybox/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>'.
					'<script type="text/javascript" src="havalite/sys/jquery/fancybox/fancybox/jquery.fancybox-1.3.4.pack.js"></script>'.
					'<link rel="stylesheet" type="text/css" href="havalite/sys/jquery/fancybox/fancybox/jquery.fancybox-1.3.4.css" media="screen" />';

	return $scriptLine;
}

/* return true if plugin activated
/* $plugin = the plugin name
*/
function plugin_check($plugin){
	$res = hava_num_rows("SELECT * FROM plugins WHERE state = 1 AND name = ?", array($plugin));
	if($res > 0){ return 1; }
	else{ return 0;}
}


/* another Search Form (see: hava_sidebar_search())
*/
function hava_search_form($submitValue=''){
	if(!$submitValue){ $submitValue = 'Search'; }
	$res = '<span id="the_search_form"><form id="search_form" name="search_form" method="get" action="">
    <input name="s" type="text" id="search_input" value="" />
    <input type="submit" name="searchsubmit" id="search_submit" value="'.$submitValue.'" />
  	</form></span>';
  	return $res;
}

/* Create a Comments Form 
/* $p = id of the current post
/* $name = change the word "Name"
/* $email = change the word "Email"
/* $website = change the word "Website"
/* $comment = change the word "Comment"
/* $submit = change the word "Submit Comment"
*/
function hava_comment_form($p, $name='', $email='', $website='', $comment='', $submit=''){
	$page = hava_single_query("SELECT * FROM posts WHERE id = ?", $p);
	if($page['comments'] == 1){
		if(!$name){ $name = '*Name'; }
		if(!$email){ $email = '*Email'; }
		if(!$website){ $website = 'Website'; }
		if(!$comment){ $comment = '*Comment'; }
		if(!$submit){ $submit = 'Submit Comment'; }
		
		$res ='<span id="the_comment_form"><form action="" method="post" name="comment_form" id="comment_form">
		<label class="name"><span>'.$name.': </span><input name="name" type="text" id="name" /></label>
		<label class="email"><span>'.$email.': </span><input name="email" type="text" id="email" /></label>
		<label class="website"><span>'.$website.': </span><input name="website" type="text" id="website" /></label>
		<label class="comment"><span>'.$comment.'</span><textarea name="comment" cols="50" rows="5" id="comment"></textarea></label>
		<label class="submit"><input type="submit" name="Submit_comment" id="Submit_comment" value="'.$submit.'" /></label>
		</form></span>';
  
		return $res;
	}
}

/* get the role of the user
/* $user = the user name
*/
function hava_user_role($user){
	$role = explode(',', hava_options('usersLvl'));
	$lvl = hava_single_query("SELECT * FROM users WHERE user =?", $user, "lvl");
	$res = '';
	for($i = 0; $i<count($role); $i++){
		if(($i+1) == $lvl) $res = trim($role[$i]);
	} 
	return $res;
}

function hava_user_name($user){

	$name = hava_single_query("SELECT * FROM users WHERE user =?", $user, 'name');
	if(empty($name)) return $user;
	else return $name;

}

/* get a sidebar by name with all widgets inside for 
/* $sidebar = the name of the sidebar
*/

/* <br>
*/
/* // Standard Widgets ******************* 
*/

function hava_sidebar_widget($sidebar){
	$w_option = hava_options("widgets");
	$res = '';
	
	$w_opt = preg_split('/\\|/', $w_option);
		
	for($i =0; $i< count($w_opt); $i++){
		if (preg_match('/'.$sidebar.'\\[/', $w_opt[$i])) {  // sidebar name found-----------
			$w_opt[$i] = preg_replace('/(\\.\\w+\\[)|(\\])/', '', $w_opt[$i]);
			$w_single = preg_split('/,/', $w_opt[$i]);
			
			for($x = 0; $x < count($w_single); $x++){
				$myWidget = trim($w_single[$x]);
				$wres = hava_single_query("SELECT * FROM widgets WHERE name = ? and active=1", $myWidget);
				if(!empty($wres)){
					$func = trim($wres['func']);
					if(function_exists($func))
					$res .= call_user_func($func, $wres['result']);
					//$res .= split_str_parse($wres);
				}
			}
		}
	}
	//printf($res, $_GET['p']);
	return $res;
}

/* Text Widget 1
/* arg0 = the title
/* arg1 = the text
*/
function Text1_widget($args){
	if(!empty($args)){
		parse_str($args);

		return '<div id="Text1" class="sidebar_widget"><h2>'.$arg0.'</h2><div>'.$arg1.'</div></div>';
	}
}

/* Text Widget 2 
/* arg0 = the title
/* arg1 = the text
*/
function Text2_widget($args){
	if(!empty($args)){ 
		parse_str($args);
		return '<div id="Text2" class="sidebar_widget"><h2>'.$arg0.'</h2><div>'.$arg1.'</div></div>';
	}
}

/* The links list Widget 
/* arg0 = the title
*/
function Links_widget($args){
	if(!empty($args)){
		parse_str($args);
		return '<div id="Links" class="sidebar_widget"><h2>'.$arg0.'</h2><div>'.hava_sidebar_links().'</div></div>';
	}
}

/* Latest Post Widget
/* arg0 = the title
/* arg1 = count of posts
/* arg2 = the word "written by:"
*/
function Post_widget($args){
	if(!empty($args)){
		parse_str($args);
		
		return '<div id="Post" class="sidebar_widget"><h2>'.$arg0.'</h2><div>'.hava_sidebar_posts($arg1, $arg2, '').'</div></div>'; // hava_sidebar_posts($limit='', $writtenBy='', $element='')
	}
}

/* Categories Widget
/* arg0 = the title
/* arg1 = view post amount (true or false)
/* arg2 = UL list or Select menu (true or false)
*/
function Categories_widget($args){
	if(!empty($args)){
		parse_str($args);
		if($arg1=='false') $arg1 = false;
		if($arg2=='false') $arg2 = false;
		return '<div id="categories" class="sidebar_widget"><h2>'.$arg0.'</h2><div>'.hava_sidebar_cat('', $arg2, $arg1).'</div></div>'; //hava_sidebar_cat($element='', $post=false, $menu = false)
	}
}

/* RSS Widget
/* arg0 = the title
/* arg1 = RSS image Url
/* arg2 = set to "categories" for categories feed
*/
function RSS_widget($args){
	if(!empty($args)){
		global $cat;
		parse_str($args);
		
		if(empty($arg1)) $arg1='RSS';
		else $arg1 = '<img src="'.$arg1.'" alt="'.$arg0.'" align="middle" />';
		
		$feed= '';
		if($arg2 == 'categories' and !empty($cat)) $feed = '&cat='.$cat;
		
		$res = '<div id="RSS" class="sidebar_widget"><a href="?feed=rss'.$feed.'" title="'.$arg0.'">'.$arg1.' '.$arg0.'</a></div>';
		return $res;
	}
}

/* Search Widget
/* arg0 = the title
/* arg1 = Text in the input field
/* arg2 = value of submit button
/* arg3 = image Url instead of the button
*/
function Search_widget($args){
	if(!empty($args)){
		parse_str($args);
		return '<div id="Search" class="sidebar_widget"><h2>'.$arg0.'</h2><div>'.hava_sidebar_search($arg1, $arg2, $arg3).'</div></div>'; //hava_sidebar_search($input='Search', $submit ='Submit', $img='')
	}
}

/* Static Pages Widget
/* arg0 = the title
/* arg1 = sort by (sort, id, date)
/* arg2 = the word (written by:)
*/
function Pages_widget($args){
	if(!empty($args)){
		parse_str($args);
		return '<div id="pages" class="sidebar_widget"><h2>'.$arg0.'</h2><div>'.hava_sidebar_pages($arg2, '', $arg1).'</div></div>'; // hava_sidebar_pages($writtenBy='', $element='', $sort = 'sort')
	}
}

/* Latest Comments Widget
/* arg0 = the title
/* arg1 = count of comments
/* arg2 = the word (Written by:)
*/
function Comments_widget($args){
	if(!empty($args)){
		parse_str($args);
		if(empty($arg1)) $arg1 = 5;
		return '<div id="Links" class="sidebar_widget"><h2>'.$arg0.'</h2><div>'.hava_sidebar_comments($arg1, $arg2).'</div></div>'; // hava_sidebar_comments($limit='', $written_by='')
	}
}





?>