<?

require_once('../../data/config.php');
/*************** Havalite data ***********************/
$dbPath = '../../data/'.$dbPath;
$db = new PDO('sqlite:'.$dbPath);
/*****************************************************/

function plugin_value($name, $val){
	$row = hava_single_query("SELECT * FROM plugins WHERE name = ?", $name);
	return $row[$val];
}

// returns array
// $data = should be array with sql values if WHERE statment exists, other wise set ''
function hava_all_queries($SQL, $data = array()){
	if(isset($SQL)){
		global $db;
		$SQL = $db->prepare($SQL);
		if(empty($data)) $SQL->execute();
		else $SQL->execute($data);
		$res = $SQL->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	else return false;
}

// returns single array
// $data = the sql value if WHERE statment exists, other wise set 'all'
// $col = column name
function hava_single_query($SQL, $data, $col=''){
	if(isset($SQL) and isset($data)){
		global $db;
		
		$SQL = $db->prepare($SQL);
		
		if($data == "all") $SQL->execute();
		else $SQL->execute(array($data));
		
		$res = $SQL->fetch(PDO::FETCH_ASSOC);
		
		if($col){ return $res[$col]; }
		else{ return $res; }
	}
	else return false;
}

// check if theme tring to get information about the users pass
function checkSqlite($SQL){ 
	if (preg_match('/users/', $SQL)){ return true; } 
	else { return false; }
}

// Get options from DB 
function hava_options($opt){
	$result = hava_all_queries("SELECT * FROM options WHERE opt = ?", array($opt));
	$res = '';
	foreach($result as $row){ $res = $row['val']; }
	return $res;
}

function update_value($name, $valname, $val){
	global $db, $activeHavalite;
	if($activeHavalite){
		$SQL = "UPDATE plugins SET ".$valname." = '".$val."' WHERE name = '".$name."'";
		$db->exec($SQL);
	}
}

// save single query to db ----------------------------------------------
function saveSqlite($SQL, $data=array(), $insert=''){
	global $activeHavalite;
	if(isset($SQL) and !checkSqlite($SQL) and $activeHavalite){
		global $db;
		$res = 'Failed';
		
		$stm = $db->prepare($SQL);
		if($stm->execute($data)){ 
			if($insert){ $res = $db->lastInsertId(); }
			else{ $res = 'Successfull'; }
		}
		
		return $res;
	}
}

?>