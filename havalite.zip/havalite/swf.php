<?php
require_once('hava_media.php');

$swf = NULL;

if(isset($_GET['id'])){ 
	$id = $_GET['id'];
	$swf = hava_single_query("SELECT * FROM images WHERE id=?", $id, "data");
}
if(isset($_GET['name'])){
	$name = $_GET['name'];
	$swf = hava_single_query("SELECT * FROM images WHERE name=?", $name, "data");
}

header("content-type: application/x-shockwave-flash");
echo base64_decode($swf);
?>