<?php
if (preg_match('/\\/plugins\\//', $_SERVER['PHP_SELF'])) header('location: ../../../index.php'); // relink to main page

$ivTime = time();
$imgvalPath = 'havalite/plugins/imgval/';

function imgvalJs(){
	global $ivTime, $imgvalPath, $p;
	if($p){
	$res = '
<script language="JavaScript"> 

var ivTime = '.$ivTime.'; 

var imgvalidator = "\r\n<label id=\"codeLabel\"><span>Code: </span><input type=\"text\" name=\"comment_code\" value=\"\" /> " +
"<a href=\"no_matter\" onClick=\"document.getElementById(\'__code__\').src = \''.$imgvalPath.'code.php?id=\' + ++ivTime; return false;\" title=\"Click here to reload\"><img id=\"__code__\" src=\"'.$imgvalPath.'code.php?id='.$ivTime.'\" border=\"0\" /></a> " +
"<small>Please type the code shown in the image!</small></label>"; 
	
$(document).ready(function(){
	$(".website").after(imgvalidator);
});

</script>
';
	return $res;
	}
}


function checkCommentCode(){
	if(isset($_POST['comment_code'])){
		//$ip = $_SERVER['REMOTE_ADDR'];
		//if($ip == '127.0.0.1') $_ENV['saveComment'] = false;
		
		if(md5(strtoupper($_POST['comment_code'])) != $_SESSION['__img_code__']){ 
			$_ENV['saveComment'] = false;
		}
	}
	else $_ENV['saveComment'] = false;
}

add_filter('checkCommentCode', 'the_begin');
add_filter('imgvalJs', 'the_head');

?>
