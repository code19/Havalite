<?

require_once('../../hava_plugin_connect.php');


$imgval_value1 = plugin_value("imgval", "value1");

if($imgval_value1==''){
	$codeString = 'CODE_WIDTH=120&CODE_HEIGHT=25&CODE_FONT_SIZE=14&CODE_CHARS_COUNT=5&CODE_LINES_COUNT=20&CODE_CHAR_COLORS=#880000,#008800,#000088,#888800,#880088,#008888,#000000&CODE_LINE_COLORS=#DD6666,#66DD66,#6666DD,#DDDD66,#DD66DD,#66DDDD,#666666&CODE_BG_COLOR=#FFFFFF&CODE_ALLOWED_CHARS=ABCDEFGHJKLMNPQRSTUVWXYZ2345689&PATH_TTF=fonts';
}
else{ $codeString = $imgval_value1; }
	
	parse_str($codeString);

	define('CODE_WIDTH',         $CODE_WIDTH);
	define('CODE_HEIGHT',        $CODE_HEIGHT);
	define('CODE_FONT_SIZE',     $CODE_FONT_SIZE);
	define('CODE_CHARS_COUNT',   $CODE_CHARS_COUNT);
	define('CODE_LINES_COUNT',   $CODE_LINES_COUNT);
	define('CODE_CHAR_COLORS',   $CODE_CHAR_COLORS);
	define('CODE_LINE_COLORS',   $CODE_LINE_COLORS);
	define('CODE_BG_COLOR',      $CODE_BG_COLOR);
	define('CODE_ALLOWED_CHARS', $CODE_ALLOWED_CHARS);
	define('PATH_TTF',           $PATH_TTF);
?>