<?php
if (preg_match('/\\/plugins\\//', $_SERVER['PHP_SELF'])) header('location: ../../../index.php'); // relink to main page
?><div style="border:1px solid #ccc; padding:15px;">
<?
if(isset($_POST['pluginId'])){
	$newCodeString = 'CODE_WIDTH='.$_POST['CODE_WIDTH'].'&CODE_HEIGHT='.$_POST['CODE_HEIGHT'].'&CODE_FONT_SIZE='.$_POST['CODE_FONT_SIZE'].'&CODE_CHARS_COUNT='.$_POST['CODE_CHARS_COUNT'].'&CODE_LINES_COUNT='.$_POST['CODE_LINES_COUNT'].'&CODE_CHAR_COLORS='.$_POST['CODE_CHAR_COLORS'].'&CODE_LINE_COLORS='.$_POST['CODE_LINE_COLORS'].'&CODE_BG_COLOR='.$_POST['CODE_BG_COLOR'].'&CODE_ALLOWED_CHARS='.$_POST['CODE_ALLOWED_CHARS'].'&PATH_TTF='.$_POST['PATH_TTF'];
	//echo $_POST['pluginId'].' '.$newCodeString;
	$pluginId = $_POST['pluginId'];
	saveSqlite("UPDATE plugins SET value1=? WHERE id=?", array($newCodeString, $pluginId));
}

$imgvalRow = hava_single_query("SELECT * FROM plugins WHERE name = ?", 'imgval');

if($imgvalRow['value1']==''){
	$codeString = 'CODE_WIDTH=120&CODE_HEIGHT=25&CODE_FONT_SIZE=14&CODE_CHARS_COUNT=5&CODE_LINES_COUNT=20&CODE_CHAR_COLORS=#880000,#008800,#000088,#888800,#880088,#008888,#000000&CODE_LINE_COLORS=#DD6666,#66DD66,#6666DD,#DDDD66,#DD66DD,#66DDDD,#666666&CODE_BG_COLOR=#FFFFFF&CODE_ALLOWED_CHARS=ABCDEFGHJKLMNPQRSTUVWXYZ2345689&PATH_TTF=fonts';
}
else{ $codeString = $imgvalRow['value1']; }
	
parse_str($codeString);

?>
<form id="imgval_form" name="imgval_form" method="post" action="">
  <table  border="0" align="center" cellpadding="7" cellspacing="0">
  <tr>
    <td colspan="2" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td width="100" valign="top">CODE_WIDTH</td>
    <td valign="top"><input name="CODE_WIDTH" type="text" id="CODE_WIDTH" size="10" value="<?php echo $CODE_WIDTH; ?>" /> 
      px 
        <input name="pluginId" type="hidden" id="pluginId" value="<?php echo $pluginId; ?>" /></td>
  </tr>
  <tr>
    <td width="100" valign="top">CODE_HEIGHT</td>
    <td valign="top"><input name="CODE_HEIGHT" type="text" id="CODE_HEIGHT" size="10" value="<?php echo $CODE_HEIGHT; ?>" /> 
      px </td>
  </tr>
  <tr>
    <td width="100" valign="top">CODE_FONT_SIZE</td>
    <td valign="top"><input name="CODE_FONT_SIZE" type="text" id="CODE_FONT_SIZE" size="10" value="<?php echo $CODE_FONT_SIZE; ?>" /> 
      px </td>
  </tr>
  <tr>
    <td width="100" valign="top">CODE_CHARS_COUNT</td>
    <td valign="top"><input name="CODE_CHARS_COUNT" type="text" id="CODE_CHARS_COUNT" size="5" value="<?php echo $CODE_CHARS_COUNT; ?>" /></td>
  </tr>
  <tr>
    <td width="100" valign="top">CODE_LINES_COUNT</td>
    <td valign="top"><input name="CODE_LINES_COUNT" type="text" id="CODE_LINES_COUNT" size="5" value="<?php echo $CODE_LINES_COUNT; ?>" /></td>
  </tr>
  <tr>
    <td width="100" valign="top">CODE_CHAR_COLORS</td>
    <td valign="top"><input name="CODE_CHAR_COLORS" type="text" id="CODE_CHAR_COLORS" size="70" value="<?php echo $CODE_CHAR_COLORS; ?>" /></td>
  </tr>
  <tr>
    <td width="100" valign="top">CODE_LINE_COLORS</td>
    <td valign="top"><input name="CODE_LINE_COLORS" type="text" id="CODE_LINE_COLORS" size="70" value="<?php echo $CODE_LINE_COLORS; ?>" /></td>
  </tr>
  <tr>
    <td width="100" valign="top">CODE_BG_COLOR</td>
    <td valign="top"><input name="CODE_BG_COLOR" type="text" id="CODE_BG_COLOR" value="<?php echo $CODE_BG_COLOR; ?>" /></td>
  </tr>
  <tr>
    <td width="100" valign="top">CODE_ALLOWED_CHARS</td>
    <td valign="top"><input name="CODE_ALLOWED_CHARS" type="text" id="CODE_ALLOWED_CHARS" size="70" value="<?php echo $CODE_ALLOWED_CHARS; ?>" /></td>
  </tr>
  <tr>
    <td width="100" valign="top">PATH_TTF</td>
    <td height="42" valign="top"><input name="PATH_TTF" type="text" id="PATH_TTF" value="<?php echo $PATH_TTF; ?>" size="20" /> 
      <span style="font-style:italic; color:#999999; font-size:12px;">Folder name of the used fonts</span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="right"><input type="submit" name="Submit" value="            Save Changes            " /></td>
  </tr>
</table>
<p>&nbsp;</p>
</form>
<p>&nbsp; </p>
</div>
<?php


?>