<?php
/************* functions to view external media files **********************************/

require_once('data/config.php');
/*************** Havalite data ***********************/
$dbPath = 'data/'.$dbPath;
$db = new PDO('sqlite:'.$dbPath);
/*****************************************************/

// returns array
// $data = should be array with sql values if WHERE statment exists, other wise set ''
function hava_all_queries($SQL, $data = array()){
	if(isset($SQL)){
		global $db;
		$SQL = $db->prepare($SQL);
		if(empty($data)) $SQL->execute();
		else $SQL->execute($data);
		$res = $SQL->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	else return false;
}

// returns single array
// $data = the sql value if WHERE statment exists, other wise set 'all'
// $col = column name
function hava_single_query($SQL, $data, $col=''){
	if(isset($SQL) and isset($data)){
		global $db;
		
		$SQL = $db->prepare($SQL);
		
		if($data == "all") $SQL->execute();
		else $SQL->execute(array($data));
		
		$res = $SQL->fetch(PDO::FETCH_ASSOC);
		
		if($col){ return $res[$col]; }
		else{ return $res; }
	}
	else return false;
}

// check if theme tring to get information about the users pass ----------------
function checkSqlite($SQL){ 
	if (preg_match('/(--|union|users)/', $SQL)){ return true; } 
	else { return false; }
}

// options -----------------------------------------------
function hava_options($opt){
	if(isset($opt)){
		$result = hava_all_queries("SELECT * FROM options WHERE opt = ?", array($opt));
		if($result){
			$res = '';
			foreach($result as $row){ $res = $row['val']; }
			return $res;
		}
	}
}

// $id = image id
// $thumb = true/false to show thumbnail
function showImage($id, $thumb=''){
	$res = '';
	if(isset($id)){	
		$result = hava_single_query("SELECT * FROM images WHERE id = ?", $id);
		if($thumb){ $res = $result['thumb']; }
		else{ $res = $result['data']; }
		if(empty($res)){ $res = file_get_contents("sys/img/wrong.png"); }
		else $res = base64_decode($res);
	}
	return $res;
}

// change HEX value to RGB value ------------------------------------
function HexToRGB($hex) {
	$hex = ereg_replace("#", "", $hex);
	$color = array();
	 
	if(strlen($hex) == 3) {
		$color['r'] = hexdec(substr($hex, 0, 1) . $r);
		$color['g'] = hexdec(substr($hex, 1, 1) . $g);
		$color['b'] = hexdec(substr($hex, 2, 1) . $b);
	}
	else if(strlen($hex) == 6) {
		$color['r'] = hexdec(substr($hex, 0, 2));
		$color['g'] = hexdec(substr($hex, 2, 2));
		$color['b'] = hexdec(substr($hex, 4, 2));
	}
	return $color;
}

// (-50)->(50) or (50)->(-50) -------------------------------------
function recorsive($val){
	if (preg_match('/-\\d+/', $val)) {
		$val = str_replace('-', '', $val);
	} else {
		$val = '-'.$val;
	}
	return $val;
}

?>