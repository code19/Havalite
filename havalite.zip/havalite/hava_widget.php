<?php 
include("hava_head.php");

// Check if table widgets exists
if(!table_exists('widgets')){
	saveSqlite("CREATE TABLE widgets (id INTEGER NOT NULL, name VARCHAR(100), widget TEXT, result TEXT, func VARCHAR(50), active INETEGER(1), PRIMARY KEY (id))");
}

checkWidgets();

// default widgets
function checkWidgets(){
	$widgets = array(
	'Text1' 	=> '<div class="portlet" id="Text1"><div class="portlet-header">Text1</div><div class="portlet-content"><form id="w_text1_form" name="w_text1_form" method="post" action="" onsubmit="return get_args(\'Text1\', 2);">Title:<br /><input type="text" name="w_text1_title" id="arg0" class="w_title" /><br /><textarea name="w_text1_textarea" id="arg1" rows="10" class="w_textarea"></textarea><p id="w_save"><input name="w_text1_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>',
	'Text2' 	=> '<div class="portlet" id="Text2"><div class="portlet-header">Text2</div><div class="portlet-content"><form id="w_text2_form" name="w_text2_form" method="post" action="" onsubmit="return get_args(\'Text2\', 2);">Title:<br /><input type="text" name="w_text2_title" id="arg0" class="w_title" /><br /><textarea name="w_text2_textarea" id="arg1" rows="10" class="w_textarea"></textarea><p id="w_save"><input name="w_text2_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>',
	'Search' 	=> '<div class="portlet" id="Search"><div class="portlet-header">Search</div><div class="portlet-content"><form id="w_text_form" name="w_search_form" method="post" action="" onsubmit="return get_args(\'Search\', 4);">Title:<br /><input type="text" name="w_search_title" id="arg0" class="w_title" />Input Value:<br /><input type="text" name="w_search_input" id="arg1" class="w_title" />Submit Value:<br /><input type="text" name="w_search_submit" id="arg2" class="w_title" />Image:<br /><input type="text" name="w_search_image" id="arg3" class="w_title" /><p id="w_save"><input name="w_text_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>',
	'Links' 	=> '<div class="portlet" id="Links"><div class="portlet-header">Links</div><div class="portlet-content"><form id="w_links_form" name="w_links_form" method="post" action="" onsubmit="return get_args(\'Links\', 1);">Title:<br /><input type="text" name="w_links_title" id="arg0" class="w_title" /><p id="w_save"><input name="w_links_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>',
	'RSS'		=> '<div class="portlet" id="RSS"><div class="portlet-header">RSS</div><div class="portlet-content"><form id="w_rss_form" name="w_rss_form" method="post" action="" onsubmit="return get_args(\'RSS\', 3);">Title: <input type="text" name="w_rss_title" id="arg0" class="w_title" /> Image Url: <input type="text" name="w_rss_image" id="arg1" class="w_title" /><p><label><input name="w_rss_opt" type="radio" id="arg2" value="post" checked="checked" /> latest Posts</label><br /><label><input name="w_rss_opt" type="radio" value="categories" id="arg2" /> Categories</label><br /><label><input name="w_rss_opt" type="radio" value="comments" id="arg2" /> Comments</label><p id="w_save"><input name="w_rss_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>',
	'Post'		=> '<div class="portlet" id="Post"><div class="portlet-header">Recent Post</div><div class="portlet-content"><form id="w_post_form" name="w_post_form" method="post" action="" onsubmit="return get_args(\'Post\', 3);">Title:<br /><input type="text" name="w_post_title" id="arg0" class="w_title" />Written by:<br><input type="text" name="w_post_written" id="arg2" class="w_title" /><p>Posts amount: <input type="text" name="w_post_amount" style="width:38px;" id="arg1" /></p><p id="w_save"><input name="w_post_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>',
	'Categories'=> '<div class="portlet" id="Categories"><div class="portlet-header">Categories</div><div class="portlet-content"><form id="w_categories_form" name="w_categories_form" method="post" action="" onsubmit="return get_args(\'Categories\', 3);">Title: <input type="text" name="w_categories_title" id="arg0" class="w_title" /><p><label><input name="w_categories_menu" id="arg1" type="checkbox"  /> Dropdown menu</label><br /><label><input name="w_categories_amount" id="arg2" type="checkbox" /> View amount of posts</label><p id="w_save"><input name="w_categories_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>',
	'Pages' 	=> '<div class="portlet" id="Pages"><div class="portlet-header">Pages</div><div class="portlet-content"><form id="w_pages_form" name="w_pages_form" method="post" action="" onsubmit="return get_args(\'Pages\', 3);">Title:<br /><input type="text" name="w_pages_title" id="arg0" class="w_title" /> Sort by:<br /><select name="w_pages_sort" id="arg1"><option value="sort">Pages Sort</option><option value="id">Pages ID</option><option value="title">Pages Title</option></select> Written by:<br><input type="text" name="w_pages_written" id="arg2" class="w_title" /><p id="w_save"><input name="w_text_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>',
	'Comments'	=> '<div class="portlet" id="Comments"><div class="portlet-header">Recent Comments</div><div class="portlet-content"><form id="w_comments_form" name="w_comments_form" method="post" action="" onsubmit="return get_args(\'Comments\', 3);">Title:<br /><input type="text" name="w_comments_title" id="arg0" class="w_title" />Written by:<br><input type="text" name="w_comments_written" id="arg2" class="w_title" /><p>Comments amount: <input type="text" name="w_comments_amount" id="arg1" style="width:38px;" /></p><p id="w_save"><input name="w_comments_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>'
	);
	
	$widget_res = array('arg0=&arg1=', 'arg0=&arg1=', 'arg0=&arg1=&arg2=&arg3=', 'arg0=', 'arg0=&arg1=&arg2=', 'arg0=&arg1=&arg2=', 'arg0=&arg1=&arg2=', 'arg0=&arg1=&arg2=', 'arg0=&arg1=&arg2=');
	
	$numKey = array_keys($widgets);
	$numVal = array_values($widgets);
	
	for($i = 0; $i<count($numKey); $i++){
		$w_db = hava_single_query("SELECT * FROM widgets WHERE name = ?", $numKey[$i]);
		if(!$w_db){ saveSqlite("INSERT INTO widgets (name, widget, result, func, active) VALUES (?, ?, ?, ?, ?)", array($numKey[$i], $numVal[$i], $widget_res[$i], $numKey[$i].'_widget', 1)); }
	}
}


?>
<script type="text/javascript" src="sys/jquery/sortable2php/sortable2php.js"></script>
<style>
#column{ width: 250px; float: left; padding: 7px 1px 100px 1px; margin:3px;  border:1px dotted #ccc; background-color:#F5F5FA;  }
#columnTitle{ background-color:#666; margin:4px; padding:3px; display:block; color:#fff; border-radius: 6px; border:1px solid #ccc; font-family:Arial, Helvetica, sans-serif; }
.portlet { margin: 0 6px 6px 6px; border:1px solid #ccc; }
.portlet-header { background-image:url(sys/img/backTop.png); margin: 0.3em; padding-bottom: 4px; padding-left: 4px; padding-top:3px; background-color:#E1E1E1; cursor:move; }
.portlet-header .ui-icon { float: right; }
.portlet-content { padding: 0.4em; display:none; }
.ui-sortable-placeholder { border: 1px dotted black; visibility: visible !important; height: 50px !important; }
.ui-sortable-placeholder * { visibility: hidden; }
.ui-icon, .ui-icon-plusthick { cursor:auto; }
.w_title, .w_textarea, #w_save{ width:97%; }
#w_save{ text-align:right; }
select { width:99%; }
</style>

<script>
$(document).ready( function(){
	
	$('.inactive, .sidebar1, .sidebar2, .sidebar3, .sidebar4').sortable2php('#widgetInfo', 'hava_ajax_response.php?columns=');	

	// UI design ------------------------
	$( ".portlet" ).addClass( "ui-widget ui-widget-content ui-helper-clearfix ui-corner-all" )
		.find( ".portlet-header" )
			.addClass( "ui-widget-header ui-corner-all" )
			.prepend( "<span class='ui-icon ui-icon-plusthick'></span>")
			.end()
		.find( ".portlet-content" );

	$( ".portlet-header .ui-icon" ).click(function() {
		$( this ).toggleClass( "ui-icon-minusthick" ).toggleClass( "ui-icon-plusthick" );
		$( this ).parents( ".portlet:first" ).find( ".portlet-content" ).toggle('blind');
	});
});


function get_args(name, argsNr){
	var res = '';
	var val = '';
	for(var i = 0; i < argsNr; i++){
		val = $("#" + name + " #arg" + i).val();
		if($("#" + name + " #arg" + i).attr("type") == "checkbox") val = $("#" + name + " #arg" + i).attr("checked")?true:false;
		else if($("#" + name + " #arg" + i).attr("type") == "radio") val = $("#" + name + " #arg" + i +":checked").val();
		res += "arg" + i + "=" + val + "&";

	}
	res = res.slice(0,-1);

	
	$.post("hava_ajax_response.php", { w_name: name, w_res: res }, function(data) {
		$("#widgetInfo").text(data); widget_notify();
	});
	
	return false;
}

function widget_notify(){
	$( "#widgetInfo" ).animate({
					backgroundColor: "#666",
					color: "#fff"
				}, 500 );
	setTimeout(function(){
    $( "#widgetInfo" ).animate({
					backgroundColor: "#fff",
					color: "#666"
				}, 3000 );
	},4000);
}

</script>

<div id="admin_index">
<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
	<td width="5" valign="middle"><a href="hava_widget.php"><img src="sys/img/widget.png" border="0" /></a></td>
	<td width="190" valign="middle"><a href="hava_widget.php"><?php echo $hava_lang['widgets1']; ?></a></td>
	<td valign="middle"><span id="widgetInfo" style="font-size:16px; padding:3px 6px; border-radius:15px; "></span></td>

  </tr>
</table>
</div>

<table width="100%" cellspacing="7" id="catTable">
<tr><td>
<?php

$openWidget = '';
if(isset($_GET['widgetName'])){
	echo '<style> #'.$_GET['widgetName'].' .portlet-content { display:block; } </style>';
}
function sortWidgets($sidebar, $all = false){
	global $openWidget; 
	$w_option = hava_options("widgets");
	
	$res = '';
	
	if($all){
		$w_option = preg_replace('/^.+\\|.sidebar1/', '', $w_option);
		$w_db = hava_all_queries("SELECT * FROM widgets WHERE active = ? ORDER BY id", array(1));
		foreach($w_db as $wdb) if(!preg_match('/'.$wdb['name'].'/', $w_option)) $res .= $wdb['widget'];
	}
	else{
		$w_opt = preg_split('/\\|/', $w_option);
		
		for($i =0; $i< count($w_opt); $i++){
			if (preg_match('/'.$sidebar.'\\[/', $w_opt[$i])) {
				$w_opt[$i] = preg_replace('/(\\.\\w+\\[)|(\\])/', '', $w_opt[$i]);
				$w_single = preg_split('/,/', $w_opt[$i]);
				
				for($x = 0; $x < count($w_single); $x++){
					$myWidget = trim($w_single[$x]);
					$wres = hava_single_query("SELECT * FROM widgets WHERE name = ? and active=1", $myWidget, 'widget');
					if(isset($wres)) $res .= $wres;
				}
			}
		}
	}
	return $res;
}



?>

<table align="center" width="50" border="0" cellspacing="0" cellpadding="0">
  <tr align="center">
	<td><span id="columnTitle"><?php echo $hava_lang['inactive']; ?></span></td>
	<td><span id="columnTitle"><?php echo $hava_lang['sidebar']; ?> 1</span></td>
	<td><span id="columnTitle"><?php echo $hava_lang['sidebar']; ?> 2</span></td>
	<td><span id="columnTitle"><?php echo $hava_lang['sidebar']; ?> 3</span></td>
	<td><span id="columnTitle"><?php echo $hava_lang['sidebar']; ?> 4</span></td>
 </tr>
  <tr valign="top">
    <td><div id="column" class="inactive">
	<?php echo sortWidgets("inactive", true); ?>		
	</div>
	</td>
    <td>
	<div id="column" class="sidebar1">
	<?php echo sortWidgets("sidebar1"); ?>		
	</div>
	</td>
    <td>
	<div id="column" class="sidebar2">
	<?php echo sortWidgets("sidebar2"); ?>		
	</div>
	</td>
    <td>
	<div id="column" class="sidebar3">
	<?php echo sortWidgets("sidebar3"); ?>		
	</div>
	</td>
    <td>
	<div id="column" class="sidebar4">
	<?php echo sortWidgets("sidebar4"); ?>		
	</div>
	</td>
  </tr>
</table>

</td>
</tr>
</table>
</div>

<script language="javascript">
$(document).ready( function(){

<?php

function clearJsResult($str){
	$str = str_replace(array("\r\n", "\r", "\n"), '', $str);
	return trim($str);
}



$widgets_results = hava_all_queries("SELECT * FROM widgets");

foreach($widgets_results as $wr){
	if (preg_match('/&/', $wr['result'])) {
		$result = preg_split('/&/', $wr['result']);
		foreach($result as $res){
			$re = preg_split('/=/', $res);
			$re[1] = str_replace($re[0].'=', '', $res);
			$re[1] =str_replace('"', '\"', $re[1]);
			echo clearJsResult('$("#'.$wr['name'].' #'.$re[0].'").val("'.$re[1].'"); ');
		}
	} 
	elseif (preg_match('/=/', $wr['result'])) {
		$re = preg_split('/=/', $wr['result']);
		$re[1] = str_replace($re[0].'=', '', $wr['result']);
		$re[1] =str_replace('"', '\"', $re[1]);
		echo clearJsResult('$("#'.$wr['name'].' #'.$re[0].'").val("'.$re[1].'"); ');
	}
}

?>

});

</script>

<?php 	
/*
$xy = 'xyz';
$$xy = ' Hello';
echo $xyz;
*/
include('hava_foot.php'); 
?>