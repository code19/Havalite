<?php
require_once('data/config.php');
/*************** Havalite data ***********************/
$dbPath = 'data/'.$dbPath;
$db = new PDO('sqlite:'.$dbPath);
/*****************************************************/
$sys_lang = hava_options('language');
if($sys_lang == NULL){ $sys_lang = 'en'; }
require('sys/languages/'.$sys_lang.'.php');

if(isset($_POST['formExec'])) $formExec = $_POST['formExec'];
if(isset($_POST['username'])) $username = $_POST['username'];
if(isset($_POST['userpass'])) $userpass = $_POST['userpass'];
if(isset($_POST['useremail'])) $useremail = $_POST['useremail'];

if(isset($_GET['l'])) $logout = $_GET['l'];
if(isset($_GET['user'])) $user = $_GET['user'];
if(isset($_GET['newkey'])) $newkey = $_GET['newkey'];
$passreset	= false;

newInstall();

$errorword = $hava_lang['error0'];
$msg = '';

if(isset($_POST['resetpassword']) and preg_match('/^[a-z|\\d]{32}$/', $_POST['resetpassword'])){ // Update password after reseting -------------
	if(isset($username, $userpass)){
		if(strlen($userpass)<6){ die('<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><div align="center" style="color:#FF0000;"><h2>'.$hava_lang['passLen'].'</h2>'.$hava_lang['error5'].'</div>'); }
		
		$newpw = $_POST['resetpassword'];
		$SQL = "SELECT * FROM users WHERE pass =?";
		$result = hava_single_query($SQL, $newpw);
		if(checkSqlite($SQL) and $result){
			saveSqlite("UPDATE users SET pass = ? WHERE user = ? and pass=?", array(md5($userpass), $username, $newpw));
			header('location: hava_login.php');
		}
		else header('location: http://mondaynightbrewing.com/wp-content/uploads/2008/02/funny-baby.jpg');
	}
	else header('location: http://mondaynightbrewing.com/wp-content/uploads/2008/02/funny-baby.jpg');
	/*
	*/
}


/**************************** functions **********************************/

// returns array
// $data = should be array with sql values if WHERE statment exists, other wise set ''
function hava_all_queries($SQL, $data = array()){
	if(isset($SQL) and checkSqlite($SQL)){
		global $db;
		$SQL = $db->prepare($SQL);
		if(empty($data)) $SQL->execute();
		else $SQL->execute($data);
		$res = $SQL->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	else return false;
}

// returns single array
// $data = the sql value if WHERE statment exists, other wise set 'all'
// $col = column name
function hava_single_query($SQL, $data, $col=''){
	if(isset($SQL) and isset($data)){
		global $db;
		
		$SQL = $db->prepare($SQL);
		
		if($data == "all") $SQL->execute();
		else $SQL->execute(array($data));
		
		$res = $SQL->fetch(PDO::FETCH_ASSOC);
		
		if($col){ return $res[$col]; }
		else{ return $res; }
	}
	else return false;
}

// save single query to db ----------------------------------------------
function saveSqlite($SQL, $data=array(), $insert=''){
	if(isset($SQL)){
		global $db;
		$res = 'Failed';
		
		$stm = $db->prepare($SQL);
		if($stm->execute($data)){ 
			if($insert){ $res = $db->lastInsertId(); }
			else{ $res = 'Successfull'; }
		}
		
		return $res;
	}
}

// check if theme tring to get information about the users pass ----------------
function checkSqlite($SQL){ 
	if(isset($SQL)){
		if(preg_match('/(--|union)/', $SQL)){ return false; } 
		else { return true; }
	}
	else return false;
}
// Check if New Installation --------------
function newInstall(){
	$chk = hava_single_query("SELECT * FROM users WHERE user = ?", 'admin', "pass");
	if($chk == ''){ header('location: data/install.php'); }
}

// Get options from DB --------------------------------------------------
function hava_options($opt){
	if(isset($opt)){
		$result = hava_all_queries("SELECT * FROM options WHERE opt = ?", array($opt));
		$res = '';
		foreach($result as $row){ $res = $row['val']; }
		return $res;
	}
	else return false;
}
// create a log code ---------------------------------------------------
function createLog(){
	$res = '';
	for($i=0; $i<3; $i++){
		$n = rand(10e16, 10e20);
		$res .= base_convert($n, 10, 36);
	}
	return $res;
}

// sending email by reseting password ----------------------------------
function sendmail($user, $email, $pass){
	$url = hava_options('url');
	$sub = '['.hava_options('title').'] Password Reset';
	
	$mes = '

Someone requested that the password be reset for the following account:

  '.$url.'

Username: '.$user.'

If this was a mistake, just ignore this email and nothing will happen.

To reset your password, visit the following address:

'.$url.'/havalite/hava_login.php?newkey='.$pass.'

';
    
	$mes = htmlspecialchars_decode($mes,ENT_QUOTES);
	$emailUrl = $result = preg_replace('/http[s]*:\/\/(www\\.)*/', '', $url);
	$headers = "From: Havalite <havalite@".$emailUrl.">";
	if(mail($email, "=?utf-8?B?".base64_encode($sub)."?=", $mes, $headers)){  }
}
/*************************** End functions *****************************/



if(isset($logout) and $logout == "logout"){ // Logout and reser log --------------------------------------
	if(isset($user)){

		saveSqlite("UPDATE users SET log = '' WHERE user = ?", array($user));
		setcookie('login', '', 0);
		header('location: hava_login.php');
	}
}
elseif(isset($useremail)){ // Forgot Password, send email to the user ------------------------
	$result = hava_single_query("SELECT * FROM users WHERE user = ? OR email = ?", $useremail);
	if($result){
		sendmail($result['user'], $result['email'], $result['pass']);
	}
}
elseif(isset($newkey)){ // check Reseting password -------------------------------------------
	$reset = hava_single_query("SELECT * FROM users WHERE pass=?", $newkey);
	if($reset){ 
		$username = $reset['user'];
		$passreset = true;
		$errorword = $hava_lang['hello'].' '.$username;
		$msg = "Please insert a new password!";
	}
}
elseif(isset($formExec) and $formExec == 1){ // Check if username and password exist -----------------------
	sleep(1);
	if($username == ""){ $msg = $hava_lang['error1']; }
	elseif($userpass == ""){ $msg = $hava_lang['error2'];}
	elseif($username !="" and $userpass !=""){ 

		$SQL = "SELECT * FROM users WHERE user = ?";
		if(checkSqlite($SQL)){
			$result = hava_single_query("SELECT * FROM users WHERE user = ?", $username);
			if($result){
				if($result['pass'] == md5($userpass)){
					$myLog = createLog();
					
					saveSqlite("UPDATE users SET log = ? WHERE user = ?", array($myLog, $username));
					
					setcookie("login", $myLog);
					header('location: index.php');
				}
				else{ $msg = $hava_lang['error3']; }
			}
		}
	}
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Havalite System - Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0;  user-scalable=0;">

<script type="text/javascript" src="sys/jquery/js/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="sys/jquery/js/jquery-ui-1.8.16.custom.min.js"></script>

</head>
<style>
body { font-family:Arial, Helvetica, sans-serif; color:#333333; }
#log_title { font-size:22px; }
#log_text { font-size:14px; display:block; overflow:hidden; width:75px;}
#all{
	display:block; 
	width:280px; 
	position:absolute; 
	top:19%; left:50%; 
	margin-left:-140px; 

}
#formular { 
	padding:10px; 
	border:1px solid #ccc; 
	background-color:#fff; 
	-webkit-box-shadow: 2px 2px 2px 2px #403d40;
	-moz-box-shadow: 2px 2px 2px 2px #403d40; 
	box-shadow: 2px 2px 2px 2px #403d40; 
	-webkit-border-radius: 7px; 
	-moz-border-radius: 7px; 
	border-radius: 7px; 
}
#underForm, #upperForm{
	margin:19px 0;
	font-size:12px;
}
#underForm a{ text-decoration:none; color:#339966; display:block; padding:5px; }
#underForm a:hover{ color:#999999; }
#upperForm{ display:block;}
#msg{ border:1px solid #ff0000; display:block; padding:9px; background-color:#FFEBE8; -webkit-border-radius: 4px; 
	-moz-border-radius: 4px; 
	border-radius: 4px; 
}
#useremailMsg{border:1px solid #E6DB55; display:block; padding:9px; background-color:#FFFFE0; margin-bottom:12px;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	border-radius: 4px; font-size:12px;
}
#username, #userpass { padding:3px; font-size:16px; width:150px; }
#useremail{ padding:3px; font-size:16px; width:96%; border:1px solid #ccc; }
#submit{ 
	width:100%; 
	height:35px; 
	border:1px solid #ccc; 
	font-size:16px; 
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px; 
	-webkit-box-shadow: 2px #424042;
	-moz-box-shadow: 2px #424042;
	box-shadow: 2px #424042; 
	cursor:pointer;   
}

#submit:hover { background-color:#ccc; color:#666; border:1px solid #fff; }
</style>
<body>

<div id="all">
<div id="upperForm">
<?php
if($msg != ''){ 
?>
<script type="text/javascript"> 
$(document).ready(function(){ 
	$('#msg').effect("bounce", { times:5, distance:38 }, 300); }); 
</script>
	<span id="msg"><b><?php echo $errorword; ?></b>: <?php echo $msg; ?></span>
<?php
}
?>
</div>
<div id="formular">
<?php

if(isset($_GET['passLost'])){ // forgot password -------------------------------------------
?>

<form name="hava_passlost_form" action="hava_login.php" method="post">
<table id="logintable" width="250" border="0" align="center" cellpadding="0" cellspacing="10">
  <tr>
    <td height="76" valign="top" id="log_title"><a href="<?php echo hava_options('url'); ?>"><img src="sys/img/logo72.png" alt="Havalite" width="240" height="61" border="0" id="logo" title="Return Home?" /></a></td>
    </tr>
    <td id="log_text"><span id="useremailMsg"><?php echo $hava_lang['login2']; ?></span><input name="useremail" type="text" id="useremail" value="" /></td>
  </tr>
  <tr>
    <td align="right" valign="bottom"><input id="submit" type="submit" name="Submit2" value="<?php echo $hava_lang['login1']; ?>" /></td>
  </tr>
</table>
</form>

<?php
}
elseif(isset($newkey, $passreset) and $passreset == true){ // reset password -------------------------------------
?>
<form name="reset_form" action="hava_login.php" method="post">
<input type="hidden" name="resetpassword" value="<?php echo $newkey; ?>" />
<table id="logintable" width="250" border="0" align="center" cellpadding="0" cellspacing="10">
  <tr>
    <td height="76" colspan="2" valign="top" id="log_title"><a href="<?php echo hava_options('url'); ?>"><img src="sys/img/logo72.png" alt="Havalite" width="240" height="61" border="0" id="logo" title="Return Home?" /></a></td>
    </tr>
  <tr>
    <td id="log_text" title="<?php echo $hava_lang['username']; ?>"><?php echo $hava_lang['username']; ?></td>
    <td><input name="username" type="text" id="username" value="<?php echo $username; ?>" readonly style="color:#CCCCCC;" /></td>
  </tr>
  <tr>
    <td id="log_text" title="<?php echo $hava_lang['password']; ?>"><?php echo $hava_lang['password']; ?></td>
    <td><input name="userpass" type="password" id="userpass" value="" autofocus="autofocus" /></td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td align="right" valign="bottom"><input id="submit" type="submit" name="Submit2" value="<?php echo $hava_lang['login']; ?>" /></td>
  </tr>
</table>
</form>

<?php
}
else{ // login form ----------------------------------------------------------------------

?>
<form name="hava_login_form" action="hava_login.php" method="post">
<input type="hidden" name="formExec" value="1" />
<table id="logintable" width="250" border="0" align="center" cellpadding="0" cellspacing="10">
  <tr>
    <td height="76" colspan="2" valign="top" id="log_title"><a href="<?php echo hava_options('url'); ?>"><img src="sys/img/logo72.png" alt="Havalite" width="240" height="61" border="0" id="logo" title="Return Home?" /></a></td>
    </tr>
  <tr>
    <td id="log_text" title="<?php echo $hava_lang['username']; ?>"><?php echo $hava_lang['username']; ?></td>
    <td><input name="username" type="text" id="username" value="<?php if(isset($username)) echo $username; ?>" autofocus="autofocus" /></td>
  </tr>
  <tr>
    <td id="log_text" title="<?php echo $hava_lang['password']; ?>"><?php echo $hava_lang['password']; ?></td>
    <td><input name="userpass" type="password" id="userpass" value="<?php if(isset($userpass)) echo $userpass; ?>" /></td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td align="right" valign="bottom"><input id="submit" type="submit" name="Submit2" value="<?php echo $hava_lang['login']; ?>" /></td>
  </tr>
</table>
</form>
<?php
}
?>
</div>
<div id="underForm">
  <p><?php if(!isset($_GET['passLost'], $newkey)) { ?><a href="?passLost=1"><?php echo $hava_lang['error4']; ?></a><?php } ?><a href="<?php echo hava_options('url'); ?>">&#8250;&#8250; <?php echo hava_options('title'); ?></a></p>
  </div>
</div>
</body>
</html>
