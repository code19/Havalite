<!DOCTYPE html>
<html>
<head>
    <title>Havalite CMS - Mobile</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0;  user-scalable=0;">
</head>
<script src="sys/jquery/js/jquery-1.8.2.min.js"></script>
<script>
$(document).ready(function(){
	
	var menu = '#menuHead';
	var menuW = 200;
	var menuH = 440;
	
	$(menu).css({'margin-left':'-'+menuW+'px', 'width': menuW+'px', 'top':'0', 'left':'0', 'position': 'fixed', 'display': 'block', 'z-index': '10000' });
	$(menu + ' span').css({ 'width': (menuW+20) + 'px', 'position':'absolute' });
	$(menu + ' ul li ul').css({'margin-left':'-'+menuH+'px', 'width': menuW+'px', 'position':'absolute' });
	
	$(menu + ' span').toggle( 
		function(){ $(menu).animate({'margin-left':'0px'}, 300); },
		function(){ 
			$(menu).animate({'margin-left':'-'+menuW+'px'}, 300);
			$(menu + ' ul li ul').animate({'margin-left':'-'+menuH+'px'}, 300);
		}
	);
	
	$(menu + ' ul li').click( 
		function(){ 
			$(menu + ' ul li ul').animate({'margin-left':'-'+menuH+'px'}, 0);
			$(this).children('ul').animate({'margin-left':(menuW / 2)+'px'}, 300); 
		}
	);
})
</script>
<script type="text/javascript" src="sys/jquery/iscroll/iscroll.js"></script>
<script type="text/javascript">

var myScroll;
function loaded() {
	myScroll = new iScroll('content');
}

document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);

// Use this for high compatibility (iDevice + Android)
document.addEventListener('DOMContentLoaded', function () { setTimeout(loaded, 200); }, false);

// Use this for iDevice only
//document.addEventListener('DOMContentLoaded', loaded, false);

// Use this if nothing else works
//window.addEventListener('load', setTimeout(function () { loaded(); }, 200), false);

</script>
<style>
body{ font-family: arial; }
#content{ position:absolute; z-index:1; top:0px; bottom:0px; left:0; width:100%; background:#eee; overflow:auto; }
#scroller{ width:94%; margin-left:3%; padding:30px 0; }
#menuHead{ border-right: 1px solid #666; background: #333; color: #fff; font-size: 18px; }
#menuHead #nav{
  padding:0px 14px; line-height:40px; height:40px;
  background: #8F9F41 url(sys/img/havalite48.png) no-repeat; background-position:204px;
  cursor: pointer; display:block; border:1px solid #727E34; box-shadow: 2px 2px 10px 0px #000; 
  border-radius: 0px 18px 20px 0px; font-weight:bold; font-size:20px;
  text-shadow: 0.1em 0.1em 0.2em #727E34; color:#fff;
}
#menuHead ul{ list-style: none; padding: 0 7px; background: #333; }
#menuHead ul li{ margin-bottom:-4px; }

#menuHead li{
	display: block; color:#ccc; border:1px solid #333; cursor:default;
	padding:9px 7px 5px 32px; border-radius: 10px; background-position:8px; background-repeat:no-repeat;
}
#menuHead li:hover{border:1px solid #666; background-color:#2F2F2F; color:#66CCFF;}

#menuHead a:link, #menuHead a:visited, #menuHead a:active{ 
	text-decoration:none; color:#ccc; background-repeat:no-repeat; background-position:-10px;
}
#menuHead a:hover{  color:#66CCFF; }
#menuHead ul li ul{ 
	 margin-top:-34px; box-shadow: 4px 4px 12px 0px #000; padding:6px 6px; 
}

.home{ background:url(Png/Green/Home.png); } .home:hover{ background:url(Png/Blue/Home.png); }
.posts{ background:url(Png/Green/Document_Spreadsheet.png); } .posts:hover{ background:url(Png/Blue/Document_Spreadsheet.png); }
.pages{ background:url(Png/Green/Document_Text.png); }	.pages:hover{ background:url(Png/Blue/Document_Text.png); }
.new{ background:url(Png/Green/Document.png); } .new:hover{ background:url(Png/Blue/Document.png); }
.categories{ background:url(Png/Green/Folder.png); } .categories:hover{ background:url(Png/Blue/Folder.png); }
.comments{ background:url(Png/Green/Bubble4.png); } .comments:hover{ background:url(Png/Blue/Bubble4.png); }
.links{ background:url(Png/Green/Globe.png); } .links:hover{ background:url(Png/Blue/Globe.png); }
.media{ background:url(Png/Green/My_Images.png); } .media:hover{ background:url(Png/Blue/My_Images.png); }
.mFiles{ background: url(Png/Green/Photo.png); } .mFiles:hover{ background: url(Png/Blue/Photo.png); }
.mUpload{ background:url(Png/Green/Upload.png); } .mUpload:hover{ background:url(Png/Blue/Upload.png); }
.mCat{ background:url(Png/Green/Media.png); } .mCat:hover{ background:url(Png/Blue/Media.png); }
.settings{ background:url(Png/Green/Gear.png); } .settings:hover{ background:url(Png/Blue/Gear.png); }
.tools{ background:url(Png/Green/Network.png); } .tools:hover{ background:url(Png/Blue/Network.png); }
.plugins{ background:url(Png/Green/Light.png); } .plugins:hover{ background:url(Png/Blue/Light.png); }
.widgets{ background:url(Png/Green/Stats.png); } .widgets:hover{ background:url(Png/Blue/Stats.png); }
.users{ background:url(Png/Green/Users.png); } .users:hover{ background:url(Png/Blue/Users.png); }
.uNew{ background:url(Png/Green/User.png); } .uNew:hover{ background:url(Png/Blue/User.png); }
.uProfile{ background:url(Png/Green/Woman.png); } .uProfile:hover{ background:url(Png/Blue/Woman.png); }
.logout{ background:url(Png/Green/Standby.png); } .logout:hover{ background:url(Png/Blue/Standby.png); }

</style>
<body>
<div id="menuHead"><span id="nav">Havalite CMS</span><br>
	<ul>
	  <li class="home"><a href="#1">Dashboard</a></li>
	  <li id="posts" class="posts">Posts &raquo;
		  <ul>
			  <li class="pages"><a href="#1">Pages</a></li>
			  <li class="new"><a href="#1">New Post</a></li>
			  <li class="categories"><a href="#1">Categories</a></li>
			  <li class="comments"><a href="#1">Comments</a></li>
			  <li class="links"><a href="#1">Links</a></li>
		  </ul>
	  </li>
	  <li id="media" class="media">Media &raquo;
		  <ul>
			  <li class="mFiles"><a href="#">Media Files</a></li>
			  <li class="mUpload"><a href="#">Media Upload</a></li>
			  <li class="mCat"><a href="#">Media Categories</a></li>
		  </ul>
	  </li>
	  <li class="settings"><a href="#1">Settings</a></li>
	  <li class="tools">Tools &raquo;
		  <ul>
			  <li class="plugins"><a href="#1">Plugins</a></li>
			  <li class="widgets"><a href="#1">Widgets</a></li>
		  </ul>
	  </li>
	  <li class="users">Users &raquo;
		  <ul>
			  <li class="uNew"><a href="#1">New User</a></li>
			  <li class="uProfile"><a href="#1">My Profile</a></li>
		  </ul>
	  </li>
	  <li class="logout"><a href="#1">Log Out</a></li>
	</ul>
</div>

<div id="content"> 
<div id="scroller">
	<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
	<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
	<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
	<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
	<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
	<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
	<form name="form1" method="post" action="">
	  <input type="text" name="textfield">
      <input type="submit" name="Submit" value="Submit">
	</form>
	<p>&nbsp;</p>
</div>
</div>
</body>
</html>
