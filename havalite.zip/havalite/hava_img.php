<?php 
include("hava_head.php"); 

$myCount = $imageCount;
if(isset($_GET['del'])){
	if($userLvl >1) echo "DELETE IS NOT ALLOWED!";
	else{
		$del = $_GET['del'];
		// delete image from folder first
		hava_img_del($del);
		// than from db
		saveSqlite("DELETE FROM images WHERE id = ?", array($del));
	}
}

?>
<script language="javascript">

$(document).ready(function(){
	$("#allpost").tablesorter({widthFixed: true, widgets: ['zebra']} );	}
);
</script>

<div id="admin_index">
<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><img src="sys/img/image.png" width="32" height="32" border="0" /></td>
    <td><a href="hava_img.php"><?php echo $imageCount; ?> <?php echo $hava_lang['images']; ?></a>, <?php echo $imageCatCount; ?> <?php echo $hava_lang['categories']; ?></td>
  </tr>
</table>
</div>


<table id="tablesorter" class="tablesorter" border="0" width="100%">
<thead>
<tr>
	<th width="50" valign="top"><?php echo $hava_lang['images']; ?></th>
	<th valign="top" width="100%"><?php echo $hava_lang['description']; ?></th>
	<th width="76" valign="top"><?php echo $hava_lang['category']; ?></th>
	<th width="50" align="center" valign="top"><?php echo $hava_lang['edit']; ?></th>
</tr>
</thead>
<tbody>
<?php

$fLimit = 0;
if(isset($fpage)) $fLimit = $fpage*$limit_res;

$myCount = hava_num_rows("SELECT * FROM images"); // for down navigation -----------------
$imgRes = hava_all_queries("SELECT * FROM images ORDER BY date DESC LIMIT ".$fLimit.", ".$limit_res);

if(isset($_GET['cat'])){
	$myCount = hava_num_rows("SELECT * FROM images WHERE cat = ?", array($_GET['cat'])); // for down navigation -----------------
	$imgRes = hava_all_queries("SELECT * FROM images WHERE cat = ? ORDER BY date DESC LIMIT ".$fLimit.", ".$limit_res, array($_GET['cat']));
}

$wh ='';
foreach($imgRes as $row){
	$thumb_wh = hava_options('thumbnail');
	if($row['w']){ $wh = '('.$row['w'].'x'.$row['h'].')'; }
	if($row['type'] == 'img'){ 
		$imgSrc = 'img.php?thumb='.$row['id']; 
		
		$imgUrl = hava_options('url').'/havalite/img.php?id='.$row['id'].'&type=x.png';
	}
	else { 
		$imgSrc = 'sys/img/swf_small.png'; 
		$imgUrl = hava_options('url').'/havalite/swf.php?id='.$row['id'].'&type=x.swf';
	}
?>
	<tr>
	<td><a rel="img_group" href="<?php echo $imgUrl; ?>" title="(id = <?php echo $row['id'].', name = '.$row['name'].') ('.$row['w'].'x'.$row['h'].') '.$row['desc']; ?>"><img  src="<?php echo $imgSrc; ?>" border="0" style="max-height:<?php echo hava_options('thumbnail'); ?>px; max-width:<?php echo hava_options('thumbnail'); ?>px;" /></a></td>
	<td><a href="hava_img_upload.php?edit=<?php echo $row['id']; ?>" title="edit"><?php echo $row['name']; ?></a> <span id="small"><?php echo $wh; ?></span><br /><?php if($row['desc']){ echo $row['desc']; } ?> <span id="expl"><?php echo hava_date($row['date']); ?></span></td>
	<td align="center"><a href="?cat=<?php echo $row['cat']; ?>"><?php echo $row['cat']; ?></a></td>
	<td align="center"><span style="display:block;width:60px;"><a href="hava_img_upload.php?edit=<?php echo $row['id']; ?>"><img src="sys/img/editpost.png" border="0" title="<?php echo $hava_lang['edit']; ?>" /></a> &nbsp;
	<a href="#" onclick="zebraConfirm('<?php echo $hava_lang['deleted']; ?><br><br><span style=\'color:red;\'><?php echo $hava_lang['deleted1']; ?></span><br>', '<?php echo $row['name']; ?>', '?del=<?php echo $row['id']; ?>', 'warning', true); return false;"><img src="sys/img/imgDel.png" border="0" /></a></td>
	</tr>
<?php
}
?>

</tbody>
</table>

</div>

<?php include('hava_foot.php'); ?>
