<?php 
include("hava_head.php"); 

if(isset($_POST['find'])) $find = $_POST['find'];
if(isset($_POST['replace'])) $replace = $_POST['replace'];
if(isset($_POST['findOpt'])) $findOpt = $_POST['findOpt'];
$noPermission = '';

function viewFoundPhrase($find, $text){
	$ex = explode(' ', $text);
	$res = '<span style="color:#ccc; font-size:12px;">';
	$find = str_replace('/', '\/', $find);
	$counts = count($ex);
	for($i = 0; $i<$counts; $i++){
		if(isset($ex[$i])){
			if (preg_match('/'.$find.'/', $ex[$i])) {
				@$res .= '<br>...'.htmlentities($ex[$i-1]).' <span style="color:#666;">'.htmlentities($ex[$i]).'</span> '.htmlentities($ex[$i+1]).'... ';
			}
		}
	}
	return $res.'</span>';
}


$result = '<ol>';
if(isset($find)){
	showResults();
}

function showResults(){
	global $find, $findOpt, $replace, $userLvl, $noPermission;
	$result = '<ol>';
	if(isset($find)){
		$findRes = hava_all_queries("SELECT * FROM posts WHERE text LIKE ?", array('%'.$find.'%'));
		foreach($findRes as $row){
			$rowText = $row['text'];
			$result .= '<li><a href="hava_post.php?postId='.$row['id'].'">'.$row['title'].'</a>'.viewFoundPhrase($find, $rowText).'</li>';
			if($findOpt == 'replace'){
				$newText = str_replace($find, $replace, $row['text']);
				if($userLvl <2){ 
					$changes = saveSqlite("UPDATE posts SET text = ? WHERE id = ?", array($newText, $row['id'])); 
				}
				else { $noPermission = ' <span style="color:red">Only Admins are allowed to change content of the database!!!</span>'; }
			}
		}
		$result .= '</ol>';
	}
	return $result;
}
?>


<div id="admin_index">
<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><img src="sys/img/find-replace1.png" width="32" height="32" border="0" /></td>
    <td><?php echo $hava_lang['findReplace'].' '.$noPermission; ?> </td>
  </tr>
</table>
</div>




<table id="catTable" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="350" valign="top" id="catSplitter"><form id="form1" name="form1" method="post" action="">
        Find: 
		<input class="round" name="find" type="text" id="find" style="width:98%;" value="<?php if(isset($find)) echo $find; ?>" />
		Replace:
		<input class="round" name="replace" type="text" id="replace" style="width:98%;" value="<?php if(isset($replace)) echo $replace; ?>" />
		<br />
<br />

		<fieldset class="round"><legend><label><input name="findOpt" type="radio" value="find" checked="checked" />
		Find only</label>
		<label><input name="findOpt" type="radio" value="replace" />Find and Replace</label></legend>
		<span style="display:block; text-align:right; padding:10px 0;">
		<input type="submit" id="submit" name="Submit" value="    Replace in all posts    " style="height:38px;" />
		</span>
		</fieldset>
      </form>
	  <span style="display:block; width:100%; margin-top:19px;"><fieldset  class="round"><legend><strong>Hint</strong>:</legend> You better save your Database before replacing any text to all matches!!!</fieldset> </span></td>
    <td valign="top"><?php echo showResults(); ?></td>
    </tr>
  </table>  
</div>   
</form></td>
</tr>
</table>
</div>







<?php include('hava_foot.php'); ?>