CKEDITOR.plugins.add( 'saveas', {
    
    init: function( editor ) {
        editor.addCommand( 'saveas', {
			exec : function( editor ) {
				editor.updateElement();
				var saveasnew = confirm("Are you sure to save this post as New post?   ");
				if(saveasnew == true){
					$('input[name=postId]').val('new');
					$('#saveDataForm').submit();
				}
			}
		});
		
		editor.ui.addButton( 'Saveas', {
			label: 'Save as new',
			command: 'saveas',
			icon: this.path + 'saveas.png',
			toolbar: 'insert'
		});
    }
});