CKEDITOR.plugins.add( 'previewpage', {
    
    init: function( editor ) {
        editor.addCommand( 'previewpost', {
			exec : function( editor ) {
				editor.updateElement();
				var editor1 = $("#editor1").val();
				var previewlog = "../index.php?p=" + previewid + "&preview=" + previewuser;
				window.open(previewlog);
			}
		});
		
		editor.ui.addButton( 'Previewpage', {
			label: 'Preview Post',
			command: 'previewpost',
			icon: this.path + 'previewpage.png',
			toolbar: 'insert'
		});
    }
});