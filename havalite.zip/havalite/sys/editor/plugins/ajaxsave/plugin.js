CKEDITOR.plugins.add('ajaxsave', {
	init: function(editor) {
		var pluginName = 'ajaxsave';

		editor.addCommand( pluginName, {
			exec : function( editor ) {
				editor.updateElement();
				
				var myPostProp = 0; if($('#postProp1:checked').val() == 1) myPostProp = 1;
				var myPostCom = 0; 	if($('#postComments').attr('checked')) myPostCom = 'on';
				
				if(formSubmission()){
					$.post("hava_post_response.php", {
						postId : $("#postId").val(), 
						postTitle : $("#postTitle").val(), 
						editor1 : $("#editor1").val(), 
						postCat : $("#postCat").val(), 
						postTags : $("#postTags").val(),
						postDesc : $("#postDesc").val(), 
						postAuthor : $("#postAuthor").val(), 
						postProp : myPostProp, 
						postComments : myPostCom, 
						postDate : $("#postDate").val(), 
						postSort : $("#postSort").val(),
						postHeader : $("#postHeader").val(),
						postImg : $("#postImg").val()
					}).done( function(data){
						$("#postId").val(data);
						previewid = data;
						//alert(myPostProp);
						post_notify();
						contentChanged = false;
						CKEDITOR.instances.editor1.resetDirty();
						$('.cke_button_save span').css({ boxShadow:'', backgroundImage: 'url(sys/editor/plugins/ajaxsave/ajaxsave.png)' });
					});
				}
			},
			canUndo : true
		});
		
		editor.ui.addButton('Ajaxsave', {
			label: 'Save Ajax',
			command: pluginName,
			className : 'cke_button_save',
			icon: this.path + 'ajaxsave.png'
		});
	}
});
