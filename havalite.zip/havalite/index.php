<?php 
include("hava_head.php");

hava_db_vacuum();
// check if all options are in the db ---------------
checkOptions();
function checkOptions(){
	$optData = array(
		'title' => 'Havalite',
		'tagline' => 'A new liteweight Content Management System (CMS)',
		'language' => 'en',
		'sysColor' => '#DBEAF9',
		'sysColorLite' => '#FFFFFF',
		'theme' => 'simplepagedesign',
		'url' => '',
		'thumbnail' => '50',
		'limit_res' => '12',
		'page_cat' => 'Static',
		'description' => 'A new liteweight Content Management System (CMS)',
		'date_time' => 'd.M.Y',
		'notEmail' => 'on',
		'editorHeight' => '600',
		'editorMax' => '',
		'filterMax' => '600',
		'post_amount' => '10',
		'notes' => '1',
		'editorConfig' => '',
		'yearMonthCat' => '1',
		'frontPage' => 'page',
		'editorStyles' => '',
		'usersBoard' => 'text',
		'usersLvl' => 'Administrator, Author, Editor, Contributor, Guest',
		'mobile' => 'yes',
		'add_styles' => '#brd_admin{ color:#FF00FF; }',
		'error_page' => 'PAGE NOT FOUND!',
		'widgets' => '',
		'backup' => 'standard',
		'similarPost' => 'on',
		'latestPost' => '1',
		'gravatar' => '40-mm',
		'plugins' => '',
		'post_desc' => '155',
		'imgFolder' => 'images'.subdomain(),
		'keywords' => '',
		'htaccess' => ''
	);
	
	for($i = 0; $i < count($optData); $i++){
		if(key($optData) != ''){
			$chk = hava_single_query("SELECT * FROM options WHERE opt = ?", key($optData));
			if(!$chk){ 
				$SQL = "INSERT INTO options (opt, val) VALUES (?, ?)";
				saveSqlite($SQL, array(key($optData), current($optData)));
			}
			next($optData);
		}
	}
}


// check if main and subdomain exists
function hava_db_manager(){
	global $db_path, $db_sub;
	$db_path = 'data/'.$db_path;
	$db_sub = 'data/'.$db_sub;
	$res = false;
	if(!empty($db_path) and file_exists($db_path)){
		if(!empty($db_sub)) $res = true; 
	}
	return $res;
}


?>


<script src="sys/jquery/zRSSFeed/jquery.zrssfeed.min.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function () {	
	$('.lastFeeds p').rssfeed('http://havalite.com/?feed=rss', {	limit: 6, header:false }); 
});
</script>

<div id="admin_index">
<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><?php echo hava_gravatar($userEmail); ?></td>
    <td><?php echo $hava_lang['hello'].' '.$userName;  ?></td>
  </tr>
</table>
</div>


<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="50%" valign="top">
<div id="start_id"><span id="upperBox">Havalite Informations</span>
	<span id="upgradeMsg">Version</span>
	<p><?php echo $hava_lang['blog']; ?>: 
	<span id="allPostsNav"><a href="hava_all_posts.php"><?php echo $postCount; ?> <?php echo $hava_lang['posts']; ?></a> 
	| <a href="hava_all_posts.php?drafts=1"><?php echo $draftCount; ?> <?php echo $hava_lang['drafts']; ?></a> |  
	<a href="hava_comm.php"><?php echo $commentCount; ?> <?php echo $hava_lang['comments']; ?></a> | 
	<a href="hava_img.php"><?php echo $imageCount; ?> <?php echo $hava_lang['images']; ?></a> </span> </p>
</div>

<div id="start_id">
  <span id="upperBox"><?php echo $hava_lang['sysData']; ?></span>
  <table width="100%" border="0" cellpadding="1" cellspacing="1">
  <tr><td width="50%" valign="top">
  
  <?php 
  $backupOpt = hava_options('backup');
  if($backupOpt == "standard"){
  ?>
  <a href="<?php echo $dbPath; ?>"><img src="sys/img/database.png" width="24" height="24" border="0" /> 
    <?php echo $hava_lang['backup']; ?></a>:  <?php echo substr(filesize($dbPath)/1000000, 0,6); ?> MB  
  
  <?php
  }
  else{
  ?>
    <a href="data/zip.php"><img src="sys/img/zip.png" width="24" height="24" border="0" /> 
    <?php echo $hava_lang['backup']; ?></a>

  <?php
  }
  ?>
  </p>
  <p><a href="#" onclick="openSafeFolder(); return false;"><img src="sys/img/lock.png" width="24" height="24" border="0" /> <?php echo $hava_lang['safe']; ?></a></p>
  <p><a href="http://havalite.com/new_lang.php"><img src="sys/img/earth.png" width="24" height="24" border="0" /> Interface language Creator</a></p>
  
  </td>
  <td valign="top">
  <a href="findReplace.php"><img src="sys/img/find-replace.png" width="24" height="24" border="0" /> <?php echo $hava_lang['findReplace']; ?></a>
  <p><a href="http://havalite.com/howto.html"><img src="sys/img/howto.png" width="24" height="24" border="0" /> <?php echo $hava_lang['howTo']; ?></a></p>  </td>
  </tr>
  </table>
</div>


<div id="start_id" class="lastFeeds">
<span id="upperBox"><?php echo $hava_lang['latestNews']; ?></span>
<p>Loading....</p>
</div></td>
<td valign="top">
<div id="start_id">
<span id="upperBox"><?php echo $hava_lang['userBoard']; ?></span>

  <div style="display:block; padding:5px; width:100%;">
  <form id="form1" name="usersForm" method="post" action="index.php">
    <textarea name="usersMsg" id="usersMsg" style="width:99%; direction:<?php echo $hava_lang['direction']; ?>;"></textarea>
    <?php 
	if(hava_options('usersBoard') == 'html'){ 
	?>
    <div style="display:block; width:100px; text-align:left; float:left; ">
        <img src="sys/jquery/dashboardTS/bold.gif" onClick="textareaTools('bold', 'usersMsg');" style="cursor:pointer;">
        <img src="sys/jquery/dashboardTS/italic.gif" onClick="textareaTools('italic', 'usersMsg');" style="cursor:pointer;">
        <img src="sys/jquery/dashboardTS/link.png" onClick="textareaTools('link', 'usersMsg');" style="cursor:pointer;">
        <img src="sys/jquery/dashboardTS/image.png" onClick="textareaTools('image', 'usersMsg');" style="cursor:pointer;">
    </div>
    <?php 
	} 
	?>
    <div style="text-align:right;">
    <?php if($userLvl<2){ ?><a href="?del=board"><?php echo $hava_lang['deleteBoard']; ?></a> <?php } ?><input type="submit" name="Submit" id="submit" value="    <?php echo $hava_lang['save']; ?>    " />
  	</div>
  </form>
  </div>

<span id="usersBoard">
<?php
$sql = "SELECT * FROM notes WHERE user ='usersBoard'";
$boardNum = hava_num_rows($sql);
if($boardNum < 1){ saveSqlite("INSERT INTO notes (user) VALUES (?)", array('usersBoard')); }
if(isset($_GET['del'])){
	$delBoard = $_GET['del'];
	if($delBoard== 'board'){
		saveSqlite("UPDATE notes SET note='' WHERE user=?", array('usersBoard'));
	}
	else{
		$boardRes = hava_single_query("SELECT * FROM notes WHERE user = ?", 'usersBoard');
		$boardRes = trim($boardRes['note']);
		$boardRes = preg_replace('/<'.$delBoard.'>[\\s\\t\\e\\d\\w\\W]+<\/'.$delBoard.'>/u', '', $boardRes);
		saveSqlite("UPDATE notes SET note=? WHERE user=?", array($boardRes, 'usersBoard'));
	}
}
elseif(isset($_POST['usersMsg'])){ 

	if(hava_options('usersBoard') == 'html'){ $usersMsg = correctQuotes($_POST['usersMsg']);  }
	else{	$usersMsg = htmlentities($_POST['usersMsg']); }
	
	$randTag = str_shuffle('bsmalhrny');
	
	$usersMsg = '<'.$randTag.'><tr title="'.$userName.'"><td width="10" valign="top">'.hava_gravatar($userEmail, 24).'</td><td><i style="color:#ccc">'.$userName.' ('.date('d.m.Y - H:s').')</i><a href="?del='.$randTag.'"><img src="sys/img/del.png" border="0" title="'.$hava_lang['delete'].'" alt="'.$hava_lang['delete'].'"></a><br>'.preg_replace('/\\n/ui', '<br>', $usersMsg).'</td></tr></'.$randTag.'>';
	$usersMsg = $usersMsg.hava_single_query("SELECT * FROM notes WHERE user = ?", 'usersBoard', 'note');
	saveSqlite("UPDATE notes SET note=? WHERE user=?", array($usersMsg, 'usersBoard')); 
}
$boardRes = hava_single_query("SELECT * FROM notes WHERE user = ?", 'usersBoard');
echo '<table>'.recorrectQuotes($boardRes['note']).'</table>';
?>
<!--
  <p>     <a href="http://fusion.google.com/add?source=atgs&feedurl=http%3A//havalite.com/%3Ffeed%3Drss"><img src="http://buttons.googlesyndication.com/fusion/add.gif" border="0" alt="Add to Google"></a>   </p>
  <p><script src="http://www.gmodules.com/ig/ifr?url=http://ralph.feedback.googlepages.com/googlecalendarviewer.xml&amp;synd=open&amp;w=250&amp;h=200&amp;title=&amp;border=%23ffffff%7C3px%2C1px+solid+%23999999&amp;output=js"></script>
  </p>
-->
</span></div></td>
</tr>
</table>
<?php include('hava_foot.php'); ?> 