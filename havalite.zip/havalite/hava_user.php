<?php 
include("hava_head.php"); 

if(isset($_GET['userId'])) $userId = $_GET['userId'];	else $userId = '';
if(isset($_GET['del'])) $delUser = $_GET['del'];

$msg = '';
$update = false;

$userq = array();
if(preg_match('/\\b\\d+\\b/', $userId)){
	$userq = hava_single_query("SELECT * FROM users WHERE id = ?", $userId);
	//$userNick = $userq['user']; 
	//$userRole 	= $userq['lvl'];
	//$user_email = $userq['email'];
	//$user_Name 	= $userq['name'];
	//$userWebsite = $userq['website'];
	//$userInfo 	= $userq['info'];
}	
if(isset($_POST['userNick'])){ 	$userq['user'] 	= $_POST['userNick']; 	$update = true; }
if(isset($_POST['userRole'])) 	$userq['lvl'] 	= $_POST['userRole'];
if(isset($_POST['user_email'])) $userq['email'] = $_POST['user_email'];
if(isset($_POST['user_Name'])) 	$userq['name'] 	= $_POST['user_Name'];
if(isset($_POST['userWebsite'])){ 
	$userq['website'] = $_POST['userWebsite']; 
	$userq['website'] = correctUrl($userq['website']);
}
if(isset($_POST['userInfo'])) $userq['info'] 	= $_POST['userInfo'];
if(isset($_POST['userPass1'])) $userPass1 	= $_POST['userPass1'];
if(isset($_POST['userPass2'])) $userPass2 	= $_POST['userPass2'];
$msg = '';

/************************* Save Update ***********************************/

if($userId == 'new' and $userLvl<3 and isset($userq['user'])){ // New User -------------------------------------------
	
	$checkUser = hava_num_rows("SELECT * FROM users WHERE user = ?", array($userq['user']));
	$checkmail = hava_num_rows("SELECT * FROM users WHERE email = ?", array($userq['email']));

	if($checkUser > 0){ $msg = '<span id="red">'.$hava_lang['userExists'].'</span><br>'.$hava_lang['anotherName'].'!'; } 	// user EXISTS
	elseif($checkmail > 0){ $msg = '<span id="red">'.$hava_lang['mailExists'].'</span><br>'.$hava_lang['anotherEmail'].'!'; }// mail EXISTS
	elseif(!$userq['email']){ $msg = '<span id="red">'.$hava_lang['emailFailed'].'!</span>'; } 									// email NOT given
	elseif(!$userPass1){ $msg = '<span id="red">'.$hava_lang['passFailed'].'!</span>'; } 									// password1 NOT given
	elseif(!$userPass2){ $msg = '<span id="red">'.$hava_lang['pass2Failed'].'!</span>'; } 									// password2 NOT given
	elseif($userPass1 != $userPass2){ $msg = '<span id="red">'.$hava_lang['passNotEqual'].'!</span>'; } 					// password1 != password2
	elseif(strlen($userq['user']) <6){ $msg = '<span id="red">'.$hava_lang['userLen'].'!</span>'; } 								// username LESS than 6
	elseif(strlen($userPass1) <6){ $msg = '<span id="red">'.$hava_lang['passLen'].'!</span>'; } 							// password LESS than 6
	else{ 
		$userPass = md5($userPass1);
		$userInformation = htmlspecialchars($userq['info'], ENT_QUOTES);
		$userId = saveSqlite("INSERT INTO users (user, pass, lvl, email, name, website, info) VALUES (?, ?, ?, ?, ?, ?, ?)", array($userq['user'], $userPass, $userq['lvl'], $userq['email'], $userq['name'], $userq['website'], $userInformation), 1);
		$msg = '<span id="green">'.$hava_lang['userAdded'].'!</span>'; 
	}
}
elseif(($update and $userLvl <2 and isset($userq['user'])) or ($user_id == (isset($_POST['userId'])))){ // Update user Informations from Admin or current user with the same name ----------------
	
	if($userLvl <2){ $lvlRole = " lvl='".$userq['lvl']."',"; } // only admins can change lvl
	else { $lvlRole = ''; }
	
	if(!$userq['email']){ $msg = '<span id="red">'.$hava_lang['emailFailed'].'!</span>'; } // email is always reuired
	else{ 
		$userInformation = htmlspecialchars($userq['info'], ENT_QUOTES);
		if($userPass1 or $userPass2){ // if password is changed
			if($userPass1 != $userPass2){ $msg = '<span id="red">'.$hava_lang['passNotEqual'].'!</span>'; }
			else{ 
				$userPass = md5($userPass1); 
				$userId = saveSqlite("UPDATE users SET pass=?,".$lvlRole." email=?, name=?, website=?, info=? WHERE id = ?", array($userPass, $userq['email'], $userq['name'], $userq['website'], $userInformation, $userId), 1);
			}
		}
		else{ // save without changing password
			$userId = saveSqlite("UPDATE users SET ".$lvlRole." email=?, name=?, website=?, info=? WHERE id = ?", array($userq['email'], $userq['name'], $userq['website'], $userInformation, $userId), 1);
		}
		
	}
}
elseif(isset($delUser) and ($userLvl <2)){ // delete user if userLevel = admin or 1
	if($userLvl == 0){}
	else saveSqlite("DELETE FROM users WHERE id = ?", array($delUser));
}
?>
<script language="javascript">

$(document).ready(function()
{
	$("#allpost").tablesorter({widthFixed: true, widgets: ['zebra']} );	}
);
</script>

<div id="admin_index">
<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><img src="sys/img/users.png" width="32" height="32" border="0" /></td>
    <td><span id="success"><?php echo $hava_lang['users']; ?></span><?php 
		if($userLvl == 'admin'){ ?> (<a href="?userId=new"><?php echo $hava_lang['newUser']; ?></a>)<?php } else { ?> (<a href="?userId=<?php echo $user_id; ?>"><?php echo $hava_lang['profile']; ?></a>) <?php }	?></td>
  </tr>
</table>
</div>
<?php
// Admin or user Profile --------------------------
if(($userId and $userLvl<3) or ($userId == $user_id and $userLvl < 5)){ // or userId == id of logged userName
	
	if(preg_match('/\\b\\d+\\b/', $userId)){
		$userq = hava_single_query("SELECT * FROM users WHERE id = ?", $userId);
	}
?>
<div id="userTable">
<form id="form1" name="form1" method="post" action="?userId=<?php echo $userId; ?>">
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top">&nbsp;</td>
    <td valign="top"><?php if(isset($msg)) echo $msg; ?></td>
  </tr>
  <tr>
    <td width="133" valign="top"><?php echo $hava_lang['username']; ?>:</td>
    <td height="38" valign="top"><input name="userNick" type="text" id="userNick" value="<?php if(isset($userq['user'])) echo $userq['user']; ?>"<?php if($userLvl > 2) { echo 'disabled="disabled"'; } ?> />
      <input name="userId" type="hidden" value="<?php echo $userId; ?>" /> <span id="expl">(<?php echo $hava_lang['required']; ?>)</span></td>
  </tr>
  <tr>
    <td valign="top"><?php echo $hava_lang['role']; ?>:</td>
    <td height="38" valign="top"><select name="userRole" <?php if($userLvl > 1){ ?>disabled="disabled"<?php } ?>> <?php if(isset($userq['lvl'])) echo getUserRole($userq['lvl']); else echo getUserRole(4);  ?>
    </select>
    </td>
  </tr>
  <tr>
    <td valign="top"><?php echo $hava_lang['email']; ?>:</td>
    <td height="38" valign="top"><input name="user_email" type="text" id="user_email" value="<?php if(isset($userq['email'])) echo $userq['email']; ?>" />  <span id="expl">(<?php echo $hava_lang['required']; ?>)</span></td>
  </tr>
  <tr>
    <td valign="top"><?php echo $hava_lang['name']; ?>:</td>
    <td height="45" valign="top"><input name="user_Name" type="text" id="user_Name" value="<?php if(isset($userq['name'])) echo $userq['name']; ?>" /></td>
  </tr>
  <tr>
    <td valign="top"><?php echo $hava_lang['website']; ?>:</td>
    <td height="38" valign="top"><input name="userWebsite" type="text" id="userWebsite" size="30" value="<?php if(isset($userq['website'])) echo $userq['website']; ?>" /></td>
  </tr>
  <tr>
    <td valign="top"><?php echo $hava_lang['info']; ?>:</td>
    <td height="87" valign="top"><textarea name="userInfo" cols="50" id="userInfo"><?php if(isset($userq['info'])) echo $userq['info']; ?></textarea></td>
  </tr>
  <tr>
    <td valign="top"><?php echo $hava_lang['password']; ?>:</td>
    <td valign="top"><input name="userPass1" type="password" id="userPass1" size="12" autocomplete="off"  />  <span id="expl">(<?php echo $hava_lang['required']; ?>)</span></td>
  </tr>
  <tr>
    <td valign="top">&nbsp;</td>
    <td height="50" valign="top"><input name="userPass2" type="password" id="userPass2" size="12" autocomplete="off" /> <span id="expl"><?php echo $hava_lang['password1']; ?></span> <span id="expl">(<?php echo $hava_lang['required']; ?>)</span></td>
  </tr>
  <tr>
    <td valign="top">&nbsp;</td>
    <td valign="top"><input id="submit" type="submit" name="Submit" value="                   save                   " /></td>
  </tr>
  <tr>
    <td valign="top">&nbsp;</td>
    <td valign="top">&nbsp;</td>
  </tr>
</table>
</form>

</div>

<?php
}
else{ // view users table -------------------------
?>

<table id="tablesorter" class="tablesorter" border="0" width="100%">
<thead>
<tr>
	<th width="250" valign="top"><?php echo $hava_lang['users']; ?></th>
	<th width="76" valign="top"><?php echo $hava_lang['name']; ?></th>
	<th valign="top"><?php echo $hava_lang['email']; ?></th>
	<th width="35" align="center" valign="top"><?php echo $hava_lang['delete']; ?></th>
</tr>
</thead>
<tbody>

<?php
	
// Sort all links ---------------------------------------------------
$result = hava_all_queries("SELECT * FROM users LIMIT ".$fpage.", ".$limit_res);
$res = '';
foreach($result as $row){
	$postAmount = hava_num_rows("SELECT * FROM posts WHERE author = ?", array($row['user']));
	$delUser = "<a href=\"\" onclick=\"zebraConfirm('".$hava_lang['deleted']."<br><br><span style=\'color:red;\'>".$hava_lang['deleted1']."</span><br>', '".$row['user']."', '?del=".$row['id']."', 'warning', true); return false;\"><img src=\"sys/img/user_del.png\" border\"0\"></a>";
	if($row['user'] == 'admin'){ $delUser = '<img src="sys/img/admin.png" border"0">'; }
?>
	<tr><td valign="top"><a href="?userId=<?php echo $row['id']; ?>"><?php echo hava_gravatar($row['email']); ?> <?php echo $row['user']; ?></a><br /><span id="expl"><?php echo hava_user_role($row['user']); ?></span></td>
	<td><?php echo $row['name']; ?><br /><a href="hava_all_posts.php?postAuthor=<?php echo $row['user']; ?>" id="itemsCount"><?php echo $postAmount.' '.$hava_lang['posts']; ?></a></td>
	<td valign="top"><a href="mailto:<?php echo $row['email']; ?>"><?php echo $row['email']; ?></a><br /><span id="expl"><?php echo $row['info']; ?></span></td>
	<td align="center"><?php if($userLvl <2){ echo $delUser; } ?></td>
	</tr>
<?php
	}
?>
</tbody>
</table>
<?php
}
?>
</div>




<?php
include('hava_foot.php');
?>