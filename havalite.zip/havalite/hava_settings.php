<?php 
include("hava_head.php"); 

?>
<script type="text/JavaScript">
// save before leaving
var contentChanged = false;
$(window).bind("beforeunload",function(event) {
    if(contentChanged) return "You have unsaved changes";
});

function colorize(div){
	$('#' + div).animate({ 'border-color': '#ff0000', 'background-color' : '#FFE1E8'}, 1000);
	contentChanged = true;
	$('#accordionActive').val($('#accordion').accordion('option', 'active'));
}

function trueSubmit(){ 
	contentChanged = false; 
	return true; 
}

/************************ Themes ***********************************/
function changeThemeImage(){
	var selTheme = $("#theme").val();
	var path = 'themes/' + selTheme + '/' + selTheme + '.png';
	$("#themeImage").attr("src", path);
}

function previewTheme(){
	var selTheme = $("#theme").val();
	var myUrl = '<?php echo hava_options('url'); ?>';
	var path = myUrl + '/?theme=' + selTheme;

	window.open(path, '_blank');
}
/*******************************************************************/

function resetSomeInfo(info){

var toolbarInfo = "['Ajaxsave','Saveas', '-', 'Undo','Redo'], \r\n" +
"['Bold', 'Italic', 'Underline', 'Strike', 'Subscript','Superscript', '-', 'RemoveFormat'], \r\n" +
"['JustifyLeft','JustifyCenter','JustifyRight','JustifyFull'],  \r\n" +
"['NumberedList', 'BulletedList' ,'Outdent','Indent','Blockquote','CreateDiv'],  \r\n" +
"['Print','Templates','Find','Replace','SelectAll'], ['Source', '-', 'Previewpage'], '/', \r\n" +
"['Styles','Format','Font','FontSize'], ['TextColor','BGColor'], ['Link', 'Unlink','Anchor'], \r\n" +
"['Image', 'Flash', 'SpecialChar', 'Table', 'Smiley', 'PageBreak','HorizontalRule'], \r\n" +
"['Maximize', 'ShowBlocks','-','About', 'MediaEmbed']";

var stylesInfo = "{name:'Blue Title',element:'h3',styles:{color:'Blue'}}, \r\n" +
"{name:'Red Title',element:'h3',styles:{color:'Red'}}, \r\n" +
"{name:'Marker: Yellow',element:'span',styles:{'background-color':'Yellow'}}, \r\n" +
"{name:'Marker: Green',element:'span',styles:{'background-color':'Lime'}}, \r\n" +
"{name:'Big',element:'big'}, \r\n" +
"{name:'Small',element:'small'}, \r\n" +
"{name:'Typewriter',element:'tt'}, \r\n" +
"{name:'Computer Code',element:'code'}, \r\n" +
"{name:'Keyboard Phrase',element:'kbd'}, \r\n" +
"{name:'Sample Text',element:'samp'}, \r\n" +
"{name:'Variable',element:'var'}, \r\n" +
"{name:'Deleted Text',element:'del'}, \r\n" +
"{name:'Inserted Text',element:'ins'}, \r\n" +
"{name:'Cited Work',element:'cite'}, \r\n" +
"{name:'Inline Quotation',element:'q'}, \r\n" +
"{name:'Language: RTL',element:'span',attributes:{dir:'rtl'}}, \r\n" +
"{name:'Language: LTR',element:'span',attributes:{dir:'ltr'}}, \r\n" +
"{name:'Image on Left',element:'img',attributes:{style:'padding: 5px; margin-right: 5px',border:'2',align:'left'}}, \r\n" +
"{name:'Image on Right',element:'img',attributes:{style:'padding: 5px; margin-left: 5px',border:'2',align:'right'}} \r\n";

var htacces = "# .htaccess rules for your blog \r\n" +
"Options +FollowSymLinks \r\n" +
"RewriteEngine on \r\n\r\n" +
"# Rewrite posts \r\n" +
"RewriteRule post_(.*)\\.htm$ index.php?p=$1 \r\n\r\n" +
"# Rewrite search \r\n" +
"RewriteRule search/(.*)\\.htm$ index.php?s=$1 \r\n\r\n" +
"# Rewrite for categories. Add more if some category names have more than 3 spaces \r\n" +
"RewriteRule cat/(.*)/$ index.php?cat=$1 \r\n" +
"RewriteRule cat/(.*)+(.*)/$ index.php?cat=$1%20$2 \r\n" +
"RewriteRule cat/(.*)+(.*)+(.*)/$ index.php?cat=$1%20$2%20$3 \r\n\r\n" +
"# Set a specified url in case of ERROR 404 \r\n" +
"ErrorDocument 404 /me/havalite/index.php?p=106 \r\n\r\n" +
"# Hide folders and files such as .htaccess \r\n" +
"Options All -Indexes \r\n" +
"<files .htaccess> \r\n" +
"order allow,deny \r\n" +
"deny from all \r\n" +
"</files>";

	if(info == 'editorConfig'){
		$('#editorConfig').val(toolbarInfo);
		zebraDialog('Editor Configurations has been reseted. Now you can save settings"', 'Reseting Editor Configurations', 'information', false); 
	}
	else if(info == 'editorStyles'){
		$('#editorStyles').val(stylesInfo);
		zebraDialog('Editor Configurations has been reseted. Now you can save settings"', 'Reseting Editor Configurations', 'information', false); 
	}
	else if(info == 'htaccess'){
		$('#htaccess').val(htacces);
		zebraDialog('Saving htaccess will create a .htacces file in your main folder! Now you can save settings"', 'Reseting .htaccess Configurations', 'information', false); 
	}

}

$(document).ready(function() {
	$("#sysColor").colorpicker();
});
</script>
<style>
.evo-pop{ 
-webkit-box-shadow: 3px 3px 10px 0px rgba(36,36,36,1);
-moz-box-shadow: 3px 3px 10px 0px rgba(36,36,36,1);
box-shadow: 3px 3px 10px 0px rgba(36,36,36,1);
border:1px solid #ccc; }
</style>
<title>Havalite CMS v. 1.1.5 - How To </title>
<div id="admin_index">

<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><img src="sys/img/settings.png" width="32" height="32" border="0" /></td>
    <td><span id="success"><?php echo $hava_lang['settings'];  ?></span></td>
  </tr>
</table>
</div>

<form action="hava_settings.php" enctype="multipart/form-data" method="post" name="img_upload" id="img_upload" onsubmit="trueSubmit();">
<input type="hidden" name="accordionActive" id="accordionActive" value="0" />
<div id="accordion" style="margin-top:15px;">
	<div>
		<h3><a href="#"><?php echo $hava_lang['blogInfo']; ?></a></h3>
		<div id="settingsBox">
<table width="100%" border="0" cellspacing="5" cellpadding="0">
    <tr>
      <td width="135" valign="top"><?php echo $hava_lang['blogTitle']; ?>:</td>
      <td height="25" valign="top"><input class="middleInput" name="blogTitle" type="text" id="blogTitle" size="40" value="<?php echo hava_options('title'); ?>"  onChange="colorize('blogTitle');" /> <input name="updateSettings" type="hidden" id="updateSettings" value="update" /></td>
    </tr>
    <tr>
      <td width="135" valign="top"><?php echo $hava_lang['blogUrl']; ?>:</td>
      <td height="28" valign="top"><input class="bigInput" name="blogUrl" type="text" id="blogUrl" size="60" value="<?php echo hava_options('url'); ?>"  onChange="colorize('blogUrl');" /> <span id="expl">*<?php echo $hava_lang['required']; ?></span></td>
    </tr>
    <tr>
      <td width="135" valign="top"><?php echo $hava_lang['tagLine']; ?>:</td>
      <td height="25" valign="top"><input class="bigInput" name="tagLine" type="text" id="tagLine" size="60" value="<?php echo hava_options('tagline'); ?>"  onChange="colorize('tagLine');" />	  </td>
    </tr>
    <tr>
      <td valign="top"><?php echo $hava_lang['description']; ?>:</td>
      <td height="35" valign="top"><input class="bigInput" name="description" type="text" id="description" size="60" value="<?php echo hava_options('description'); ?>"  onchange="colorize('description');" /> 
        <span id="expl"><?php echo $hava_lang['description1']; ?></span></td>
    </tr>

	<tr>
	  <td valign="top"><?php echo $hava_lang['keywords']; ?>:</td>
	  <td valign="top"><textarea name="blogKeywords" id="blogKeywords"  onChange="colorize('blogKeywords');" rows="1" style="padding:3px;;" class="settingsField"><?php echo hava_options('keywords'); ?></textarea></td>
</tr>
	<tr>
      <td height="30" valign="top"><?php echo $hava_lang['relate']; ?>:</td>
      <td height="30" valign="top" style="direction:<?php echo $hava_lang['direction']; ?>; text-align:left;">
        <label><input name="similarPost" type="radio" value="on" <?php if(hava_options('similarPost') == 'on') echo 'checked="checked"'; ?> onChange="colorize('similarPost');" />  <?php echo $hava_lang['yes']; ?> </label>
		<label><input name="similarPost" type="radio" value="off" <?php if(hava_options('similarPost') == 'off') echo 'checked="checked"'; ?> onChange="colorize('similarPost');" />  <?php echo $hava_lang['no']; ?> </label>	</td>
    </tr>  
	<tr>
      <td height="30" valign="top"><?php echo $hava_lang['frontPage']; ?>:</td>
      <td height="30" valign="top" style="direction:<?php echo $hava_lang['direction']; ?>; text-align:left;">
        <label><input name="frontPage" type="radio" value="post" <?php if(hava_options('frontPage') == 'post') echo 'checked="checked"'; ?> onChange="colorize('frontPage');" />  <?php echo $hava_lang['latestPost']; ?> </label>
		<label><input name="frontPage" type="radio" value="page" <?php if(hava_options('frontPage') == 'page') echo 'checked="checked"'; ?> onChange="colorize('frontPage');" />  <?php echo $hava_lang['staticPage']; ?> </label>	</td>
    </tr>
  
	<tr>
	  <td valign="top"><?php echo $hava_lang['postDesc']; ?>:</td>
	  <td valign="top"><input class="smallInput" name="post_desc" type="text" id="post_desc" size="5" value="<?php echo hava_options('post_desc'); ?>"  onchange="colorize('post_desc');" /> <span id="expl"><?php echo $hava_lang['postDesc1']; ?></span></td>
	  </tr>
	
	<tr>
      <td valign="top">&nbsp;</td>
      <td valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td width="135" valign="top"><a href="http://havalite.com/howto.html#settInfo" target="_blank" title="Information Center to Havalite"><img src="sys/img/info.png" border="0" /></a></td>
      <td valign="top"><input id="submit" type="submit" name="Submit" value="       <?php echo $hava_lang['save']; ?>       " /> </td>
    </tr>
	</table>
	  </div>
	</div>
	<div>
		<h3><a href="#"><?php echo $hava_lang['design']; ?></a></h3>
		<div id="settingsBox">
  <table width="100%" border="0" cellspacing="5" cellpadding="0">
    
    <tr>
      <td width="135" valign="top"><?php echo $hava_lang['theme']; ?>:</td>
      <td height="35" valign="top"><select name="theme" id="theme" class="middleSelect" onChange="colorize('theme'); changeThemeImage();">
        <?php echo get_themes(); ?>
      </select>
<?php
// Theme image -------------------
$the_theme = hava_options('theme');
$themeImage = 'themes/'.$the_theme.'/'.$the_theme.'.png';

if(!file_exists($themeImage)){ 
	$themeImage = 'themes/'.$the_theme.'/'.$the_theme.'.PNG';
	if(!file_exists($themeImage)) $themeImage = 'sys/img/wrong.png'; 
}
?> 
<a href="#" onclick="previewTheme(); return false;" title="Preview Theme" style="padding:1px 8px 0 0;" id="submit"><img style="padding-left:10px;" src="sys/img/preview.png" border="0" /></a>
<div id="themeImageDiv">
<img src="<?php echo $themeImage; ?>" id="themeImage" border="0" title="<?php echo hava_options('theme'); ?>" width="150" height="150" /></div></td>
    </tr>
	    <tr>
      <td width="135" valign="top"><?php echo $hava_lang['pagesCat']; ?>:</td>
      <td height="28" valign="top"><select class="middleSelect" name="pagesCat" id="pagesCat" onChange="colorize('pagesCat');">
        <?php 
			echo hava_cat_list($_POST['pagesCat']); 
		?>
      </select> <span id="expl"><?php echo $hava_lang['pagesCat1']; ?></span></td>
    </tr>

        <tr>
      <td valign="top"><?php echo $hava_lang['postAmount']; ?>:</td>
      <td height="28" valign="top"><input class="smallInput" name="postAmount" type="text" id="postAmount" size="5" value="<?php echo hava_options('post_amount'); ?>"  onchange="colorize('postAmount');" />
        <span id="expl"><?php echo $hava_lang['postAmount1']; ?></span></td>
    </tr>

	<tr>
      <td valign="top"><?php echo $hava_lang['dateTime']; ?>:</td>
      <td height="28" valign="top"><input class="smallInput" name="dateTime" type="text" id="dateTime" size="12" value="<?php echo hava_options('date_time'); ?>"  onchange="colorize('dateTime');" /> <span id="expl"><?php echo $hava_lang['dateTime1']; ?></span></td>
    </tr>
	
	<tr>
	  <td valign="top"><?php echo $hava_lang['filter']; ?>:</td>
	  <td height="28" valign="top"><input class="smallInput" name="filterMax" type="text" id="filterMax" size="5" value="<?php echo hava_options('filterMax'); ?>"  onchange="colorize('filterMax');" /> 
	    px <span id="expl"><?php echo $hava_lang['filterMax']; ?></span></td>
	  </tr>
	<tr>
	<tr>
      <td width="135" valign="top"><?php echo $hava_lang['images']; ?> <?php echo $hava_lang['thumbnail']; ?>:</td>
      <td height="28" valign="top"><input class="smallInput" name="thumbnail" type="text" id="thumbnail" size="5" value="<?php echo hava_options('thumbnail'); ?>"  onchange="colorize('thumbnail');" /> px
      <span id="expl"><?php echo $hava_lang['thumbMax']; ?></span></td>
    </tr>
	  <td valign="top"><?php echo $hava_lang['mobile']; ?>:</td>
	  <td height="28" valign="top" style="direction:<?php echo $hava_lang['direction']; ?>; text-align:left;">
	  <label><input name="mobile" type="radio" id="mobile" value="yes" <?php if(hava_options('mobile') == 'yes') echo 'checked="checked"'; ?> onchange="colorize('mobile');" /> <?php echo $hava_lang['yes']; ?></label> 
	  <label><input name="mobile" type="radio" value="no" <?php if(hava_options('mobile') == 'no') echo 'checked="checked"'; ?> onchange="colorize('mobile');" /> <?php echo $hava_lang['no']; ?></label></td>
	  </tr>
	<tr>
	  <td valign="top"><?php echo $hava_lang['errorPage']; ?>:</td>
	  <td valign="top"><textarea name="error_page" id="error_page" class="settingsField" cols="60" style="padding:3px; color:#666;" onchange="colorize('error_page');"><?php echo hava_options('error_page'); ?></textarea></td>
	  </tr>
	<tr>
	<tr>
	  <td valign="top">Gravatar:</td>
	  <td valign="top">

<fieldset class="settingsField">	  
	  <table><tr>
<script language="javascript">
function setgravatar(gr){
	$('#gravatar2').val(gr);
	colorize('gravatar1');
	colorize('gravatar2');
}
	  
</script>
<?php 
// gravatar
$gravIcon = array('mm', 'identicon', 'monsterid', 'wavatar', 'retro');
$optGrav = hava_options('gravatar'); 
$optGrav = preg_split('/-/', $optGrav, 2);
for($i=0; $i<count($gravIcon); $i++){
	if($optGrav[1] != $gravIcon[$i]) echo '<td><a href="#" title="'.$gravIcon[$i].'" onclick="setgravatar(\''.$gravIcon[$i].'\'); ">'.hava_gravatar('havalite@havalite.com', 30, $gravIcon[$i]).'</a></td>';
}
	  ?> <td><input name="gravatar1" type="text" id="gravatar1" class="GravInput" style="width:30px;" value="<?php echo $optGrav[0]; ?>"  onchange="colorize('gravatar1');" /> </td>
		<td><input name="gravatar2" type="text" id="gravatar2" class="GravInput" style="width:90px;" value="<?php echo $optGrav[1]; ?>"  onchange="colorize('gravatar2');" /></td>
		<td><?php echo hava_gravatar('havalite@havalite.com', 30, $optGrav[1], true); ?></td>
	</tr>
	</table>
</fieldset>	  </td>
	  </tr>
	<tr>
      <td valign="top">&nbsp;</td>
      <td valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td width="135" valign="top"><a href="http://havalite.com/howto.html#settDesign" target="_blank" title="Information Center to Havalite"><img src="sys/img/info.png" border="0" /></a></td>
      <td valign="top"><input id="submit" type="submit" name="Submit" value="       <?php echo $hava_lang['save']; ?>       " /></td>
    </tr>
	</table>
		</div>
	</div>
	<div>
		<h3><a href="#"><?php echo $hava_lang['havaSys']; ?></a></h3>
		<div id="settingsBox">
  <table width="100%" border="0" cellspacing="5" cellpadding="0">
	<tr>
      <td width="135" valign="top"><?php echo $hava_lang['sysLang']; ?>:</td>
      <td height="30" valign="top"><select class="middleSelect" name="sysLang" id="sysLang" onChange="colorize('sysLang');">
<?php
$defaultLang = hava_options('language');
$langFolder = 'sys/languages/';

require_once($langFolder.'langList.php');

foreach($lang_list as $key => $value){
	if(file_exists($langFolder.$key.'.php')){
		$selOpt = '';
		if($key == $defaultLang) $selOpt = ' selected="selected"';
		echo '<option value="'.$key.'"'.$selOpt.'>'.$value.'</option>';
	}
}

?>
</select> </td>
    </tr>
        
<tr>
	  <td valign="top">System Color:</td>
	  <td valign="top"><input class="smallInput" name="sysColor" type="text" id="sysColor" size="7" onchange="colorize('sysColor');" value="<?php echo hava_options('sysColor'); ?>" /> </td>
	  </tr>
    <tr>
      <td valign="top"><?php echo $hava_lang['limit']; ?>:</td>
      <td height="30" valign="top"><input class="smallInput" name="limitResults" type="text" id="limitResults" size="5" value="<?php echo hava_options('limit_res'); ?>"  onchange="colorize('limitResults');" />
        <span id="expl"><?php echo $hava_lang['limit1']; ?></span></td>
    </tr>
    <tr>
      <td width="135" valign="top"><?php echo $hava_lang['notEmail']; ?>:</td>
      <td height="30" valign="top"><label><input name="notEmail" type="checkbox" id="notEmail" onchange="colorize('notEmail');" <?php if(hava_options('notEmail') == 'on') echo 'checked'; ?> /> <span id="expl"><?php echo $hava_lang['notEmail1']; ?></span></label></td>
    </tr>
	<tr>
	  <td valign="top"><?php echo $hava_lang['userBoard']; ?>:</td>
	  <td height="30" valign="top"><label><input name="usersBoard" type="radio" value="html" <?php if(hava_options('usersBoard') == 'html') echo 'checked="checked"'; ?> onchange="colorize('usersBoard');" /> <?php echo $hava_lang['html']; ?></label>
	  <label><input name="usersBoard" type="radio" value="text" <?php if(hava_options('usersBoard') == 'text') echo 'checked="checked"'; ?> onchange="colorize('usersBoard');" /> <?php echo $hava_lang['text']; ?></label>	<span id="expl"><?php echo $hava_lang['userBoard1']; ?></span>  </td>
	  </tr>
	<tr>
	  <td valign="top"><?php echo $hava_lang['members']; ?>:</td>
	  <td height="28" valign="top"><input class="bigInput" name="usersLvl" type="text" id="usersLvl" size="60" onchange="colorize('usersLvl');" value="<?php echo hava_options('usersLvl'); ?>" /></td>
	  </tr>
	<tr>
	  <td valign="top"><?php echo $hava_lang['addStyles']; ?>:</td>
	  <td valign="top"><textarea class="settingsField" name="add_styles" cols="60" id="add_styles" style="padding:3px; color:#CC6699;" onchange="colorize('add_styles');"><?php echo hava_options('add_styles'); ?></textarea></td>
	  </tr>
	<tr>
      <td valign="top"><?php echo $hava_lang['backup1']; ?>:</td>
      <td valign="top" style="direction:<?php echo $hava_lang['direction']; ?>; text-align:left;"><label><input name="backup" type="radio" value="standard" <?php if(hava_options('backup') == 'standard') echo 'checked="checked"'; ?> onchange="colorize('backup');" /> 
      <?php echo $hava_lang['backup2']; ?> <span id="expl"> (<?php echo $hava_lang['backup4']; ?>)</span></label>
	  <label><input name="backup" type="radio" value="zipped" <?php if(hava_options('backup') == 'zipped') echo 'checked="checked"'; ?> onchange="colorize('backup');" /> 
	  <?php echo $hava_lang['backup3']; ?> <span id="expl">(<?php echo $hava_lang['backup5']; ?>)</span></label>  </td>
    </tr>
	
	<tr>
      <td valign="top">&nbsp;</td>
      <td valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td width="135" valign="top"><a href="http://havalite.com/howto.html#settSystem" target="_blank" title="Information Center to Havalite"><img src="sys/img/info.png" border="0" /></a></td>
      <td valign="top"><input id="submit" type="submit" name="Submit" value="       <?php echo $hava_lang['save']; ?>       " /></td>
    </tr>
</table>
	  </div>
	</div>


<div>
<h3><a href="#"><?php echo $hava_lang['editorConfig']; ?></a></h3>
<div id="settingsBox">
  <table width="100%" border="0" cellspacing="5" cellpadding="0">
    <tr>
      <td valign="top"><?php echo $hava_lang['editorHeight']; ?>:</td>
      <td height="30" valign="top"><input class="smallInput" name="editorHeight" type="text" id="editorHeight" size="9" value="<?php echo hava_options('editorHeight'); ?>"  onchange="colorize('editorHeight');" /></td>
    </tr>
    <tr>
      <td width="135" valign="top"><span id="expl"><?php echo $hava_lang['editorConfig1']; ?></span> <a href="http://docs.cksource.com/CKEditor_3.x/Developers_Guide/Toolbar" target="_blank">CKEditor</a></td>
      <td height="30" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="50%" id="linkButton"><?php echo $hava_lang['toolbar']; ?>: <a href="#" onclick="resetSomeInfo('editorConfig'); return false; "><?php echo $hava_lang['reset']; ?> <?php echo $hava_lang['toolbar']; ?></a> <br />
				<textarea  onchange="colorize('editorConfig');" name="editorConfig" rows="9" id="editorConfig" style="padding:3px; color:#CC6699; width:98%;"><?php echo recorrectQuotes(hava_options('editorConfig')); ?></textarea>			</td>
            <td id="linkButton"><?php echo $hava_lang['styles']; ?>: <a href="#" onclick="resetSomeInfo('editorStyles'); return false; "><?php echo $hava_lang['reset']; ?> <?php echo $hava_lang['styles']; ?></a> <br />
			<textarea  onchange="colorize('editorStyles');" name="editorStyles" rows="9" id="editorStyles" style="padding:3px; color:#CC6699; width:100%;"><?php echo recorrectQuotes(hava_options('editorStyles')); ?></textarea>			</td>
          </tr>
        </table></td>
    </tr>
	<tr>
      <td valign="top">Maximuze Editor:</td>
      <td valign="top"><label>
        <input type="checkbox" name="editorMax" id="editorMax" onchange="colorize('editorMax');" <?php if(hava_options('editorMax') == 'on') echo 'checked'; ?> />
      <span id="expl">Always maximize the editor when editing a post</span></label></td>
    </tr>
    <tr>
      <td valign="top">&nbsp;</td>
      <td valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td width="135" valign="top"><a href="http://havalite.com/?p=28" target="_blank" title="Information Center to Havalite"><img src="sys/img/info.png" border="0" /></a></td>
      <td valign="top"><input id="submit" type="submit" name="Submit" value="       <?php echo $hava_lang['save']; ?>       " /></td>
    </tr>
</table>

	</div>
</div>


<div>
<h3><a href="#">.htaccess</a></h3>
<div id="settingsBox">
  <table width="100%" border="0" cellspacing="5" cellpadding="0">
    <tr>
      <td width="135" valign="top"><span id="expl"><?php echo $hava_lang['htaccess']; ?></span> </td>
      <td height="30" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="50%" id="linkButton"><a href="#" onclick="resetSomeInfo('htaccess'); return false; "><?php echo $hava_lang['reset']; ?></a> <br />
				<textarea  onchange="colorize('htaccess');" name="htaccess" rows="9" id="htaccess" style="padding:3px; color:#CC6699; width:98%;"><?php echo recorrectQuotes(stripslashes(hava_options('htaccess'))); ?></textarea>
            </td>
          </tr>
        </table></td>
    </tr>
    <tr>
      <td valign="top">&nbsp;</td>
      <td valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td width="135" valign="top"><a href="https://kb.mediatemple.net/questions/1658/Using+.htaccess+files" target="_blank" title="Information Center to Havalite"><img src="sys/img/info.png" border="0" /></a></td>
      <td valign="top"><input id="submit" type="submit" name="Submit" value="       <?php echo $hava_lang['save']; ?>       " /></td>
    </tr>
</table>

	</div>
</div>

  </form>
</div>
</div>


<?php include('hava_foot.php'); ?> 