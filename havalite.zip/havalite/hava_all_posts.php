<?php 
include("hava_head.php");

// for limiting result according to this page 
$myCount = $postCount;
if(isset($_GET['del'])){
	if($userLvl >1) echo "DELETE IS NOT ALLOWED!";
	else{ hava_all_queries("DELETE FROM posts WHERE id = ?", array($_GET['del'])); }
}
?>

<div id="admin_index">
<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><img src="sys/img/edit.png" border="0" /></td>
    <td><a href="hava_all_posts.php"><?php echo $postCount; ?> <?php echo $hava_lang['posts']; ?>, <?php echo $catCount; ?> <?php echo $hava_lang['categories']; ?></a>  <span id="allPostsNav"><a id="submit" href="hava_all_posts.php?drafts=1"><img src="sys/img/draft.png" border="0" /> <?php echo $draftCount; ?> <?php echo $hava_lang['drafts']; ?></a> | <a id="submit" href="?cat=<?php echo $pagesCat; ?>" title="<?php echo $hava_lang['category']; ?>: <?php echo $pagesCat; ?>"><img src="sys/img/pages.png" border="0" /> <?php echo $pagesCount; ?> <?php echo $hava_lang['pages']; ?></a> | <a id="submit" href="hava_post.php?postId=<?php echo hava_options('latestPost'); ?>"><img src="sys/img/editpost.png" border="0" /> <?php echo $hava_lang['lastEdit']; ?></a></span></td>
  </tr>
</table>
</div>

<table id="tablesorter" class="tablesorter" border="0" width="100%" style="<?php if($hava_lang['direction'] == "rtl") echo 'direction:rtl; text-align:right;'; ?>">
<thead>
<tr>
	<th width="300" height="38"><?php echo $hava_lang['postTitle']; ?></th>
	<th><?php echo $hava_lang['author']; ?></th>
	<th><?php echo $hava_lang['category']; ?></th>
	<th width="27"><?php echo $hava_lang['comments']; ?></th>
	<th><?php echo $hava_lang['keywords']; ?></th>
	<th><?php echo $hava_lang['dateTime']; ?></th>
	<th width="35"><?php echo $hava_lang['property']; ?></th>
	<th width="55" align="center"><?php echo $hava_lang['edit']; ?></th>
</tr>
</thead>
<tbody>
<?php
$order_res = 'date';
$fLimit = 0;
$rposts = '';

if(isset($fpage)) $fLimit = $fpage*$limit_res;

if(isset($_GET['drafts'])){ 
	$rposts = hava_all_queries("SELECT * FROM posts WHERE prop = 0 LIMIT ".$fLimit.", ".$limit_res." "); 
	$myCount = hava_num_rows("SELECT * FROM posts WHERE prop = 0");
}
elseif(isset($_GET['cat'])){ 
	$rposts = hava_all_queries("SELECT * FROM posts WHERE cat = ? ORDER BY ".$order_res." DESC LIMIT ".$fLimit.", ".$limit_res." ", array($_GET['cat'])); 
	$myCount = hava_num_rows("SELECT * FROM posts WHERE cat = ?", array($_GET['cat']));
}
elseif(isset($_GET['postAuthor'])){ 
	$rposts = hava_all_queries("SELECT * FROM posts WHERE author = ? ORDER BY ".$order_res." DESC LIMIT ".$fLimit.", ".$limit_res." ", array($_GET['postAuthor'])); 
	$myCount = hava_num_rows("SELECT * FROM posts WHERE author = ?", array($_GET['postAuthor']));
}
elseif(isset($_POST['search_word'])){ 
	if($_POST['search_post_opt'] == $hava_lang['posts']){ 
		$rposts = hava_all_queries("SELECT * FROM posts WHERE title LIKE ? OR text LIKE ? ORDER BY date DESC LIMIT ".$fLimit.", ".$limit_res." ", array('%'.$_POST['search_word'].'%', '%'.$_POST['search_word'].'%')); 
		$myCount = hava_num_rows("SELECT * FROM posts WHERE title LIKE ? OR text LIKE ?", array('%'.$_POST['search_word'].'%', '%'.$_POST['search_word'].'%'));
	}
	else{
		$rposts = hava_all_queries("SELECT * FROM posts WHERE title LIKE ? ORDER BY date DESC LIMIT ".$fLimit.", ".$limit_res." ", array('%'.$_POST['search_word'].'%')); 
		$myCount = hava_num_rows("SELECT * FROM posts WHERE title LIKE ?", array('%'.$_POST['search_word'].'%'));
	}
}
else{ 
	$rposts = hava_all_queries("SELECT * FROM posts ORDER BY ".$order_res." DESC LIMIT ".$fLimit.", ".$limit_res." "); 
}

foreach($rposts as $row){
	if($row['prop']==1){ $prop = '<span id="green">'.$hava_lang['public'].'</span>'; }
	else { $prop = '<span id="red">'.$hava_lang['draft'].'</span>'; }
?>
<tr>
	<td height="33" valign="top"><a id="postName" href="hava_post.php?postId=<?php echo $row['id']; ?>"><?php echo $row['title']; ?></a></td>
	<td valign="top"><a href="?postAuthor=<?php echo $row['author']; ?>"><?php echo $row['author']; ?></a></td>
	<td valign="top"><a href="?cat=<?php echo $row['cat']; ?>"><?php echo $row['cat']; ?></a></td>
	<td valign="top"><?php echo hava_num_comments($row['id']); ?></td>
	<td valign="top"><?php echo $row['desc']; ?></td>
	<td valign="top"><?php echo $row['date']; ?></td>
	<td valign="top"><?php echo $prop; ?></td>
	<td valign="top"><span style="display:block;width:76px;"><a href="hava_post.php?postId=<?php echo $row['id']; ?>"><img src="sys/img/editpost.png" border="0" title="<?php echo $hava_lang['editPost']; ?>" /></a> &nbsp;
		<a href="../?p=<?php echo $row['id']; ?>&preview=<?php echo $userLog; ?>" target="_blank"><img src="sys/img/preview.png" border="0" title="<?php echo $hava_lang['preview']; ?>" /></a> &nbsp;&nbsp;
		<a href="#" onclick="zebraConfirm('<?php echo $hava_lang['deleted']; ?><br><br><span style=\'color:red;\'><?php echo $hava_lang['deleted1']; ?></span><br>', '<?php echo $row['title']; ?>', '?del=<?php echo $row['id']; ?>', 'warning', true); return false;" ><img src="sys/img/delete.png" border="0" title="<?php echo $hava_lang['delete']; ?>" /></a></span>
	</td>
</tr>
<?php
}

?>
</tbody>
</table>
</div>








<?php include("hava_foot.php"); ?>

