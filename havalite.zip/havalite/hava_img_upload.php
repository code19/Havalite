<?php
include("hava_head.php");

 
//if(isset($_FILES['imageData']['tmp_name'])) $imageData 	= $_FILES['imageData']['tmp_name']; else $imageData = NULL;
if(isset($_POST['imageData'])) $imageData 	= $_POST['imageData']; else $imageData = NULL;
if(isset($_POST['imageName'])) $imageName = $_POST['imageName']; 	else $imageName = NULL;
if(isset($_POST['imageCat'])) $imageCat = $_POST['imageCat'];		else $imageCat = NULL;
if(isset($_POST['imageDesc'])) $imageDesc = $_POST['imageDesc'];	else $imageDesc = NULL;
if(isset($_POST['mediaType'])) $mediaType = $_POST['mediaType'];	else $mediaType = NULL;
if(isset($_POST['yearMonthCat'])) $yearMonthCat = $_POST['yearMonthCat']; else $yearMonthCat = NULL;
if(isset($_POST['updateFile'])) $updateFile	= $_POST['updateFile'];	else $updateFile = NULL; // update media file

if(isset($_GET['edit'])) $edit = $_GET['edit']; 
else $edit = NULL; // Media file in edit mode

$up_message = $hava_lang['mediaUp'];

// Check for GD-Extension -----------------------
function checkGD(){
	$res = 1;
	//Check if GD extension is loaded
	if (!extension_loaded('gd') && !extension_loaded('gd2')) {
		die("GD is not loaded");
		$res = 0;
	}
	return $res;
}

// create | resize function -------------------------------
function resize($img, $w, $h, $newfilename) {
	//Get Image size info
	$imgInfo = getimagesize($img);
	switch ($imgInfo[2]) {
		case 1: $im = imagecreatefromgif($img); break;
		case 2: $im = imagecreatefromjpeg($img);  break;
		case 3: $im = imagecreatefrompng($img); break;
		default:  trigger_error('Unsupported filetype!', E_USER_WARNING);  break;
	}

	//If image dimension is smaller, do not resize
	if ($imgInfo[0] <= $w && $imgInfo[1] <= $h) {
		$nHeight = $imgInfo[1];
		$nWidth = $imgInfo[0];
	}
	else{
		//yeah, resize it, but keep it proportional
		if ($w/$imgInfo[0] > $h/$imgInfo[1]) {
			$nWidth = $w;
			$nHeight = $imgInfo[1]*($w/$imgInfo[0]);
		}
		else{
			$nWidth = $imgInfo[0]*($h/$imgInfo[1]);
			$nHeight = $h;
		}
	}
	$nWidth = round($nWidth);
	$nHeight = round($nHeight);
	
	$newImg = imagecreatetruecolor($nWidth, $nHeight);
	
	/*********** Check if this image is PNG or GIF, then set if Transparent *****************/  
	if($imgInfo[2] == 1){ // gif -----------------
		$newImg = imagecreate($nWidth, $nHeight);
		imagealphablending($newImg, false);
		imagesavealpha($newImg,true);
		$transparent = imagecolorallocatealpha($newImg, 255, 255, 255, 127);
		imagefilledrectangle($newImg, 0, 0, $nWidth, $nHeight, $transparent);
	}
	elseif($imgInfo[2]==2){ // png ----------------
		$newImg = imagecreatetruecolor($nWidth, $nHeight);
	}
	elseif($imgInfo[2]==3){ // png ----------------
		$newImg = imagecreatetruecolor($nWidth, $nHeight);
		imagealphablending($newImg, false);
		imagesavealpha($newImg,true);
		$transparent = imagecolorallocatealpha($newImg, 255, 255, 255, 127);
		imagefilledrectangle($newImg, 0, 0, $nWidth, $nHeight, $transparent);
	}
	
	imagecopyresampled($newImg, $im, 0, 0, 0, 0, $nWidth, $nHeight, $imgInfo[0], $imgInfo[1]);
	
	//Generate the file
	switch ($imgInfo[2]) {
		case 1: imagegif($newImg); break;
		case 2: imagejpeg($newImg);  break;
		case 3: imagepng($newImg); break;
		default:  trigger_error('Failed resize image!', E_USER_WARNING);  break;
	}
	
	
	//Generate the file, and rename it to $newfilename
	//save thumb file (see also down)
	switch ($imgInfo[2]) {
		case 1: imagegif($newImg,$newfilename); break;
		case 2: imagejpeg($newImg,$newfilename);  break;
		case 3: imagepng($newImg,$newfilename); break;
		default:  trigger_error('Failed resize image!', E_USER_WARNING);  break;
	}
	/*
	return $newImg;
	*/
}

// a list of all Cats --------------------------
function imageCatArray(){
	$result = hava_all_queries("SELECT DISTINCT cat FROM images");
	$res = '';
	foreach($result as $row){
		$r = trim($row['cat']);
		if($r != ''){ $res .= '"'.$row['cat'].'",'; }
	}
	return substr($res, 0, -1);
}

function saveImagesCat($name, $desc='', $sort='', $prop=0, $sub='' ){
	$findCat = hava_num_rows("SELECT * FROM images_cat WHERE name = ?", array($name));
	if($findCat < 1){
		saveSqlite("INSERT INTO images_cat (name) VALUES (?)", array($name));
	}
}


if($activeHavalite){
// save media data but keep in a hidden div tag ----------------------------------
	if(isset($imageData) and file_exists('tmp/files/'.$imageData)){	
		//chmod('tmp', 0755);
		// change the option for the cat Name for next time
		saveSqlite("UPDATE options SET val = ? WHERE opt = 'yearMonthCat'", array($yearMonthCat)); 
		
		if($mediaType == 'swf'){
			$swfData = file_get_contents('tmp/files/'.$imageData);
			$saveRes = saveImg($imageName, $imageCat, $imageDesc, $swfData, '', '', '', $mediaType, $updateFile);
			saveImagesCat($imageCat);
			$imgFolder = hava_new_img_folder($imageCat);
			$up_message = $saveRes[0];
			//$edit = $saveRes[1];
			//copy('tmp/thumbnails/'.$imageData, $imgFolder.'/'.$saveRes[1].'_tmb.swf');
			copy('tmp/files/'.$imageData, $imgFolder.'/'.$saveRes[1].'.swf');

			unlink('tmp/files/'.$imageData);
			//unlink('tmp/thumbnails/'.$imageData);
		}
		elseif($mediaType=='img'){
			$size = getimagesize('tmp/files/'.$imageData);
			// Insert to db
			$thumbContent = file_get_contents('tmp/thumbnails/'.$imageData);
			$imageContent = file_get_contents('tmp/files/'.$imageData);
			$saveRes = saveImg($imageName, $imageCat, $imageDesc, $imageContent, $thumbContent, $size[0], $size[1], $mediaType, $updateFile);
			saveImagesCat($imageCat);
			$imgFolder = hava_new_img_folder($imageCat);
			$up_message = $saveRes[0];
			//$edit = $saveRes[1];

			copy('tmp/thumbnails/'.$imageData, $imgFolder.'/'.$saveRes[1].'_tmb.png');
			copy('tmp/files/'.$imageData, $imgFolder.'/'.$saveRes[1].'.png');

			unlink('tmp/thumbnails/'.$imageData);
			unlink('tmp/files/'.$imageData);
		}
	}
	/*
	elseif($updateFile){
		$saveRes = saveImg($imageName, $imageCat, $imageDesc, '', '', '', '', $mediaType, $updateFile); 
		saveImagesCat($imageCat);
		$up_message = $saveRes[0];
		$edit = $updateFile;
	}
	*/
}

// edit mode ------------------------------------
if(isset($edit)){
	$up_message = $hava_lang['edit'].' '.$hava_lang['media'].', id: '.$edit; 
	$editRow = hava_single_query("SELECT * FROM images WHERE id=?", $edit);
	$imageName 	= $editRow['name'];
	$imageCat 	= $editRow['cat'];
	$imageDesc 	= $editRow['desc'];
	$mediaType	= $editRow['type'];

}

?>

<div id="admin_index">
<div id="upper_title">

<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><img src="sys/img/upload.png" width="32" height="32" border="0" /></td>
    <td><span id="success"><?php echo $up_message; ?></span> </td>
  </tr>
</table>

</div>
<?php
if((hava_options('yearMonthCat')==1) and !$imageCat){ $imageCat = date('Y-m'); }

?>
<script language="javascript">

// list of all categories --------------------------------------
var availableTags = [ <?php echo imageCatArray(); ?> ];
$().ready(function() {
	$("#imageCat").autocomplete(availableTags, {
		minChars: 0,
		highlight: false,
		scroll: true,
		scrollHeight: 300
	});
	
});

// Create Cat-Name from Year-Month -------------------------
$(document).ready(function(){
	$('#yearMonthCat').change(function (){
		var x = 1;
		if($('#yearMonthCat').is(':checked')) $('#imageCat').val('<?php echo date('Y-m'); ?>');
		else x='off';
	});
});

//The image name --------------------------
function getImageName(){
	var fullPath = $('#imageData').val(); // document.getElementById('imageData').value;
	var filename = fullPath.replace(/^.*\\/, '');
	var imgUpload = '<?php echo $hava_lang['imageUpload']; ?>';
	var swfUpload = '<?php echo $hava_lang['swfUp']; ?>';
	
	if (filename.match(/.(jp[e]*g|png|gif)/i)) {		
		$('input[value=img]').attr('checked', true);
		filename = filename.replace(/.(jp[e]*g|png|gif)/i, "");
		$('#imageName').val(filename); //document.getElementById('imageName').value = filename;
		$('#catTreeTitle').text(imgUpload);
	}
	else if (filename.match(/.swf/i)) {
		$('input[value=swf]').attr('checked', true);
		$('#catTreeTitle').text(swfUpload);
		filename = filename.replace(/.(swf)/i, "");
		$('#imageName').val(filename);
	}
}

function chkMedia(filename){
	var imgUpload = '<?php echo $hava_lang['imageUpload']; ?>';
	var swfUpload = '<?php echo $hava_lang['swfUp']; ?>';
	var thumbPath = 'tmp/thumbnails/';
	var normalPath = 'tmp/files/';
	var low_filename = filename.toLowerCase();
	
	if (low_filename.match(/\.(jp[e]*g|png|gif)/i)) {		
		$('#imageData').val(filename);
		$('input[value=img]').attr('checked', true);
		filename = filename.replace(/.(jp[e]*g|png|gif)/i, "");
		$('#imageName').val(filename); 
		$('#catTreeTitle').text(imgUpload);
		return true;
	}
	else if (low_filename.match(/\.(swf)/i)) {
		$('#imageData').val(filename);
		$('input[value=swf]').attr('checked', true);
		filename = filename.replace(/.(swf)/i, "");
		$('#imageName').val(filename);
		$('#catTreeTitle').text(swfUpload);
		return true;
	}
	else{
		$('#imageData').val('');
		$('#imageName').val('');
		return false;
	}
	/*
	*/
}

function redlight(div, onoff){
	if(onoff) $(div).animate({ 'background-color':'red'}, 800);
	else $(div).animate({ 'background-color':'white'}, 800);
}

// Check if fileds are assigned
function checkFields(){
	var imageDate = $('#imageData').val(); $.trim(imageDate);
	var imageName = $('#imageName').val(); $.trim(imageName);
	var imageCat = $('#imageCat').val(); $.trim(imageCat);
	
	if(imageDate == ""){ redlight('#imageData', true); }
	else redlight('#imageData', false);
	
	if(imageName == ""){ redlight('#imageName', true); }
	else redlight('#imageName', false);

	if(imageCat == ""){ redlight('#imageCat', true); }
	else redlight('#imageCat', false);
	
	if(imageDate == "" || imageName == "" || imageCat == "") return false;
	else return true;	
}

</script>
<table width="100%" cellspacing="7" id="catTable">
<tr>
<td width="400" valign="top" id="catSplitter">

<div id="imgUpload">
<span id="catTreeTitle"><?php echo $hava_lang['imageUpload']; ?></span>
<form action="hava_img_upload.php" enctype="multipart/form-data" method="post" name="img_upload" id="img_upload" onsubmit="return checkFields(); ">
  <table width="100%" border="0" cellspacing="5" cellpadding="0">
    <tr>
      <td colspan="2" id="success"><input type="hidden" name="updateFile" value="<?php echo $edit; ?>" />&nbsp;</td>
    </tr>
    <tr>
      <td width="2%" valign="top"><?php echo $hava_lang['file']; ?></td>
      <td width="98%" valign="top"><input name="imageData" type="text" id="imageData" onblur="checkFields();" /></td>
    </tr>
    <tr>
      <td valign="top"><?php echo $hava_lang['name']; ?>:</td>
      <td valign="top"><input name="imageName" type="text" id="imageName" value="<?php echo $imageName; ?>" onblur="checkFields();" /></td>
    </tr>
    <tr>
      <td valign="top"><?php echo $hava_lang['category']; ?>:</td>
      <td valign="top"><input name="imageCat" type="text" id="imageCat" value="<?php echo $imageCat; ?>" onblur="checkFields();" />
        <input name="yearMonthCat" id="yearMonthCat" type="checkbox" value="1" <?php if(hava_options('yearMonthCat')==1){ echo 'checked="checked"'; } ?> />
        <span style="width:130px; display:block; float:right;">
        <label for="yearMonthCat"><small id="expl"><?php echo $hava_lang['yearMonthCat']; ?></small></label></span>	</td>
    </tr>
    <tr>
      <td valign="top">&nbsp;</td>
      <td height="50" valign="top">
<?php
$chkImg = '';
$chkSwf = '';
if($mediaType == 'swf') $chkSwf = ' checked="checked"';
else $chkImg  = ' checked="checked"';
?>
	  <label style="color:#6666FF; font-weight:bold;"><input name="mediaType" type="radio" value="img"<?php echo $chkImg; ?> /> img</label><br />
	  <label style="color:#FF0000; font-weight:bold;"><input name="mediaType" type="radio" value="swf"<?php echo $chkSwf; ?> /> swf</label>	  </td>
    </tr>
    <tr>
      <td valign="top"><?php echo $hava_lang['description']; ?>:</td>
      <td valign="top"><textarea name="imageDesc" rows="1" id="imageDesc" style="width:95%;"><?php echo $imageDesc; ?></textarea></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right" style="padding-top:12px;"><?php if($edit){ ?><button id="deleteSubmit" onclick="zebraConfirm('<?php echo $hava_lang['deleted']; ?><br><br><span style=\'color:red;\'><?php echo $hava_lang['deleted1']; ?></span><br>', '<?php echo $hava_lang['delete'].' '.$hava_lang['media']; ?>', 'hava_img.php?del=<?php echo $edit; ?>', 'warning', true); return false;"><?php echo $hava_lang['delete'].' '.$hava_lang['media']; ?></button> <?php } ?>
	  <input id="saveSubmit" type="submit" name="Submit" value="<?php if(isset($edit)) echo $hava_lang['update']; else echo $hava_lang['save']; echo ' '.$hava_lang['media']; ?>" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">&nbsp;</td>
    </tr>
  </table>
</form>
</div>
</td>
<td valign="top" style="background-image:url(sys/img/uploadBg.gif); background-position:top left;">
<div id="fileupload">
    <form action="upload.php" method="POST" enctype="multipart/form-data">
        <div class="fileupload-buttonbar">
            <label class="fileinput-button">
                <span><?php echo $hava_lang['addFiles']; ?></span>
                <input type="file" name="files[]" multiple>
            </label>
            <button type="submit" class="start"><?php echo $hava_lang['startUp']; ?></button>
            <button type="reset" class="cancel"><?php echo $hava_lang['cancelUp']; ?></button>
            <button type="button" class="delete"><?php echo $hava_lang['delFiles']; ?></button>
        </div>
    </form>
    <div class="fileupload-content">
        <table class="files"></table>
        <div class="fileupload-progressbar"></div>
    </div>
</div>
<script id="template-upload" type="text/x-jquery-tmpl">
    <tr class="template-upload{{if error}} ui-state-error{{/if}}">
        <td class="preview"></td>
        <td class="name">{{if name}}${name}{{else}}Untitled{{/if}}</td>
        <td class="size">${sizef}</td>
        {{if error}}
            <td class="error" colspan="2">Error:
                {{if error === 'maxFileSize'}}File is too big
                {{else error === 'minFileSize'}}File is too small
                {{else error === 'acceptFileTypes'}}Filetype not allowed
                {{else error === 'maxNumberOfFiles'}}Max number of files exceeded
                {{else}}${error}
                {{/if}}
            </td>
        {{else}}
            <td class="progress"><div></div></td>
            <td class="start"><button>Start</button></td>
        {{/if}}
        <td class="cancel"><button>Cancel</button></td>
    </tr>
</script>
<script id="template-download" type="text/x-jquery-tmpl">
    <tr class="template-download{{if error}} ui-state-error{{/if}}">
        {{if error}}
            <td></td>
            <td class="name">${name}</td>
            <td class="size">${sizef}</td>
            <td class="error" colspan="2">Error:
                {{if error === 1}}File exceeds upload_max_filesize (php.ini directive)
                {{else error === 2}}File exceeds MAX_FILE_SIZE (HTML form directive)
                {{else error === 3}}File was only partially uploaded
                {{else error === 4}}No File was uploaded
                {{else error === 5}}Missing a temporary folder
                {{else error === 6}}Failed to write file to disk
                {{else error === 7}}File upload stopped by extension
                {{else error === 'maxFileSize'}}File is too big
                {{else error === 'minFileSize'}}File is too small
                {{else error === 'acceptFileTypes'}}Filetype not allowed
                {{else error === 'maxNumberOfFiles'}}Max number of files exceeded
                {{else error === 'uploadedBytes'}}Uploaded bytes exceed file size
                {{else error === 'emptyResult'}}Empty file upload result
                {{else}}${error}
                {{/if}}
            </td>
        {{else}}
            <td class="preview">
                {{if thumbnail_url}}
                    <a href="${url}" target="_blank"><img src="${thumbnail_url}"></a>
                {{/if}}
            </td>
            <td class="name">
                <a href="${url}"{{if thumbnail_url}} target="_blank"{{/if}}>${name}</a>
            </td>
            <td class="size">${sizef}</td>
            <td colspan="2"></td>
        {{/if}}
		<td class="start">
            <button onclick="chkMedia('${name}');" class="ui-state-default ui-corner-all" id="database" title="Copy (${name}) to database and delete from folder"><span class="ui-icon ui-icon-arrowstop-1-n"></span></button> 
        </td>
        <td class="delete">
            <button data-type="${delete_type}" data-url="${delete_url}">Delete</button>
        </td>
		
    </tr>
</script>

<script src="sys/jquery/fileupload/jquery.tmpl.min.js"></script>
<script src="sys/jquery/fileupload/jquery.iframe-transport.js"></script>
<script src="sys/jquery/fileupload/jquery.fileupload.js"></script>
<script src="sys/jquery/fileupload/jquery.fileupload-ui.js"></script>
<script language="javascript">

$(function () {
    'use strict';

    // Initialize the jQuery File Upload widget:
    $('#fileupload').fileupload();

    // Load existing files:
    $.getJSON($('#fileupload form').prop('action'), function (files) {
        var fu = $('#fileupload').data('fileupload');
        fu._adjustMaxNumberOfFiles(-files.length);
        fu._renderDownload(files)
            .appendTo($('#fileupload .files'))
            .fadeIn(function () {
                // Fix for IE7 and lower:
                $(this).show();
            });
    });

    // Open download dialogs via iframes,
    // to prevent aborting current uploads:
    $('#fileupload .files').delegate(
        'a:not([target^=_blank])',
        'click',
        function (e) {
            e.preventDefault();
            $('<iframe style="display:none;"></iframe>')
                .prop('src', this.href)
                .appendTo('body');
        }
    );

});
</script>
<?php
/*
if($mediaType == 'img'){
	if($edit){
		$src = 'img.php?id='.$edit;
		$src_thumb = 'img.php?thumb='.$edit;
	}
	else{
		$timeForm = date('Hms');
		$src = 'tmp/middle.png?date='.$timeForm;
		$src_thumb = 'tmp/thumb.png?date='.$timeForm;
	}
?>
 <img src="<?php echo $src; ?>" border="0" /> <img src="<?php echo $src_thumb; ?>" border="0" />
<?php
}
elseif($mediaType == 'swf'){
?>
<img src="sys/img/swf_big.png" />
<?php
}
*/
?>
</td>
</tr>
</table>
<?php include('hava_foot.php'); ?>
