<?
require_once('hava_func.php');

$height = hava_options('editorHeight');
if($height < 100) $height = 100;

echo " CKEDITOR.editorConfig = function( config ){ ";
echo " config.height = ".$height."; ";
echo " config.ProcessHTMLEntities = true; ";
echo " config.colorButton_enableMore = true; ";
echo " config.extraPlugins = 'onchange'; ";
echo " config.minimumChangeMilliseconds = 100; ";

echo recorrectQuotes(hava_options('editorConfig'));

echo " }; ";
?>
CKEDITOR.addStylesSet('default',
[
<?php
$styleRes = hava_all_queries("SELECT * FROM plugins WHERE state = 1");
foreach($styleRes as $row){
	if($row['style']) echo recorrectQuotes($row['style']);
}
echo recorrectQuotes(hava_options('editorStyles'));
?>
]);
