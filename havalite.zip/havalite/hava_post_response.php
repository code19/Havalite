<?php

require('hava_func.php');
if(isset($_POST['postId'])){
	$postTitle 	= trim($_POST['postTitle']);
	$postText	= correctPost($_POST['editor1']);
	$postCat	= trim($_POST['postCat']);
	$postTags	= $_POST['postTags'];
	$postDesc	= $_POST['postDesc'];
	$postAuthor	= $_POST['postAuthor'];
	$postProp	= $_POST['postProp'];
	$postComments = '0';
	if(isset($_POST['postComments'])) $postComments = $_POST['postComments'];
	$postDate	= $_POST['postDate'];
	$postSort	= $_POST['postSort'];
	$postImg	= $_POST['postImg'];
	$postHeader = correctPost($_POST['postHeader']);
	
	// Check if table cat has this category 
	$catTableAmount	= hava_num_rows("SELECT * FROM cat WHERE name = ?", array($postCat));
	
	if($catTableAmount < 1){ // Add new CAT if not exists ----------------------------
		$thisCatSort = hava_single_query("SELECT * FROM cat ORDER BY sort DESC", 'all', 'sort');
		$thisCatSort++;
		saveSqlite("INSERT INTO cat (name, sort) VALUES (?, ?)", array($postCat, $thisCatSort)); 
	}
	
	if($postComments == 'on') $postComments = 1;
	else $postComments = 0;
			
	if($_POST['postId'] == 'new'){ // Add new post ----------------------------------------
		$SQL = "INSERT INTO posts (title, cat, tags, desc, comments, prop, author, text, date, sort, header, img) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$postData = array(str_replace("'", "&acute;", $postTitle), $postCat, $postTags, $postDesc, $postComments, $postProp, $postAuthor, $postText, $postDate, $postSort, $postHeader, $postImg);
		
		if($postId = saveSqlite($SQL, $postData, '1')){ 
			saveSqlite("UPDATE options SET val = ? where opt = ?", array($postId, "latestPost")); 
			echo $postId;
		}
		//else echo 'Sorry, i could not save to database';
	}
	else { // Update post ----------------------------------------------
		$postId = $_POST['postId'];
		$SQL = "UPDATE posts SET title=?, cat=?, tags=?, desc=?, comments=?, prop=?, author=?, text=?, date=?, sort=?, header=?, img=? WHERE id=?";
		$postData = array(str_replace("'", "&acute;", $postTitle), $postCat, $postTags, $postDesc, $postComments, $postProp, $postAuthor, $postText, $postDate, $postSort, $postHeader, $postImg, $postId);
		
		if(saveSqlite($SQL, $postData)){ 
			saveSqlite("UPDATE options SET val = ? where opt = ?", array($postId, "latestPost"));
			echo $postId;
		}
		//else echo 'Sorry, i could not save to database';
	}
}

?>