<?php
require_once('hava_media.php');

//-----------------------------------------------------------
if(isset($_GET['id'])) 		$id 	= $_GET['id']; 		else $id = NULL;
if(isset($_GET['thumb'])) 	$thumb 	= $_GET['thumb'];	else $thumb = NULL;
if(isset($_GET['name'])) 	$name	= $_GET['name'];	else $name = NULL;
$cat = NULL;
$thumbnail = NULL;

if(isset($name)){ 
	$result = hava_single_query("SELECT * FROM images WHERE name = ?", $name);
	$id = $result['id'];
}

if(isset($id) or isset($thumb)){
	
	if(isset($thumb)) $imgId = $thumb;
	else  $imgId = $id;
	
	$result = hava_single_query("SELECT * FROM images WHERE id = ?", $imgId);
	
	if(!empty($result)){
		$cat = $result['cat'];
		$imgId = $result['id'];
		
		$imgFolder = hava_options('imgFolder');
		$imgFolder = '../'.$imgFolder.'/'.$cat;
		
		if(isset($thumb)) $thumbnail = '_tmb';
		$url = $imgFolder.'/'.$imgId.$thumbnail.'.png';
		
		if(file_exists($url)){ 
			header('location: '.$url);
			//header('Content-Type: image/x-png'); //or whatever
			//readfile($url);
			//die();
		}
		else{
			if(isset($thumb)){ $id = showImage($thumb, 1); }
			else{ $id = showImage($id); }
	
			$im = imagecreatefromstring($id);
			if ($im !== false) {
				
				$filterMax = hava_options('filterMax');
				$width = imagesx($im); 
				$height = imagesy($im);
				header('Content-Type: image/png');
				imagealphablending($im, true); 
				imagesavealpha($im, true);
				imagepng($im);
				imagedestroy($im);
			}
			if(!file_exists($imgFolder)) {
				mkdir($imgFolder, 0755, true);
			}
			$fp = fopen($url,"wb");
			fwrite($fp,$id);
			fclose($fp);
		}
	}
	else{
		//header('location: ../index.php');
	}
}

?>