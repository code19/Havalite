<?php
/***************** KEEP THIS FILE LITE AND SIMPLE *****************/
/***************** Admin file *****************/
require_once('data/config.php');

/***************** Havalite Version ********************/
$version = '1.2.1';
/****************************************************/

$main_folder = 'tmp'; // main folder in which the 2 folders "files" and "thumbnails" exist

/****************** Havalite data ***********************/
$dbPath = 'data/'.$dbPath;
$db = new PDO('sqlite:'.$dbPath);
/*************** Havalite Language ************************/

function brightHex($hex, $diff) {
	$rgb = str_split(trim($hex, '# '), 2);
	 
	foreach ($rgb as &$hex) {
		$dec = hexdec($hex);
		if ($diff >= 0) $dec += $diff;
		else $dec -= abs($diff);	

		$dec = max(0, min(255, $dec));
		$hex = str_pad(dechex($dec), 2, '0', STR_PAD_LEFT);
	}
 
	return '#'.implode($rgb);
}

/***************** save system info *****************/

column_exists('comments', 'block', "ALTER TABLE comments ADD COLUMN block VARCHAR(38)");
column_exists('posts', 'desc', "ALTER TABLE posts ADD COLUMN desc VARCHAR(255)");
column_exists('posts', 'header', "ALTER TABLE posts ADD COLUMN header TEXT");
column_exists('posts', 'img', "ALTER TABLE posts ADD COLUMN img VARCHAR(255)");

if(isset($_POST['updateSettings']) and $_POST['updateSettings'] == 'update'){
	if(isset($_POST['notEmail'])) $notEmail = $_POST['notEmail']; else $notEmail = '';	
	if(isset($_POST['editorMax'])) $editorMax = $_POST['editorMax']; else $editorMax = '';	
	$optUpdata = array(
		'title' => $_POST['blogTitle'],
		'tagline' => $_POST['tagLine'],
		'description' => $_POST['description'],
		'url' => $_POST['blogUrl'],
		'theme' => $_POST['theme'],
		'language' => $_POST['sysLang'],
		'page_cat' => $_POST['pagesCat'],
		'thumbnail' => $_POST['thumbnail'],
		'limit_res' => $_POST['limitResults'],
		'date_time' => $_POST['dateTime'],
		'sysColor' => $_POST['sysColor'],
		'sysColorLite' => brightHex($_POST['sysColor'], 24),
		'sysLang' => $_POST['sysLang'],
		'notEmail' => $notEmail,
		'editorMax' => $editorMax,
		'editorHeight' => $_POST['editorHeight'],
		'filterMax' => $_POST['filterMax'],
		'post_amount' => $_POST['postAmount'],
		'editorConfig' => trim($_POST['editorConfig']),
		'editorStyles' => trim($_POST['editorStyles']),
		'frontPage' => $_POST['frontPage'],
		'usersBoard' => $_POST['usersBoard'],
		'usersLvl' => $_POST['usersLvl'],
		'mobile' => $_POST['mobile'],
		'add_styles' => $_POST['add_styles'],
		'error_page' => $_POST['error_page'],
		'backup' => $_POST['backup'],
		'similarPost' => $_POST['similarPost'],
		'gravatar' => $_POST['gravatar1'].'-'.$_POST['gravatar2'],
		'post_desc' => $_POST['post_desc'],
		'keywords' => $_POST['blogKeywords'],
		'htaccess' => $_POST['htaccess']
	);
	
	for($i = 0; $i < count($optUpdata); $i++){
		if(key($optUpdata) != ''){
			
			saveSqlite("UPDATE options SET val = ? WHERE opt = ?", array(correctQuotes(current($optUpdata)), key($optUpdata)));
			next($optUpdata);
		}
	}
	
	// updating cat table for static category
	update_cat($_POST['pagesCat']);
	
	// save info to robots.txt or create new one
	$robotsText = '# Robots for '.$_POST['blogTitle'].' '.$_POST['blogUrl'].'
User-agent: *
Disallow: /havalite/
Sitemap: '.$_POST['blogUrl'];
	
	if(file_exists('../robots.txt')){
		file_put_contents('../robots.txt', $robotsText);
	}
	else{
		$myRobotsFile = fopen('../robots.txt', 'w');
		file_put_contents('../robots.txt', $robotsText);
	}
	
	// save .htaccess file
	if(isset($optUpdata['htaccess'])){
		if(file_exists('../.htaccess')){
			file_put_contents('../.htaccess', $optUpdata['htaccess']);
		}
		else{
			$htaccessFile = fopen('../.htaccess', 'w');
			file_put_contents('../.htaccess', $optUpdata['htaccess']);
		}
	}

	// Save .htaccess files for image folders in tmp/
	$htaccessImgFolder = 'ForceType application/octet-stream
<FilesMatch "(?i)\.(gif|jpe?g|png)$">
  ForceType none
</FilesMatch>';
	
	if(!file_exists('tmp/files/.htaccess')){
		$htaccessFile = fopen('tmp/files/.htaccess', 'w');
		file_put_contents('tmp/files/.htaccess', $htaccessImgFolder);
	}
	if(!file_exists('tmp/thumbnails/.htaccess')){
		$htaccessFile = fopen('tmp/thumbnails/.htaccess', 'w');
		file_put_contents('tmp/thumbnails/.htaccess', $htaccessImgFolder);
	}
}

$sysColor = hava_options('sysColor');
$sysColorLite = hava_options('sysColorLite');
/*******************************************************/

$sys_lang = hava_options('language');
if($sys_lang == NULL) $sys_lang = 'en';
require('sys/languages/'.$sys_lang.'.php');

foreach($hava_lang as $lkey => $lval) $hava_lang[$lkey] = correctQuotes($lval);

function hava_db_vacuum(){
	global $db;
	$db->query('VACUUM');
}


/*****************Login data *********************/
$myCookie = $_COOKIE['login']; $userLvl = ''; $userName = ''; $userEmail = ''; $user_id = ''; $userLog	= '';

if(isset($myCookie)){ 
	$log_data = logData($myCookie);	
	if($log_data == ''){ header('location: hava_login.php'); }
	else{ 
		$userLvl 	= logData($myCookie, 'lvl');
		$userName 	= logData($myCookie, 'user');
		$userEmail 	= logData($myCookie, 'email');
		$user_id 	= logData($myCookie, 'id');
		$userLog 	= logData($myCookie, 'log');
		//if($userName == '') $userName = logData($myCookie, 'user');
	}
}
else{ header('location: hava_login.php'); }
/*************************************************/

currentPath(); // users privileges 

// Comments amount -------------------------------------
$commentCount = hava_num_rows("SELECT * FROM comments");
$commNew = hava_num_rows("SELECT * FROM comments WHERE approved = 0 AND block IS NULL");
if($commNew > 0) $commWait = ' <a href="hava_comm.php"><img src="sys/img/comment16.png" border="0"></a> ';
// Posts amount ---------------------------------------
$postCount = hava_num_rows("SELECT * FROM posts");
$draftCount = hava_num_rows("SELECT * FROM posts WHERE prop=0");
// Pages amount, cat name --------------------------------
$pagesCat = hava_pages_cat();
$pagesCount = hava_num_rows("SELECT * FROM posts WHERE cat = ?", array($pagesCat));
// Images amount ---------------------------------------
$imageCount = hava_num_rows("SELECT * FROM images WHERE type='img'");
// SWF amount ---------------------------------------
$swfCount = hava_num_rows("SELECT * FROM images WHERE type='swf'");
// Images category amount ---------------------------------------
$imageCatCount = hava_num_rows("SELECT DISTINCT cat FROM images");
// Links amount ---------------------------------------
$linkCount = hava_num_rows("SELECT * FROM links");
// Cat amount ------------------------------------------
$catCount = hava_num_rows("SELECT DISTINCT cat FROM posts");
// plugins amount -------------------------------------
$pluginCount = hava_num_rows("SELECT * FROM plugins");
// limit results ---------------------------------------
$limit_res = hava_options('limit_res');
// Theme folder ---------------------------------------
$templateUrl = 'themes/'.hava_options('theme').'/';



/*************** Users Privileges *****************/
function currentPath(){
	global $userLvl;
	
	$currentPath = basename($_SERVER['REQUEST_URI']); 
	$currentPath = explode('.', $currentPath);
	
	switch($currentPath[0]){
		case 'hava_func': header('location: hava_login.php'); break;
		case 'hava_settings': if($userLvl>1) header('location: index.php'); break;
		case 'hava_plugin': if($userLvl>1) header('location: index.php'); break;
		case 'hava_cat': if($userLvl>2) header('location: index.php'); break;
		case 'hava_comm': if($userLvl>3) header('location: index.php'); break;
		case 'hava_link': if($userLvl>3) header('location: index.php'); break;
		case 'hava_post': if($userLvl>4) header('location: index.php'); break;
		case 'hava_all_posts': if($userLvl>4) header('location: index.php'); break;
		case 'hava_img': if($userLvl>4) header('location: index.php'); break;
		case 'hava_img_upload': if($userLvl>4) header('location: index.php'); break;
	}
}

// returns array
// $data = should be array with sql values if WHERE statment exists, other wise set ''
function hava_all_queries($SQL, $data = array()){
	if(isset($SQL)){
		global $db;
		$SQL = $db->prepare($SQL);
		if(empty($data)) $SQL->execute();
		else $SQL->execute($data);
		$res = $SQL->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	else return false;
}


// returns single array
// $data = the sql value if WHERE statment exists, other wise set 'all'
// $col = column name
function hava_single_query($SQL, $data, $col=''){
	if(isset($SQL) and isset($data)){
		global $db;
		
		$SQL = $db->prepare($SQL);
		
		if($data == "all") $SQL->execute();
		else $SQL->execute(array($data));
		
		$res = $SQL->fetch(PDO::FETCH_ASSOC);
		
		if($col){ return $res[$col]; }
		else{ return $res; }
	}
	else return false;
}

// save single query to db ----------------------------------------------
function saveSqlite($SQL, $data=array(), $insert=''){
	global $activeHavalite;
	if(isset($SQL) and checkSqlite($SQL) and $activeHavalite){
		global $db;
		$res = 'Failed';
		
		$stm = $db->prepare($SQL);
		if($stm->execute($data)){ 
			if($insert){ $res = $db->lastInsertId(); }
			else{ $res = 'Successfull'; }
		}
		
		return $res;
	}
}

function table_exists($table){
	global $db;
	$tableExists = (gettype($db->exec("SELECT count(*) FROM $table")) == "integer")?true:false; 
	return $tableExists;
}

function column_exists($table, $column, $sql=''){
	$res = false;
	$col = hava_all_queries("PRAGMA table_info('".$table."')");
	//if(count($col) < 7) saveSqlite("ALTER TABLE cat ADD icon VARCHAR(255)"); 
	for($i=0; $i<count($col); $i++){
		if($col[$i]['name'] == $column) $res = true;
	}
	
	if(!$res and isset($sql)) saveSqlite($sql); 
	else return $res;
}
// check SQL ------------------------------------------------------------
function checkSqlite($SQL){ 
	//if (preg_match('/(--|union)/', $SQL)){ return false; } 
	//else { return true; }
	return true;
}


//------------------------------------------------------------------------
function cleanUrl($url){
	$url = str_replace('http://', '', $url);
	return $url;
}

// Check if the user is logged to preview Drafts -------------------------------
function checkPreview($logData){
	if(isset($logData)){

		$userLog = hava_single_query("SELECT * FROM users WHERE log = ?", $logData, 'log');
		if($userLog) return $userLog;
		else return false;
	}
	else return false;
}

/********************* get number of rows **********************/
// table = posts, cat, options, users, images -------------------
function hava_num_rows($SQL, $data=array()){
	$count = 0;
	if(isset($SQL)){
		$result = hava_all_queries($SQL, $data);
		if($result){
			foreach($result as $row){ $count++; }
		}
		return $count;
	}
}

// The name of the category for static pages --------------------------------
function hava_pages_cat(){
	$result = hava_all_queries("SELECT * FROM cat WHERE prop = 1");
	if($result){
		$res = '';
		foreach($result as $row){ $res = $row['name']; }
		return $res;
	}
}
//--------------------------------------------------------------
function hava_post($id, $col){
	if(isset($id)){
		$result = hava_all_queries("SELECT * FROM posts WHERE id = ?", array($id));
		if($result){
			$res = '';
			foreach($result as $row) { $res = $row[$col]; }
			return $res;
		}
	}
}
/***************** get data for loged in user ***************/
// $log = same as cookie 
// $prop = what kind of information u need (user, name, email, lvl) 
function logData($log, $prop=''){
	if($log != ""){
		$result = hava_all_queries("SELECT * FROM users WHERE log = ?", array($log));
		if($result){
			$res = '';
			foreach($result as $row){ 
				if(!$prop) $res = $row['user'];
				else $res = $row[$prop];
			}
			return $res;
		}
	}
}

/*******************************************************************/
/********************** Read folders *******************************/

// list all themes names from folder themes ---------------------------------------------------------------
function get_themes(){	
	$res = "";
	$default = hava_options('theme');
	
	if($handle = opendir('themes')) {
		while (false !== ($file = readdir($handle))) {
			if ($file != "." && $file != ".." && is_dir('themes/'.$file)) {

				$def = "";
				if($file == $default) $def = ' selected="selected"';
				
				$res .= '<option value="'.$file.'"'.$def.'>'.$file.'</option>';

			}
		}
		closedir($handle);
	}
	return $res;
}

/*******************************************************************/
/*************************** Plugins *******************************/

/*
// list all plugins names from folder plugins --------------------------------------------------------------
function get_plugins(){	
	$res = "";
	
	if ($handle = opendir('plugins')) {
		while (false !== ($file = readdir($handle))) {
			if ($file != "." && $file != ".." && $file != "index.php") {
				$state = 0; $stateWord = 'Deactivated';
				if(plugin_check($file)){ $state = 1; $stateWord = 'Activated'; }
				$info = 'plugins/'.$file.'/info.txt';
				$res .= '<tr><td valign="top">'.$file.'</td><td valign="top"><a href="?plugin='.$file.'" id="plugin_state'.$state.'">'.$stateWord.'</a></td><td valign="top">'.file_get_contents($info).'</td></tr>';
			}
		}
		closedir($handle);
	}
	return $res;
}
*/
// ------------------------------------------------------------------
function plugin_check($plugin){
	if(isset($plugin)){

		$res = hava_single_query("SELECT * FROM plugins WHERE state = 1 AND name = ?", $plugin, 'id');
		if($res > 0){ return $res; }
		else{ return 0;}
	}
}
//---------------------------------------------------------------------

// ----------------------------------------------------------------------


// mark
/************************** Saving Image to db ***********************/
// imageName, imageCategory, imageDescription, image_fileDate, thumbnail_fileDate, width, height, ID by update
function saveImg($name, $cat, $desc, $data, $thumb, $w, $h, $type, $updateFile=''){
	global $db, $hava_lang, $activeHavalite;
	$res = array();
	$date = date("y-m-d H:i:s");
	
	if(!$updateFile){ // Insert new Media file
		$data = base64_encode($data); 
		if($type == 'img'){ $thumb = base64_encode($thumb); }
		$SQL = "INSERT INTO images (name, cat, desc, data, date, thumb, w, h, type) VALUES ('".$name."', '".$cat."', '".$desc."', '".$data."', '".$date."', '".$thumb."', '".$w."', '".$h."', '".$type."')";
	}
	elseif($updateFile){ // update media file
		if($data){
			$data = ", data = '".base64_encode($data)."'"; 
			if($type == 'img'){ $thumb = ", thumb = '".base64_encode($thumb)."'"; }
			else $thumb  =", thumb = ''"; 
			$data = $data.$thumb.", w='".$w."', h='".$h."', type='".$type."' ";
		}
		$SQL = "UPDATE images SET name='".$name."', cat='".$cat."', desc='".$desc."', date='".$date."'".$data." WHERE id='".$updateFile."'";
	}
	
	if($db->exec($SQL) and $activeHavalite==true){  // Success saved
		
		if($updateFile){ $lastId = $updateFile; }
		else { $lastId = $db->lastInsertId(); }
		$res[1] = $lastId;
		if($type == 'swf'){
			$res[0] = $hava_lang['swfUp'].' (name: "<a href="swf.php?name='.$name.'">'.$name.'</a>", id: "<a href="swf.php?id='.$lastId.'">'.$lastId.'</a>") '.$hava_lang['isSaved'].'!'; 
		}
		else { 
			$res[0] = $hava_lang['theImage'].' (name: "<a rel="img_group" href="img.php?name='.$name.'">'.$name.'</a>", id: "<a rel="img_group" href="img.php?id='.$lastId.'">'.$lastId.'</a>", <a rel="img_group" href="img.php?thumb='.$lastId.'">thumb</a>) '.$hava_lang['isSaved'].'!'; 
		}
	}
	else{ $res[0] = $hava_lang['isFailed']." - ".sqlite_error_string(5); } // Failed saving image
	
	return $res;
}

// Sort all image categories ------------------------------------
function hava_img_cat($list){
	$result = hava_all_queries("SELECT DISTINCT cat FROM images ORDER BY cat");
	if($result){
		$res = '';
		if($list == 'datalist'){ 
			foreach($result as $row){ $res .= '<option label="'.$row['cat'].'" value="'.$row['cat'].'" />'; } 
		}
		else{
			foreach($result as $row){ $res .= $row['cat'].' '; } 
		}
		return $res;
	}
}

// find folder of an image
function hava_img_folder($id){
	$imgFolder = hava_options('imgFolder');
	$cat = hava_single_query("SELECT * FROM images WHERE id = ?", $id, 'cat');
	$res = '../'.$imgFolder.'/'.$cat.'/';
	
	return $res;
}

// Create new img folder im folder images --------------------
function hava_new_img_folder($cat){
	$imgFolder = hava_options('imgFolder');
	$imgFolder = '../'.$imgFolder.'/'.$cat;
	if(!file_exists($imgFolder)) {
		mkdir($imgFolder, 0755, true);
	}
	return $imgFolder;
}

// delete image or swf from folder
function hava_img_del($id){
	$imgType = hava_single_query("SELECT * FROM images WHERE id = ?", $id, 'type');
	$image = hava_img_folder($id).$id;
	if($imgType=='img'){ 
		$img = $image.'.png';
		$tmb = $image.'_tmb.png';
	}
	else{
		$img = $image.'.swf'; 
		$tmb = $image.'_tmp.swf';
	}
	
	if(file_exists($img)){
		unlink($img);
		if(file_exists($tmb)) unlink($tmb);
	}
}

/********************************************************/
/******************* Options ****************************/

// Get options from DB 
function hava_options($opt){
	if(isset($opt)){
		$result = hava_all_queries("SELECT * FROM options WHERE opt = ?", array($opt));
		$res = '';
		foreach($result as $row){ $res = $row['val']; }
		return $res;
	}
}


/*******************************************************/
/****************** Category ***************************/
function update_cat($name){
	if(isset($name)){
		global $activeHavalite;
		if($activeHavalite){
			
			saveSqlite("UPDATE cat SET prop = ?", array(0));
			saveSqlite("UPDATE cat SET prop = ? WHERE name = ?", array(1, $name));

		}
	}
}

// Sort all categories 
function hava_cat_list($def){
	$result = hava_all_queries("SELECT * FROM cat ORDER BY name");
	if($result){
		$res = '';	
		foreach($result as $row){ 
			$prop = $row['prop'];
			$sel = '';
			if($prop > 0) $sel = ' selected="selected"';
	
			$res .= '<option value="'.$row['name'].'"'.$sel.'>'.$row['name'].'</option>'; 
		} 
		
		return $res;
	}
}

function hava_cat_array(){
	$result = hava_all_queries("SELECT DISTINCT name FROM cat ORDER BY name");
	if($result){
		$res = '';
		foreach($result as $row){  $res .= '"'.$row['name'].'",';  } 
		$res = substr($res, 0, -1);
		return $res;
	}
}


// Gravatar -------------------------------
function hava_gravatar( $email, $s='', $d='', $class=false) {
	$gOpt = hava_options('gravatar');
	$gOpt = preg_split('/-/', $gOpt);
	if(empty($s)) $s = $gOpt[0];
	if(empty($d)) $d = $gOpt[1];
	if($class) $class = ' class="gravatar" ';

	$url = 'http://www.gravatar.com/avatar/';
	$url .= md5( strtolower( trim( $email ) ) );
	$url .= "?s=".$s."&d=".$d."&r=g";
	$url = '<img id="gravatar" '.$class.' src="' . $url . '" />';
	
	return $url;
}

function correctUrl($url){
	if($url){
		$url = preg_replace('/\/[ ]*$/', '', $url);
		if(!preg_match('/^http[s]*:\/\//', $url)) {
			$url = 'http://'.$url;
		}
		return $url;
	}
}

function correctLines($txt){
	$txt = nl2br($txt);
	$txt = preg_replace('/[\n\r]/', '', $txt);
	$txt = preg_replace('/[\\\]*"/', '&quot;', $txt); // htmlspecialchars($txt, ENT_QUOTES);
	$txt = preg_replace('/[\\\]*\'/', "&acute;", $txt);
	return $txt;
}

function correctQuotes($txt){
	$txt = preg_replace('/[\\\]*"/', '&quot;', $txt); // htmlspecialchars($txt, ENT_QUOTES);
	$txt = preg_replace('/[\\\]*\'/', "&acute;", $txt);
	return $txt;
}

function recorrectQuotes($txt){
	$txt = str_replace('&quot;', '"', $txt); // htmlspecialchars($txt, ENT_QUOTES);
	$txt = str_replace("&acute;", "'", $txt);
	return $txt;
}

function correctPost($txt){
	$txt = preg_replace('/[\\\]*"/', '"', $txt); // htmlspecialchars($txt, ENT_QUOTES);
	$txt = preg_replace('/[\\\]*\'/', "'", $txt);
	$txt = str_replace('&amp;', '&', $txt);
	return $txt;
}


// get date formate as set bei the user --------------------------
// $formate = define own formate or leave empty ------------------
function hava_date($myDate, $formate=''){
	if($formate == ''){ $formate = hava_options('date_time'); }
	$myDate = strtotime($myDate); 
	return date($formate, $myDate);
}
/******************************************************/

/**************** Comments ****************************/

function hava_num_comments($id){
	if(isset($id)){

		$num = hava_num_rows("SELECT * FROM comments WHERE post = ?", array($id));
		return $num;
	}
}

/**************** users levels ****************************/

function hava_user_role($user){
	$role = explode(',', hava_options('usersLvl'));
	$lvl = hava_single_query("SELECT * FROM users WHERE user = ?", $user, "lvl");
	$res = '';
	for($i = 0; $i<count($role); $i++){
		if(($i+1) == $lvl) $res = trim($role[$i]);
	} 
	return $res;
}


// returns options for users Level------------------------------
// $sel = level of selected user
function getUserRole($sel=''){
	$role = explode(',', hava_options('usersLvl'));
	$res = '';
	if(!isset($sel)) $sel = 5;
	for($i = 0; $i<count($role); $i++){
		if(($i+1) == $sel) $res .= '<option value="'.($i+1).'" selected="selected">'.trim($role[$i]).'</option>';
		else $res .= '<option value="'.($i+1).'">'.trim($role[$i]).'</option>';
	} 
	return $res;
}

function read_file_content($url){
	if(extension_loaded('curl')){
		$ch = curl_init();
		$timeout = 5;
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
		$data = curl_exec($ch);
		curl_close($ch);
		if(!empty($data)) return $data;
		else return NULL;
	}
	else return NULL;
}

/* Create a button on your plugin as a link to the widgets area
/* $name = the plugin name
*/
function widget_button($name, $pos = 'right'){
	if(isset($name)) echo '<div style="position:absolute; top:120px; '.$pos.':50px;"><a href="hava_widget.php?widgetName='.$name.'" title="Add this as a sidebar widget to your theme?"><img src="sys/img/widgetsButton.png" border="0" /></a></div>';
}

/* create meta refresh for your plugin to get to the widget area
/* $name = the plugin name
*/
function widget_redirect($name){
	echo '<meta http-equiv="refresh" content="0;url=hava_widget.php?widgetName='.$name.'"> ';
}

/*********** Widget ****************/
// Name
// Form data
// function name
// arg0, arg1, arg2...
function activateWidget($name, $input, $func, $args){
	global $pluginId;
	
	//$widgetCheck = hava_single_query("SELECT * FROM plugins WHERE id = ?", $pluginId, 'widget');
	$widgetCheck = hava_single_query("SELECT * FROM widgets WHERE name = ?", $name);

	if($widgetCheck==0){
		saveSqlite("UPDATE plugins SET widget =? WHERE id=?", array(1, $pluginId));
	
		$form = '<div class="portlet" id="'.$name.'"><div class="portlet-header">'.$name.'</div><div class="portlet-content"><form id="w_'.$name.'_form" name="w_'.$name.'_form" method="post" action="" onsubmit="return get_args(\''.$name.'\', '.$args.');">'.$input.'<p id="w_save"><input name="w_'.$name.'_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>';
		
		saveSqlite("INSERT INTO widgets (name, widget, func, active) VALUES (?, ?, ?, ?)", array($name, $form, $func, 1));
	}
	elseif($widgetCheck['active']==0){
		$form = '<div class="portlet" id="'.$name.'"><div class="portlet-header">'.$name.'</div><div class="portlet-content"><form id="w_'.$name.'_form" name="w_'.$name.'_form" method="post" action="" onsubmit="return get_args(\''.$name.'\', '.$args.');">'.$input.'<p id="w_save"><input name="w_'.$name.'_save" type="submit" value="Save" id="saveSubmit" /></p></form></div></div>';
		saveSqlite("UPDATE widgets SET widget=?, func=?, active = ? WHERE id=?", array($form, $func, 1, $widgetCheck['id']));
	}
}

function hava_plugins_menu(){
	$pluginOpt = hava_options('plugins');
	$res ='';
	if(!empty($pluginOpt)){
		$menuUp = preg_split('/,/', $pluginOpt);
		foreach($menuUp as $up){
			if(!empty($up)){
				$pluginInfo = hava_single_query("SELECT * FROM plugins WHERE id=?", $up);
				if($pluginInfo['state'] == 1){
					$img = 'sys/img/noimage.gif';
					if(file_exists('plugins/'.$pluginInfo['name'].'/'.$pluginInfo['name'].'.png')) $img = 'plugins/'.$pluginInfo['name'].'/'.$pluginInfo['name'].'.png';
					$res .= '<li><a href="hava_plugin.php?pluginId='.$up.'"><img class="menuPlugins" src="'.$img.'" border="0" /> '.$pluginInfo['name'].'</a></li>';
				}
			}
		}
	}
	return $res;
}

function remove_plugin_menu($offId){
	if(isset($offId)){
		$pluginOpt = hava_options('plugins');
		$pluginOpt = preg_split('/,/', $pluginOpt);
		$res = '';
		foreach($pluginOpt as $up){
			if(!empty($up) and $up != $offId){
				$res .= $up.',';
			}
		}
		saveSqlite("UPDATE options SET val=? WHERE opt =?", array($res, 'plugins'));
	}
}

function hava_plugin_style(){
	$result = hava_all_queries("SELECT * FROM plugins WHERE state = 1 AND style LIKE '%{%'");
	if($result){
		$res = '';
		foreach($result as $row){ $res .= $row['style'].' '; }
		return $res;
	}
}
?>