<?php

$cat = '';
$postAuthor = '';
if(isset($_GET['cat'])) $cat  = '&cat='.$_GET['cat'];
if(isset($_GET['postAuthor'])) $postAuthor  = '&postAuthor='.$_GET['postAuthor'];

$linkRest = $cat.$postAuthor;

if(isset($myCount) and $myCount > $limit_res){
	$divide = ceil($myCount / $limit_res);
	$nextPage = $fpage+1;
	$prevPage = $fpage-1;
	$lastPage = $divide - 1;
	$middleRes = $nextPage.' of '.$divide;  
?> 

<div id="arrowNav">
<?php
if(isset($_GET['pluginId'])){}
else{
echo $myCount.' '.$hava_lang['items']; 
if(!$fpage){
?> 
 <img src="sys/img/arrow_first_dis.png" border="0" title="First page" /> <img src="sys/img/arrow_prev_dis.png" width="16" height="16" border="0" title="previous Page" />  
<?php 
} else{ 
?>
 <a href="?fpage=0<?php echo $linkRest; ?>"><img src="sys/img/arrow_first.png" border="0" title="First page" /></a> <a href="?fpage=<?php echo $prevPage; ?><?php echo $linkRest; ?>"><img src="sys/img/arrow_prev.png" width="16" height="16" border="0" title="previous Page" /></a> 
<?php 
}
echo $middleRes; 
if($nextPage == $divide){
?> 
 <img src="sys/img/arrow_next_dis.png" width="16" height="16" border="0" title="Next Page" /> <img src="sys/img/arrow_last_dis.png" width="16" height="16" border="0" title="Last Page" />
<?php 
} else { 
?>
 <a href="?fpage=<?php echo $nextPage; ?><?php echo $linkRest; ?>"><img src="sys/img/arrow_next.png" width="16" height="16" border="0" title="Next Page" /></a> <a href="?fpage=<?php echo $lastPage; ?><?php echo $linkRest; ?>"><img src="sys/img/arrow_last.png" width="16" height="16" border="0" title="Last Page" /></a>
<?php }  ?>
</div>
<?php  
	} 
} 
?>

<p>&nbsp;</p>


<div id="footer">
<span><img src="sys/img/logo22.png" alt="Havalite CMS" width="22" height="22" align="left" longdesc="Havalite CMS" />Thank you for creating with <a href="http://havalite.com">Havalite</a> | <a href="http://havalite.com">Documentation</a></span>
<?php
if($activeHavalite == false) echo '<span id="red" style="font-variant:small-caps;"><img src="sys/img/cmslock.gif" border="0" /> Saving or updating data is disabled!!!</span>';
?>
</div>


</body>
</html>