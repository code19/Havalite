<?php 
include("hava_head.php"); 

// Delete a link --------------------------
if(isset($_GET['del'])){ saveSqlite("DELETE FROM links WHERE id=?", array($_GET['del'])); }

if(isset($_GET['linkId'])) $linkId = $_GET['linkId'];

if(isset($_POST['linkName'], $_POST['linkUrl'])){
	$linkName = htmlspecialchars($_POST['linkName'], ENT_QUOTES);
	$linkUrl = correctUrl($_POST['linkUrl']);
	
	if(isset($_POST['linkId'])) $linkId = $_POST['linkId']; 				else $linkId = 'new';
	if(isset($_POST['linkState'])) $linkState = $_POST['linkState']; 		else $linkState = '0';
	if(isset($_POST['linkCat'])) $linkCat = $_POST['linkCat']; 				else $linkCat = 'Friends';
	if(isset($_POST['linkTarget'])) $linkTarget = $_POST['linkTarget']; 	else $linkTarget = '';
	if(isset($_POST['linkSort'])) $linkSort = $_POST['linkSort']; 			else $linkSort = '';
	if(isset($_POST['linkDescription'])) $linkDesc = htmlspecialchars($_POST['linkDescription'], ENT_QUOTES); 	else $linkDesc = '';
		
	if($linkId != 'new'){ // update link ----------------------------
		
		saveSqlite("UPDATE links SET name=?, url=?, description=?, cat=?, target=?, sort=?, state=? WHERE id=?", array($linkName, $linkUrl, $linkDesc, $linkCat, $linkTarget, $linkSort, $linkState, $linkId));
	}
	else{ //insert new link --------------------
		
		$linkId = saveSqlite("INSERT INTO links (name, url, description, cat, target, sort, state) VALUES (?, ?, ?, ?, ?, ?, ?)", array($linkName, $linkUrl, $linkDesc, $linkCat, $linkTarget, $linkSort, $linkState), 1);
	}
	
}

// for limiting result according to this page 
$myCount = hava_num_rows("SELECT * FROM links");
// deleting a link --------------------------------
$privateLinks = hava_num_rows("SELECT * FROM links WHERE state = 0");
$publicLinks = $myCount - $privateLinks;
?>

<?php
function linkCatArray(){
	$result = hava_all_queries("SELECT DISTINCT cat FROM links ORDER BY cat");
	$res = '';
	foreach($result as $row){
		$r = trim($row['cat']);
		if($r != ''){ $res .= '"'.$row['cat'].'",'; }
	}
	return substr($res, 0, -1);
}
?>
<script language="javascript">
// list of all categories --------------------------------------
var availableTags = [ <?php echo linkCatArray(); ?> ];
$().ready(function() {
	$("#linkCat").autocomplete(availableTags, {
		minChars: 0,
		highlight: false,
		scroll: true,
		scrollHeight: 300
	});
});
</script>
<div id="admin_index">
<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><img src="sys/img/links.png" width="32" height="32" border="0" /></td>
    <td><span id="success"><a href="hava_link.php"><?php echo $myCount; ?> <?php echo $hava_lang['links']; ?></a></span> (<a href="?linkState=1"><?php echo $publicLinks.' '.$hava_lang['public']; ?></a>, <a href="?linkState=0"><?php echo $privateLinks.' '.$hava_lang['private']; ?></a>) <span id="allPostsNav"><a id="submit" href="?linkId=new"><img src="sys/img/link1.png" border="0" /> <?php echo $hava_lang['newLink']; ?></a></span></td>
  </tr>
</table>
</div>
<?php
if(isset($linkId)){

	$myCount = 0; // reset to disable nav arrows
	
	if (preg_match('/^\\d+$/', $linkId)){
		$linkRes = hava_all_queries("SELECT * FROM links WHERE id=? ORDER BY sort", array($linkId));
		foreach($linkRes as $row){
			$linkId = $row['id'];
			$linkName = $row['name'];
			$linkUrl = $row['url'];
			$linkDescription = $row['description'];
			$linkCat = $row['cat'];
			$linkTarget = $row['target'];
			$linkSort = $row['sort'];
			$linkTitle = '<a href="'.$linkUrl.'" title="'.$linkDescription.'" target="'.$linkTarget.'">'.$linkName.'</a>';
			$linkState = $row['state'];
		}		
	}
	else{ $linkTitle = $hava_lang['newLink']; }

?>
<div>
<div id="catTable"><span id="upperBox"><?php if(isset($linkTitle)) echo $linkTitle; ?></span>
	<form id="saveLink" name="saveLink" method="post" action="">
		<table border="0" cellpadding="7">
		<tr><td valign="top" colspan="3"><input type="hidden" name="linkId" value="<?php if(isset($linkId)) echo $linkId; ?>" /></td></tr>
		<tr><td valign="top"><?php echo $hava_lang['name']; ?>: </td><td valign="top"><input name="linkName" type="text" id="linkName" value="<?php if(isset($linkName)) echo $linkName; ?>" /> 
		
</td>
		  <td valign="top" style="direction:<?php echo $hava_lang['direction']; ?>; text-align:left;"><label><input name="linkState" type="radio" value="1" <?php if(isset($linkState) and $linkState==1) echo 'checked="checked"'; ?> /> <?php echo $hava_lang['public']; ?></label>
		<label><input name="linkState" type="radio" value="0" <?php if((isset($linkState) and $linkState==0) || $linkId=='new') echo 'checked="checked"'; ?> /> <?php echo $hava_lang['private']; ?></label></td>
		</tr>
		<tr><td valign="top"><?php echo $hava_lang['url']; ?>: </td><td colspan="2" valign="top"><input name="linkUrl" type="text" id="linkUrl" value="<?php if(isset($linkUrl)) echo $linkUrl; ?>" size="60" /></td></tr>
		<tr><td valign="top"><?php echo $hava_lang['description']; ?>: </td><td colspan="2" valign="top"><textarea name="linkDescription" cols="60" rows="2"><?php if(isset($linkDescription)) echo $linkDescription; ?></textarea></td></tr>
		<tr><td valign="top"><?php echo $hava_lang['category']; ?>: </td><td colspan="2" valign="top"><input name="linkCat" type="text" id="linkCat" value="<?php if(isset($linkCat)) echo $linkCat; ?>" /></td></tr>
		<tr><td valign="top"><?php echo $hava_lang['target']; ?>: </td><td colspan="2" valign="top">
		  <select name="linkTarget">
<?php
$targets = array("", "_blank", "_parent", "_self", "_top");

for($i=0; $i<count($targets); $i++){
	if($linkTarget == $targets[$i]){ echo '<option selected>'.$targets[$i].'</option>'; }
	else{ echo '<option>'.$targets[$i].'</option>'; }
}
?>    
  </select>
</td></tr>
		<tr><td valign="top"><?php echo $hava_lang['sort']; ?>: </td><td colspan="2" valign="top"><input name="linkSort" type="text" id="linkSort" value="<?php if(isset($linkSort)) echo $linkSort; ?>" size="5" /></td></tr>
		<tr>
		  <td valign="top">&nbsp;</td>
		  <td colspan="2" valign="top"><input type="submit" name="Submit" id="submit" value="           <?php echo $hava_lang['save']; ?>           " /></td>
		</tr>
		</table>
	</form>
</div>

<?php
}
else{
?>
<table id="tablesorter" class="tablesorter" border="0" width="100%">
<thead>
<tr>
	<th width="250" valign="top"><?php echo $hava_lang['name']; ?></th>
	<th width="76" valign="top"><?php echo $hava_lang['url']; ?></th>
	<th valign="top"><?php echo $hava_lang['description']; ?></th>
	<th width="76" valign="top"><?php echo $hava_lang['category']; ?></th>
	<th width="35" align="center" valign="top"><?php echo $hava_lang['state']; ?></th>
	<th width="35" align="center" valign="top"><?php echo $hava_lang['delete']; ?></th>
</tr>
</thead>
<tbody>
<?php

$result = hava_all_queries("SELECT * FROM links ORDER BY sort LIMIT ".$fpage.", ".$limit_res);
if(isset($_GET['linkState'])){ 
	$result = hava_all_queries("SELECT * FROM links WHERE state = ? ORDER BY sort LIMIT ".$fpage.", ".$limit_res, array($_GET['linkState']));
}
// Sort all links ---------------------------------------------------
$res = '';
foreach($result as $row){ 
	if($row['state'] ==1){ $stt = $hava_lang['public']; }
	else{ $stt = $hava_lang['private']; }
?>
	<tr>
	<td><a href="?linkId=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></td>
	<td><a href="http://<?php echo cleanUrl($row['url']); ?>" target="<?php echo $row['target']; ?>" title="<?php echo $row['description']; ?>"><?php echo cleanUrl($row['url']); ?></a></td>
	<td><?php echo $row['description']; ?></td>
	<td><?php echo $row['cat']; ?></td>
	<td><?php echo $stt; ?></td>
	<td align="center"><a href="" onclick="zebraConfirm('<?php echo $hava_lang['deleted']; ?><br><br><span style=\'color:red;\'><?php echo $hava_lang['deleted1']; ?></span><br>', '<?php echo $row['name']; ?>', '?del=<?php echo $row['id']; ?>', 'warning', true); return false;"><img src="sys/img/dellink.png" border"0"></a></td>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php
}
?>
</div>
<?php include("hava_foot.php"); ?>