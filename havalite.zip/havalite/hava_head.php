<?php
//header("Cache-Control: no-cache");
require('hava_func.php');

// for limiting result according to this page 
if(isset($_GET['fpage'])) $fpage = $_GET['fpage'];
else $fpage = 0;

/************** Note data *********************/
$noteRes = hava_single_query("SELECT * FROM notes WHERE user= ?", $userName); 
if($noteRes){
	$noteText = $noteRes['note'];
	$noteW = $noteRes['w'];
	$noteH = $noteRes['h'];
}
else{
	$noteText = 'Here comes your note';
	$noteW = 300;
	$noteH = 130;
}

// plugin Menu to uper menu
if(isset($_GET['plugin_on'])){
	$plugin_on = intval($_GET['plugin_on']);
	$pluginOpt = hava_options('plugins');
	saveSqlite("UPDATE options SET val=? WHERE opt =?", array($pluginOpt.$plugin_on.',', 'plugins'));
}
elseif(isset($_GET['plugin_off'])){
	remove_plugin_menu(intval($_GET['plugin_off']));
}
/*************************************************/
$currentPage = '/'.basename($_SERVER["SCRIPT_NAME"]);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo hava_options('title'); ?> - <?php echo $hava_lang['administration']; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0;  user-scalable=0;">
<link rel="SHORTCUT ICON" href="sys/favicon.ico" type="image/x-icon">

<link rel="stylesheet" type="text/css" href="sys/sys.css" />
<link rel="stylesheet" type="text/css" href="sys/jquery/development-bundle/css/smoothness/jquery-ui-1.8.16.custom.css" />	
<link rel="stylesheet" type="text/css" href="sys/jquery/fancybox/fancybox/jquery.fancybox-1.3.4.css" />
<link rel="stylesheet" media="screen" href="sys/jquery/fileupload/jquery.fileupload-ui.css">
<link rel="stylesheet" type="text/css" href="sys/jquery/ddsmoothmenu/ddsmoothmenu.css" />
<link rel="stylesheet" type="text/css" href="sys/jquery/autocomplete/jquery.autocomplete.css" />
<link rel="stylesheet" type="text/css" href="sys/jquery/colorpicker/css/evol.colorpicker.css" />

<script type="text/javascript" src="sys/jquery/js/jquery-1.7.2.min.js" charset="utf-8">/* jQuery */</script>
<script type="text/javascript" src="sys/jquery/js/jquery-ui-1.8.16.custom.min.js" charset="utf-8">/* UI */</script>
<script type="text/javascript" src="sys/jquery/datetime/jquery-ui-timepicker-addon.js">/* Time picker */</script>
<script type="text/javascript" src="sys/jquery/nestedSortable/jquery.ui.nestedSortable.js"></script>
<script type="text/javascript" src="sys/jquery/tablesorter/jquery.tablesorter.min.js"></script>

<script type="text/javascript" src="sys/jquery/zebra_dialog/public/javascript/zebra_dialog.js"></script>
<script type="text/javascript" src="sys/jquery/zebra_dialog/public/javascript/functions.js">/* Zebra_Dialog */</script>
<link rel="stylesheet" type="text/css" href="sys/jquery/zebra_dialog/public/css/zebra_dialog.css">

<script type="text/javascript" src="sys/jquery/autocomplete/jquery.autocomplete.min.js"></script>

<script type="text/javascript" src="sys/editor/ckeditor.js"></script>
<script type="text/javascript" src="sys/jquery/fancybox/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
<script type="text/javascript" src="sys/jquery/fancybox/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript" src="sys/jquery/ddsmoothmenu/ddsmoothmenu.js">/* upper menu */</script>
<script type="text/javascript" src="sys/jquery/stickyNote/jquery.stickyNote.js"></script>
<script type="text/javascript" src="sys/jquery/placeholder/formfiller-1.0.0.js"> /* input placeholder */ </script>
<script type="text/javascript" src="sys/jquery/colorpicker/js/evol.colorpicker.min.js"> /* Color Picker */</script>
<script type="text/javascript" src="sys/jquery/dashboardTS/rangyinputs-jquery-1.1.2.js"> /* dashboard editor tools */</script>

<script type="text/javascript" src="http://havalite.com/version/v.txt">/* Check Version */</script>
<script type="text/javascript">
// latest Version compare-----------------
$(document).ready(function () {
	var myVersion = '<?php echo $version; ?>';
	var upgradeMsg = '<br><?php echo $hava_lang['currentVersion']; ?>: '+ myVersion + '<br>';
	if(havaliteUpgrade != '' && havaliteUpgrade != myVersion){
		upgradeMsg += '<span id="red" style=" text-transform:uppercase;"><?php echo $hava_lang['newUpgrade']; ?></span> <span id="allPostsNav"><a href="http://havalite.com/?p=15"><?php echo $hava_lang['download']; ?>: Havalite ' + havaliteUpgrade + '</a></span> OR: <span id="allPostsNav"><a href="#" onclick=" openSafeFolder(\'updater.php\')">Do Live Update</a></span>';
	}
	$('#upgradeMsg').html(upgradeMsg);

});

// jQuery UI ----------------------------
$(function(){
	// Accordion
	$("#accordion").accordion({ header: "h3", autoHeight: false <?php if(isset($_POST['accordionActive'])) echo ', active:'.$_POST['accordionActive']; ?> });
	// Tabs
	$('#tabs').tabs();
	// Dialog for comments	
	$('#dialog').dialog({
		autoOpen: false,
		width: 600,
		buttons: {
			"<?php echo $hava_lang['save']; ?>": function() { document.forms["commEditor"].submit();  }, 
			"<?php echo $hava_lang['cancel']; ?>": function() { $(this).dialog("close"); } 
		}
	});
	// Dialog for post scripts	
	$('#dialog1').dialog({
		autoOpen: false,
		width: 600,
		buttons: {
			"<?php echo $hava_lang['save']; ?>": function() { $('#postHeader').val($('#postscript').val()); $(this).dialog("close");  }, 
			"<?php echo $hava_lang['cancel']; ?>": function() { $(this).dialog("close"); } 
		}
	});

	// Accordion
	$("#accordion").accordion({ header: "h3" });
	
});

// for comments -----------------------------
function openDialogBox(id, content, commPostId){
	$('#dialog').dialog('open');
	$('#commId').val(id);
	content = content.replace(/<br \/>/g, "\r\n");
	$('#commEdit').val(content);
	<?php if($hava_lang['direction'] == "rtl") echo "$('#commEdit').css('direction', 'rtl');"; ?>
	$('#commPostId').val(commPostId);
	return false;
}

function openSafeFolder(fileName){
if(!fileName) fileName = 'index.php';
$('<div align="center" style="width: 400px; height: 300px"><iframe src="data/' + fileName + '" width="100%" frameborder="0" height="100%"></iframe></div>').dialog({
        width: 600,
        height: 500,
        title: 'Safe Folder'
    })
      .css({padding:0, overflow:'hidden'});
}

// TableSorter ------------------------------------
$(document).ready(function(){
	// fancybox ------------------
	$("a[rel=img_group]").fancybox({		
		'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'titlePosition' 	: 'over',
		'titleFormat'		: function(title, currentArray, currentIndex, currentOpts) {
			return '<span id="fancybox-title-over">Image ' + (currentIndex + 1) + ' / ' + currentArray.length + (title.length ? ' &nbsp; ' + title : '') + '</span>';
		}
	});
	// tablesorter ---------------
	$("#tablesorter").tablesorter({widthFixed: true, widgets: ['zebra']} );
	$("#postTitle, #postCat").formFiller({'attr':'placeholder', 'color':'#ccc'});
	
});

// Dropdown Menu -----------------------------
ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

// CKEditor config -------------------------------------------

function post_notify(note){
	$( "#postTitle" ).animate({
					backgroundColor: "green",
					color: "#fff"
				}, 500 );
	setTimeout(function(){
    $( "#postTitle" ).animate({
					backgroundColor: "#fff",
					color: "#000"
				}, 3000 );
	},4000);
}

// zebra dialog Test -------------
function zebraDialog(textDialog, title, typ, modal, buttons, autoClose){
	$.Zebra_Dialog(textDialog, {
		'title':    title,
		'type':     typ,
		'modal': 	modal,
		'buttons':  buttons,
		'auto_close': autoClose
	});
}
// zebra Confirm Test -------------
function zebraConfirm(textDialog, title, action, typ, modal){
	$.Zebra_Dialog(textDialog, {
		'title':    title,
		'type':     typ,
		'modal': 	modal,
		'buttons':  ['Yes', 'No'],
		'onClose':  function(caption) {
			if(caption == 'Yes')  window.location.href = action;
		}
	});
}

function viewSearchOpt(){
	$("#search_word_opt").fadeIn("slow");
}
</script>

</head>
<style>
.ui-dialog-buttonset, .ui-dialog-buttonpane,  ui-helper-clearfix, .ui-dialog-title-dialog1 {background-color:#F0F0F6; }

#myBox{
	width:<?php echo $noteW; ?>px; height:<?php echo $noteH; ?>px; background-color:#FFF6B7; position:absolute; z-index:100; left:8px; margin-top:0px; font-size:12px; font-family:"Courier New", Courier, monospace; display:none; overflow:hidden; padding:7px;
	-webkit-box-shadow: 12px 12px 9px -7px #999999;	-moz-box-shadow: 12px 12px 9px -7px #999999; box-shadow: 12px 12px 9px -7px #999999;   -webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;
}
/* css for timepicker */
.ui-timepicker-div .ui-widget-header{ margin-bottom: 8px; }
.ui-timepicker-div dl{ text-align: left; }
.ui-timepicker-div dl dt{ height: 25px; }
.ui-timepicker-div dl dd{ margin: -25px 0 10px 65px; }
.ui-timepicker-div td { font-size: 90%; }
input.holder { color: #ccc; }

<?php 
echo hava_options('add_styles'); 
?>

#upperBox, .rssHeader, .ddsmoothmenu, #catTreeTitle, #allPostsNav a, table.tablesorter thead tr .header,
.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default{
background-image: -webkit-linear-gradient(top left, <?php echo $sysColorLite; ?> 15%, <?php echo $sysColor; ?> 80%); 
background-image: -moz-linear-gradient(right bottom, <?php echo $sysColorLite; ?> 15%, #<?php echo $sysColor; ?> 80%); 
background-image: -o-linear-gradient(<?php echo $sysColorLite; ?> 15%, <?php echo $sysColor; ?> 80%); 
background-image: linear-gradient(<?php echo $sysColorLite; ?> 15%, <?php echo $sysColor; ?> 80%);

}
#footer{ background-color:<?php echo $sysColor; ?>; }
.ui-dialog{ box-shadow: 0px 0px 27px 4px rgba(0,0,0,0.75); }

</style>

<body>

<div id="blog_title"><? if(isset($commWait)) echo $commWait; ?> <a href="../index.php"><?php echo hava_options('title'); ?></a></div>

<div id="smoothmenu1" class="ddsmoothmenu">
<ul>
<li class="c_dashboard"><a href="index.php"><span class="icon108"></span><?php echo $hava_lang['dashboard']; ?></a></li>

<?php 
if($userLvl < 5){ // Menu Post and Media only for Level 0 - 4 ***********************************
?>
<li class="c_post"><a href="hava_all_posts.php"><span class="icon55"></span><?php echo $hava_lang['posts']; ?></a>
  <ul>
<?php 
if($userLvl < 3){ // Pages only for Level 0 - 2 ------------------
?>
  <li><a href="hava_all_posts.php?cat=<?php echo $pagesCat; ?>"><span class="icon11"></span><?php echo $hava_lang['pages']; ?> (<?php echo $pagesCat; ?>)</a></li>
  <li>-------------</li>
<?php
} // -------------------------------------------------------
?>
  <li><a href="hava_post.php"><span class="icon68"></span><?php echo $hava_lang['newPost']; ?></a></li>
<?php 
if($userLvl < 3){ // Categories only for Level 0 - 2 ------------------------
?>
<li><a href="hava_cat.php"><span class="icon92"></span><?php echo $hava_lang['categories']; ?></a></li>
<?php
} // -------------------------------------------------------------
?>
<?php 
if($userLvl < 4){ // Comments and Links only for Level 0 - 3 ------------------------
?>
  <li><a href="hava_comm.php"><span class="icon145"></span><?php echo $hava_lang['comments']; ?></a></li>
  <li><a href="hava_link.php"><span class="icon197"></span><?php echo $hava_lang['links']; ?></a></li>
<?php
} // -------------------------------------------------------------
?>
  </ul>
</li>

<li class="c_media"><a href="hava_img.php"><span class="icon90"></span><?php echo $hava_lang['media']; ?></a>
  <ul>

  <li><a href="hava_img_upload.php"><span class="icon189"></span><?php echo $hava_lang['mediaUp']; ?></a></li>
<?php 
if($userLvl < 3){ // Images Categories only for Level 0 - 2 ------------------------
?>
  <li><a href="hava_img_cat.php"><span class="icon148"></span><?php echo $hava_lang['categories']; ?></a></li>
<?php
} // -------------------------------------------------------------
?>
  </ul>
<?php
} // **************************************************************************************
?>

</li>

<?php
if($userLvl < 2){ // Settings and Plugins only for Admins -----------------------------
?>
<li class="c_settings"><a href="hava_settings.php"><span class="icon96"></span><?php echo $hava_lang['settings']; ?></a></li>
<li class="c_plugins"><a href="hava_plugin.php"><span class="icon196"></span><?php echo $hava_lang['plugins']; ?></a>
	<ul>
	<li><a href="hava_widget.php"><span class="icon177"></span><?php echo $hava_lang['widgets']; ?></a></li>
	<?php echo hava_plugins_menu(); ?>
	</ul>
</li>
<?php
} // -------------------------------------------------------------
?>
<li class="c_users"><a href="hava_user.php"><span class="icon97"></span><?php echo $hava_lang['users']; ?></a>
  <ul>
<?php 
if($userLvl < 3){ // New User only for Level 0 - 2 ----------------------------------
?> <li><a href="hava_user.php?userId=new"><span class="icon127"></span><?php echo $hava_lang['newUser']; ?></a></li>
<?php 
} // ------------------------------------------------------------------------------
if($userLvl < 5){ // Profile only for Level 0 - 4 ---------------------------------
?>
  <li><a href="hava_user.php?userId=<?php echo $user_id; ?>"><span class="icon4"></span><?php echo $hava_lang['profile']; ?></a></li>
<?php 
} // ------------------------------------------------------------------------------
?>
  <li><a href="hava_login.php?l=logout&user=<?php echo $userName; ?>"><span class="icon151"></span><?php echo $hava_lang['logout'].' ('.$userName.')'; ?> </a></li>
  </ul>
</li>

<li id="stickyNotis"><img id="stickyNote" src="sys/img/sticky_note.png" border="0"><div id="myBox"><pre id="myBoxInner"><?php echo $noteText; ?></pre></div></li>

</ul>
<br style="clear: left" />
</div>


<div id="search_div">
<form id="search_post" name="search_post" method="post" action="hava_all_posts.php">
      <input type="submit" id="search_submit" value=" " title="Seach" /> 
      <input name="search_word" type="text" id="search_word" style="direction:<?php echo $hava_lang['direction']; ?>;" onfocus="viewSearchOpt();" />
      <div id="search_word_opt">
      <label><input name="search_post_opt" id="search_post_opt" type="radio" value="<?php echo $hava_lang['posts']; ?>" checked="checked" /> <?php echo $hava_lang['posts']; ?></label><br />
      <label><input name="search_post_opt" id="search_post_opt" type="radio" value="<?php echo $hava_lang['postTitle']; ?>" /> <?php echo $hava_lang['postTitle']; ?></label>
      </div>
    </form>
</div>