<?php 
include("hava_head.php");

function spamBot(){
	
	$commBlockCheck = hava_all_queries("SELECT * FROM comments WHERE approved=? AND block IS NULL ORDER BY date", array('0'));
	
	if(count($commBlockCheck)>1){
		$checkDate1 = '';
		$checkIp1 = '';
		
		foreach($commBlockCheck as $cbc){
			$checkDate2 = substr($cbc['date'], 0, -3);
			$checkIp2 = $cbc['ip'];
			
			if(($checkDate1 == $checkDate2) and ($checkIp1 == $checkIp2)){
				removeBlock($checkIp2);
				break;
			}
			$checkDate1 = $checkDate2;
			$checkIp1 = $checkIp2;
		}
	}
}

function removeBlock($ip){
	saveSqlite("DELETE FROM comments WHERE ip=?", array($ip)); 
	saveSqlite("INSERT INTO comments (name, email, comment, post, approved, date, ip, block) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", array('xxx', 'xxx', 'xxx', '0', '0', date('Y-m-d H:i:s'), $ip, '1'));
}



spamBot();



if(isset($_GET['commId'])) $commId 	= $_GET['commId'];
if(isset($_GET['approState'])) $approState = $_GET['approState'];
if(isset($_GET['del'])) $del = $_GET['del'];

if(isset($_POST['commId'])){ 
	$commPostId = $_POST['commPostId'];
	$commEdit = correctLines($_POST['commEdit']); // nl2br ----------
	if($commPostId){ // replay to comment - insert new --------------
		
		saveSqlite("INSERT INTO comments (name, website, email, comment, post, approved, date, ip, replay) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", array($userName, hava_options('url'), $userEmail, $commEdit, $commPostId, 1, date('Y-m-d H:i:s'), $_SERVER['REMOTE_ADDR'], $_POST['commId']));
	}
	else{ // update comment ----------------
		
		saveSqlite("UPDATE comments SET comment = ? WHERE id = ?", array($commEdit, $_POST['commId']));
	}
}

if(isset($commId)){ // approve comment or unapprove ----------------------
	if($approState == 0){ $approState = 1;  }
	else{ $approState = 0; }
	saveSqlite("UPDATE comments SET approved = ? WHERE id=?", array($approState, $commId));
}
elseif(isset($del)){ // delete comment --------------------------------
	saveSqlite("DELETE FROM comments WHERE id=?", array($del)); 
}

$commentCount = hava_num_rows("SELECT * FROM comments");
$myCount = $commentCount;
?>

<form name="commEditor" method="post" action="" id="dialog" title="Edit">
	<textarea name="commEdit" id="commEdit" rows="5" style="width:100%; min-height:90%;"></textarea>
<div style="display:block; width:100px; text-align:left; float:left; ">
        <img src="sys/jquery/dashboardTS/bold.gif" onClick="textareaTools('bold', 'commEdit');" style="cursor:pointer;">
        <img src="sys/jquery/dashboardTS/italic.gif" onClick="textareaTools('italic', 'commEdit');" style="cursor:pointer;">
        <img src="sys/jquery/dashboardTS/link.png" onClick="textareaTools('link', 'commEdit');" style="cursor:pointer;">
        <img src="sys/jquery/dashboardTS/image.png" onClick="textareaTools('image', 'commEdit');" style="cursor:pointer;">
    </div>	<input type="hidden" name="commId" id="commId" />
	<input type="hidden" name="commPostId" id="commPostId" />
</form>
		
<div id="admin_index">
<div id="upper_title">

<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><img src="sys/img/comment.png" width="32" height="32" border="0" /></td>
    <td><span id="success"><?php echo $hava_lang['comments']; ?></span> <?php echo $commentCount; ?></td>
  </tr>
</table>

</div>

<table id="tablesorter" class="tablesorter" border="0" style="<?php if($hava_lang['direction'] == "rtl") echo 'direction:rtl; text-align:right;'; ?>">
<thead>
<tr>
	<th width="300" valign="top"><?php echo $hava_lang['author']; ?></th>
	<th valign="top"><?php echo $hava_lang['comments']; ?></th>
</tr>
</thead>
<tbody>
<?php
$fLimit = 0;
if(isset($fpage)) $fLimit = $fpage*$limit_res;

if(isset($_GET['commIp'])) $commIp = $_GET['commIp'];

if(isset($commIp)) $commRes = hava_all_queries("SELECT * FROM comments WHERE ip= ? AND block IS NULL ORDER BY date DESC LIMIT ".$fLimit.", ".$limit_res, array($commIp));
else $commRes = hava_all_queries("SELECT * FROM comments WHERE block IS NULL ORDER BY date DESC LIMIT ".$fLimit.", ".$limit_res);

foreach($commRes as $row){
	$commWebsite = '';
	if($row['website']) $commWebsite = '<a href="'.correctUrl($row['website']).'" target="_blank">'.correctUrl($row['website']).'</a>';
	
	if($row['approved'] == 0){ $appro = '<span id="red">'.$hava_lang['approve'].'</span>'; }
	else { $appro = $hava_lang['unapprove']; }
?>
<tr>
	<td valign="top"><?php echo hava_gravatar($row['email']); ?><b><?php echo $row['name']; ?></b> <span id="expl">(<?php echo hava_date($row['date']); ?>)</span><br /><?php echo $commWebsite; ?><br /><a href="mailto:<?php echo $row['email']; ?>"><?php echo $row['email']; ?></a><br />
		<a href="?commIp=<?php echo $row['ip']; ?>"><?php echo $row['ip']; ?></a>
		<p id="postName"><a href="../index.php?p=<?php echo $row['post']; ?>#<?php echo $row['id']; ?>" target="_blank"><img src="sys/img/preview.png" border="0" title="<?php echo $hava_lang['preview']; ?>" /></a><a href="hava_post.php?postId=<?php echo $row['post']; ?>"><?php echo hava_post($row['post'], 'title'); ?></a></p>
	</td>
	<td valign="top"><?php echo $row['comment']; ?>
	<div id="commMenu"><a href="?commId=<?php echo $row['id']; ?>&approState=<?php echo $row['approved']; ?>"><?php echo $appro; ?></a> | 
	<a href="#" onclick="openDialogBox('<?php echo $row['id']; ?>', '<?php echo preg_replace('/[\n\r]/', '', $row['comment']); ?>', ''); return false;"><?php echo $hava_lang['edit']; ?></a> | 
	<a href="#" onclick="openDialogBox('<?php echo $row['id']; ?>', '', '<?php echo $row['post']; ?>'); return false;"><?php echo $hava_lang['replay']; ?></a> | 
	<a href="#" onclick="zebraConfirm('<?php echo $hava_lang['deleted']; ?><br><br><span style=\'color:red;\'><?php echo $hava_lang['deleted1']; ?></span><br>', '<?php echo $hava_lang['comment']; ?>', '?del=<?php echo $row['id']; ?>', 'warning', true); return false;"><?php echo $hava_lang['delete']; ?></a></div>
	</td>
</tr>
<?php
}
?>
</tbody>
</table>

</div>





<?php include('hava_foot.php'); ?>

