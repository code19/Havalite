<?php 
include("hava_head.php"); 
$myCount = 0;

if(isset($_GET['catId'])) $catId = $_GET['catId']; else $catId= NULL;
if(isset($_GET['subId'])) $subCat = $_GET['subId'];
if(isset($_GET['del'])) $delCat = $_GET['del'];
$imgFolder = hava_options('imgFolder');
$itemCount = 0;

$catTitle = $hava_lang['newCat'];

if(isset($_POST['catName'])){
	if(isset($_POST['catId'])) $catId = $_POST['catId']; 	//else $catId = NULL;
	if(isset($_POST['catName'])) $catName = $_POST['catName'];	
	if(isset($_POST['catDesc'])) $catDesc = $_POST['catDesc'];
	if(isset($_POST['copyCat'])) $copyCat = $_POST['copyCat']; else $copyCat = NULL;
	//$catSort = $_POST['catSort'];
	//if(isset($_POST['subCat'])) $subCat	 = $_POST['subCat'];
	
	if(empty($catId)){ // Add new Cat -------------
		$catId = saveSqlite("INSERT INTO images_cat (name, desc) VALUES (?, ?)", array($catName, $catDesc), 1);
		
		$makeFolder = '../'.$imgFolder.'/'.$catName;
		if(!is_dir($makeFolder)){
			
			mkdir($makeFolder, 0755);  
		}
	}
	elseif(isset($copyCat) and !empty($copyCat)){ // copy all images to another cat ----------------------------
		saveSqlite("UPDATE images SET cat = ? WHERE cat=?", array($copyCat, $catName), 1); 
	}
	else{ // Change name or description ------------------------------
		$oldCatName = hava_single_query("SELECT * FROM images_cat WHERE id=?", $catId, "name");
		
		if($oldCatName != $catName){ // chamge cat name by posts too ------------------------
			saveSqlite("UPDATE images SET cat=? WHERE cat=?", array($catName, $oldCatName), 1);
			$oldFName = '../'.$imgFolder.'/'.$oldCatName;
			$newFName = '../'.$imgFolder.'/'.$catName;
			rename($oldFName, $newFName);
		}
		saveSqlite("UPDATE images_cat SET name=?, desc=? WHERE id=?", array($catName, $catDesc, $catId)); 
	}
}
elseif(isset($delCat) and $userLvl < 2){

	$imgCatName = hava_single_query("SELECT * FROM images_cat WHERE id = ?", $delCat, 'name');
	
	$delFolder = '../'.$imgFolder.'/'.$imgCatName.'/';	
	if(is_dir($delFolder) and file_exists($delFolder)){ 
		if(rmdir($delFolder)){ }
		else echo "Sorry, i couldn't remove the folder: ".$delFolder; 
		saveSqlite("DELETE FROM images_cat WHERE id = ?", array($delCat));
	}
}


if(isset($catId)){ 
	$itemCount = itemCount($catId);
	$catArray = hava_single_query("SELECT * FROM images_cat WHERE id = ?", $catId);
}

if(isset($subCat)) $subCat =  getCatOptions('id', $subCat);
$copyCat = getCatOptions('name');

function getCatOptions($value, $sel=''){
	$res = '';
	$result = hava_all_queries("SELECT * FROM images_cat ORDER BY sort");
	foreach($result as $ro){
		$selected = '';
		if($sel and $sel == $ro['id']){ $selected = ' selected="selected"'; }
		$res .= '<option value="'.$ro[$value].'" '.$selected.'>'.$ro['name'].'</option>';
	}
	return $res;
}

function itemCount($id){
	$res = 0;
	if(isset($id)){
		$catName = hava_single_query("SELECT * FROM images_cat WHERE id = ?", $id, "name");
		if($catName) $res = hava_num_rows("SELECT * FROM images WHERE cat = ?", array($catName));
	}
	return $res;
}

?>
<script language="javascript">

// check post title and category -----------------------------
function formSubmission(){
	var catName = $('#catName').val();
	catName = jQuery.trim(catName);
	if(catName.match(/[#&"']/)) {
		alert('<?php echo $hava_lang['alphaNummeric']; ?>');
		$("#catName").focus();
		return false;
	}
	else if(catName == ""){
		return false;
	}
}

function clearSerialize(str){
	str = str.replace(/(id\[|\]|root)/g, "");
	str = str.replace(/&/g, ",");
	return str;
}

$(document).ready(function(){
	$('ol.sortable').nestedSortable({
		disableNesting: 'no-nest',
		forcePlaceholderSize: true,
		handle: 'div',
		helper:	'clone',
		items: 'li',
		maxLevels: 3,
		opacity: .6,
		placeholder: 'placeholder',
		revert: 250,
		tabSize: 25,
		tolerance: 'pointer',
		toleranceElement: '> div'
	});
		
	$("ol.sortable").nestedSortable({
       	update: function(event, ui) {
			var order = $(this).nestedSortable("serialize");
			var result = clearSerialize(order);
			$('#imgLoad').attr({ src:"sys/img/ajaxLoad.gif" });
			$.post("hava_ajax_response.php", { imageCatSerial:result });
			setTimeout(function(){ $('#imgLoad').attr({ src:"sys/img/trans.gif" }); }, 3000);
		}
	});

	$('#serialize').click(function(){
		serialized = $('ol.sortable').nestedSortable('serialize');
		//$('#serializeOutput').text(serialized+'\n\n');
		result = clearSerialize(serialized);
		window.location.href = '?catSerial=' + result;
	})

});

</script>

<div id="admin_index">
<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="1"><img src="sys/img/media.png" width="32" height="32" border="0" /></td>
    <td><?php echo $hava_lang['media'].' '.$hava_lang['categories']; ?>  <span id="allPostsNav"><a id="submit" href="hava_img_cat.php"><img src="sys/img/newCat.png" border="0" /> <?php echo $catTitle; ?></a></span></td>
  </tr>
</table>
</div>




<table id="catTable" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="350" valign="top" id="catSplitter">
<div><span id="catTreeTitle"> <?php echo $hava_lang['categories']; ?>  <?php echo $hava_lang['sort']; ?> <img src="sys/img/trans.gif" border="0" id="imgLoad" /></span>

<?php

function catMenuArray(){
	$firstRes = hava_all_queries("SELECT * FROM images_cat ORDER BY sort");
	$menu_array = '';
	foreach($firstRes as $ro){
		$postAmount = hava_num_rows("SELECT * FROM images WHERE cat = ?", array($ro['name']));
		$menu_array[$ro['id']] = array('id' => $ro['id'], 'name' => $ro['name'], 'sub' => $ro['sub'], 'desc' =>$ro['desc'], 'posts' =>$postAmount);
	}
	return $menu_array;
}

$catMenuRes = '';
$menu_array = catMenuArray();

// generate menu in OL Tag ---------------------------------------------------------
function generate_menu($parent){
	$has_childs = false;
	global $menu_array, $catMenuRes, $hava_lang;
	if(!empty($menu_array)){
		foreach($menu_array as $key => $value){
			if ($value['sub'] == $parent) {       
				if ($has_childs === false){
					$has_childs = true;
					$catMenuRes .= '<ol class="sortable">
					';
				}
				if($value['name'] == "") $value['name'] = '&empty;';
				$catMenuRes .= '<li id="id_'.$value['id'].'"><div><a title="'.$value['desc'].'" href="?catId='.$value['id'].'&subId='.$value['sub'].'">'.$value['name'].'</a> <a id="itemsCount" href="hava_img.php?cat='.$value['name'].'">-&gt; '.$value['posts'].' '.$hava_lang['items'].'</a></div>';
				generate_menu($key);
				$catMenuRes .= '</li>
				';
			}
		}
		if ($has_childs === true) $catMenuRes .= '</ol>';
		return $catMenuRes;
	}
	else return "No category defined!";
}


echo generate_menu(0);

if(isset($catArray['sort'])){ $thisCatSort = $catArray['sort']; }
else {
	$thisCatSort = hava_single_query("SELECT * FROM images_cat ORDER BY sort DESC", 'all', 'sort');
	$thisCatSort++;
}
?> 
</div>
<style>
ol.sortable, ol.sortable ol { margin: 0 0 0 25px; padding: 0; list-style-type: none; }
ol.sortable { margin: 0; }
.sortable li { margin: 7px 0 0 0; padding: 0; }
.sortable li div  { 
	border: 1px solid #ccc; padding: 3px 3px 3px 28px; margin: 0; cursor: move; 
	background-image:url(sys/img/dots.png); background-repeat:no-repeat; background-position:1px 1px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px; 
}

</style></td>
<td valign="top">
<form id="catForm" name="catForm" method="post" action="hava_img_cat.php<?php if(isset($catId)) echo '?catId='.$catId; ?>" onsubmit="return formSubmission()">
<div style="border:1px solid #ccc; padding:7px;">
 <table id="catForm" border="0" cellspacing="0" cellpadding="7" >
    <tr>
      <td width="100" valign="top"><?php echo $hava_lang['name']; ?>:</td>
      <td valign="top"><input name="catName" type="text" id="catName" class="middleInput" value="<?php if(isset($catArray['name'])) echo $catArray['name']; ?>" /> <span id="expl"><?php if(isset($catId)) echo $itemCount.' '.$hava_lang['items']; ?></span> <input name="catId" type="hidden" id="catId" value="<?php if(isset($catArray['id'])) echo $catArray['id']; ?>" /></td>
    </tr>
    <tr>
      <td valign="top"><?php echo $hava_lang['description']; ?>:
        <input name="catSort" type="hidden" id="catSort" value="<?php echo $thisCatSort; ?>" /></td>
      <td valign="top"><input name="catDesc" type="text" id="catDesc" class="bigInput" size="70" value="<?php if(isset($catArray['desc'])) echo $catArray['desc']; ?>" /></td>
    </tr>
<?php
if(isset($catId) and $itemCount >0){
?>
    <tr>
      <td valign="top"><?php echo $hava_lang['copyTo']; ?>:</td>
      <td valign="top"><select name="copyCat" id="copyCat">
        <option></option>
        <?php echo $copyCat; ?>
      </select> <span id="expl"><?php echo $hava_lang['copyTo1']; ?></span>      </td>
    </tr>
<?php
}
?>
    <tr>
      <td valign="top">&nbsp;</td>
      <td valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td valign="top">&nbsp;</td>
      <td align="right" valign="top"><?php 

if(isset($catId) and $itemCount <1){ 
?>
		<button id="deleteSubmit" onclick="zebraConfirm('<?php echo $hava_lang['deleted']; ?><br><br><span style=\'color:red;\'><?php echo $hava_lang['deleted1']; ?></span><br>', '<?php echo $catArray['name']; ?>', '?del=<?php echo $catArray['id']; ?>', 'warning', true); return false;"><?php echo $hava_lang['delete']; ?></button>
<?php } ?>
		<input id="saveSubmit" type="submit" name="Submit" value="        <?php echo $hava_lang['save']; ?>         " /></td>
    </tr>
  </table>  
 </div>   
</form></td>
</tr>
</table>
</div>







<?php include('hava_foot.php'); ?>