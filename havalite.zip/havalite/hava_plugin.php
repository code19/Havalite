<?php 
include("hava_head.php"); 
$infoSize = 1000;

column_exists("plugins", "widget", "ALTER TABLE plugins ADD widget INTEGER(1)");

function upperMenuConnect($id){
	$uOpt = hava_options('plugins');
	$upMenu = '<br><a href="?plugin_on='.$id.'"><img src="sys/img/connect.png" border="0" /></a>';
	if(!empty($uOpt)){
		$up = preg_split('/,/', $uOpt);
		if(in_array($id, $up)) 	$upMenu = '<br><a href="?plugin_off='.$id.'"><img src="sys/img/disconnect.png" border="0" /></a>';
	}
	//$upMenu .= ' <a href="?upmenu='.$id.'"><img src="sys/img/disconnect.png" border="0" /></a>';
	return $upMenu;
}

function getPlugins(){
	global $hava_lang, $infoSize;
	$res = "";
	
	if ($handle = opendir('plugins')) {
		
		while (false !== ($file = readdir($handle))) {
			
			if (is_dir('plugins/'.$file.'/') and $file != "." && $file != ".." && $file != "index.php") {
				$pluginFolder = 'plugins/'.$file.'/';
				$state = 0; 
				$stateWord 	= $hava_lang['deactivated'];
				$stateWord 	= '<a href="?activate='.$file.'#'.$file.'" id="red">'.$stateWord.'</a>';
				$pluginId 	= plugin_check($file);
				$transparent = 'transparent';
				//$plugIndex 	= $file;
				$imgView 	= '';
				$upMenu = '';
				
				$pluginImg = $pluginFolder.$file.'.png';
				if(file_exists($pluginImg)){ $imgView = '<img src="'.$pluginImg.'" border="0" style="max-height:50px; max-width:50px;" />'; }
				else{ $imgView = '<img src="sys/img/noimage.gif" border="0" style="max-height:50px; max-width:50px;" />'; }

				if($pluginId){ 
					$state = 1; 
					$stateWord = $hava_lang['activated'];
					$stateWord 	= "<a  onclick=\"zebraConfirm('".$hava_lang['pluginDeact']."', '".$file."', '?del=".$pluginId."', 'warning', true); return false;\" href=\"\" id=\"green\">".$stateWord."</a>";
					
					if(file_exists($pluginFolder.'index.php')){
						$plugIndex = '<a href="?pluginId='.$pluginId.'">'.$imgView.'<br>'.$file.'</a>';
						$upMenu = upperMenuConnect($pluginId);
					}
					else $plugIndex = $imgView.'<br>'.$file;
					
					$transparent = '';
				}
				else{ $plugIndex = $imgView.'<br>'.$file; }
				
				$info = $pluginFolder.'info.txt';
				if(!file_exists($info)){ $info = '<span id="red">'.$hava_lang['noInfoFile'].'</span>'; }
				else{ 
					$info = file_get_contents($info); 
					$info = substr($info, 0, $infoSize);
					if($info == ''){ $info = '<span id="red">'.$hava_lang['noInfoFile'].'</span>'; }
				}
				$res .= '<tr><td valign="top" align="center" width="1"><a name="'.$file.'"></a><h3 id="'.$transparent.'">'.$plugIndex.'</h3></td><td valign="top" align="center">'.$stateWord.'</td><td valign="top">'.$info.'</td><td align="center">'.$upMenu.'</td></tr>';
			}
		}
		closedir($handle);
	}
	return $res;
}

function deletePlugin($del=''){
	$res = false;
	if(!empty($del)){
		$del = intval($del); 
		saveSqlite("UPDATE plugins SET state=0, widget=0 WHERE id = ?", array($del)); 
		$pluginName = hava_single_query("SELECT * FROM plugins WHERE id=?", $del, 'name');
		saveSqlite("UPDATE widgets SET active=0, result='', widget='' WHERE name = ?", array($pluginName)); 
	}
	else{
		$pluginRes = hava_all_queries("SELECT * FROM plugins");
		
		foreach($pluginRes as $r){
			$path = 'plugins/'.$r['name'].'/'.$r['name'].'.php';
			if(!file_exists($path)){
				$res = true;
				saveSqlite("UPDATE plugins SET state=0 WHERE id = ?", array($r['id']));
			}
		}
	}
	return $res;
}

// activate a plugin --------------
if(isset($_GET['activate'])){ 
	$toActivate = $_GET['activate'];
	if(hava_num_rows("SELECT * FROM plugins WHERE name=?", array($toActivate)) > 0){ 
		// update if exists
		saveSqlite("UPDATE plugins SET state=1 WHERE name = ?", array($toActivate));
	}
	else{
		saveSqlite("INSERT INTO plugins (name, state) VALUES (?, ?)", array($toActivate, 1)); 
	}
}
else{ deletePlugin(); }


$myCount = $pluginCount;
if(isset($_GET['pluginId'])) $pluginId = $_GET['pluginId'];
$pluginName = '';

if(isset($pluginId)){
	
	$pluginRes = hava_single_query("SELECT * FROM plugins WHERE id = ?", $pluginId);
	$pluginName = $pluginRes['name'];
	$pluginFolder = 'plugins/'.$pluginName.'/';
}

?>
<script language="javascript">
$(document).ready(function(){
	$('#dialogContent').text('<?php echo $hava_lang['pluginDeact']; ?>');
});
</script>
<div id="admin_index">
<div id="upper_title">
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td width="5" valign="left"><a href="hava_plugin.php"><img src="sys/img/plugins.png" width="32" height="32" border="0" /></a></td>
    <td width="5" valign="left"><a href="hava_plugin.php"><?php echo $hava_lang['plugins']; ?></a></td>
	<td valign="left"><?php 
if(isset($pluginId)){ 
	$pl_image = 'plugins/'.$pluginName.'/'.$pluginName.'.png';
	if(file_exists($pl_image)) $pl_image = '<img src="'.$pl_image.'" border="0" style="width:30px; float: left; margin-left: 12px;"> ';
	else $pl_image = '<img src="sys/img/noimage.gif" border="0" style="width:30px; float: left; margin-left: 12px;"> ';
?>
	<a style="padding-left:6px;" href="?pluginId=<?php echo $pluginId; ?>"><?php echo $pl_image.$pluginName; ?></a>
<?php
}
?> &nbsp;</td>
  </tr>
</table>
</div>
<?php

if(isset($_GET['del']) and deletePlugin($_GET['del'])){
?>
<div class="ui-widget" style="margin-top:12px;">
	<div class="ui-state-error ui-corner-all" style="padding: 0 .7em;"> 
		<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span> 
		<strong>HINT:</strong> Plugin is removed from your database!</p>
	</div>
</div>
<?php
}

if(isset($pluginId)){
	$hava_plugin_data = $pluginRes;
	if(file_exists($pluginFolder.'index.php')){ 
		echo '<div style="margin-top:15px;" id="catTable">';
		include ($pluginFolder.'index.php'); 
		echo '</div>';
	}
}
else{
?>
<table id="tablesorter" class="tablesorter" border="0" width="100%" >
<thead>
<tr>
	<th width="1" valign="top" align="center"><?php echo $hava_lang['plugins']; ?></th>
	<th width="82" valign="top" align="center"><?php echo $hava_lang['state']; ?></th>
	<th valign="top"><?php echo $hava_lang['description']; ?></th>
	<th width="100" align="center">Upper Menu</th>
</tr>
</thead>
<tbody>
<?php     echo getPlugins();      ?>
</tbody>
</table>

<?php     }     ?>
</div>


<?php

include('hava_foot.php'); 
?>