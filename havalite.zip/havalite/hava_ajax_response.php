<?php
require_once('hava_func.php');

$chkUser = hava_num_rows("SELECT * FROM notes WHERE user=?", array($userName));

// note data -------------------------
if(isset($_POST['note'])) $note	= $_POST['note'];
if(isset($_POST['resized'])) $resized = $_POST['resized'];
if(isset($_POST['w'])) $w = $_POST['w'];
if(isset($_POST['h'])) $h = $_POST['h'];

// (Keep yearMonth...) CheckBox in -> hava_img_upload.php -------------------
if(isset($_POST['imgCatName'])) $imgCatName = $_POST['imgCatName'];

/******************* sticky Note *********************/

if(isset($resized, $userName)){ 		// Note resized -----------------

	if($chkUser > 0){ SaveSqlite("UPDATE notes SET w=?, h=? WHERE user=?", array($w, $h, $userName)); }
	else{ SaveSqlite("INSERT INTO notes (user, w, h) VALUES (?, ?, ?)", array($userName, $w, $h)); }
}
elseif(isset($note, $userName)){ // Note changed text -----------------
	
	if($chkUser > 0){ SaveSqlite("UPDATE notes SET note=? WHERE user=?", array($note, $userName)); }
	else{ SaveSqlite("INSERT INTO notes (user, w, h, note) VALUES (?, ?, ?, ?)", array($userName, '300', '150', $note)); }

}
if(isset($_POST['imgCatBrows'])){ 			// view images in img_browser --------------
	$imgCatBrows = $_POST['imgCatBrows'];
	if(isset($_POST['imgSize'])) 	$imgSize = $_POST['imgSize']; 				else $imgSize = 'thumb';
	if(isset($_POST['imgEff'])) 	$imgEff = '&eff='.$_POST['imgEff']; 		else $imgEff = '';
	if(isset($_POST['imgValue'])) 	$imgValue = '&value='.$_POST['imgValue']; 	else $imgValue = '';
	if(isset($_POST['imgAlpha'])) 	$imgAlpha = '&alpha='.$_POST['imgAlpha']; 	else $imgAlpha = '';
	
	$imgRes = hava_all_queries("SELECT * FROM images WHERE cat=? ORDER BY date DESC", array($imgCatBrows));
	foreach($imgRes as $ro){
		if($ro['type'] == 'swf') $src = 'sys/img/swf_small.png'; 
		else  $src = 'img.php?'.$imgSize.'='.$ro['id'].$imgEff.$imgValue.$imgAlpha; 
?>
<label title="<?php echo $ro['desc']; ?>"><a href="#" onclick="OpenFile('<?php echo $ro['id']; ?>', '<?php echo $ro['type']; ?>'); return false;"><span><img src="<?php echo $src; ?>" border="0" /></span><?php echo $ro['name']; ?></a></label>
<?php
	}
}
elseif(isset($_POST['catSerial'])){ 		// Cat Serial in ->hava_cat.php -----------------------
	$catSerial = $_POST['catSerial'];
	$catS = explode(",", $catSerial); 
	for($i=0; $i<count($catS); $i++){
		$cs = explode("=", $catS[$i]);
		//echo $i.'('.$cs[0].':'.$cs[1].') ';

		saveSqlite("UPDATE cat SET sort=?, sub=? WHERE id = ?", array($i, $cs[1], $cs[0]));
		echo 1;
	}
}
elseif(isset($_POST['imageCatSerial'])){ 	// Cat Serial in ->hava_img_cat.php -----------------------
	$imageCatSerial = $_POST['imageCatSerial'];
	$catS = explode(",", $imageCatSerial); 
	for($i=0; $i<count($catS); $i++){
		$cs = explode("=", $catS[$i]);
		//echo $i.'('.$cs[0].':'.$cs[1].') ';

		saveSqlite("UPDATE images_cat SET sort=?, sub=? WHERE id = ?", array($i, $cs[1], $cs[0]));
		echo 1;
	}
}
elseif(isset($imgCatName)){ 	// imgCatName ------------------------
	if(saveSqlite("UPDATE options SET val = ? WHERE opt = 'imgCatName'", array($imgCatName))) return 'ok';
	else echo 'Failed';
}




/******************* widgeta ******************/
if(isset($_GET['columns'])){
	if(saveSqlite("UPDATE options SET val = ? WHERE opt = ?", array($_GET['columns'], 'widgets'))) echo $_GET['columns'];
	else echo 'Failed to save Widget!';
}


if(isset($_POST['w_name'])){
	$w_name = $_POST['w_name'];
	$w_result = $_POST['w_res'];	
	
	if(saveSqlite("UPDATE widgets SET result = ? WHERE name = ?", array($w_result, $w_name))) echo $w_name.'{ '.$hava_lang['isSaved'].' }'; // '.$w_result.'
	else echo $hava_lang['isFailed'];
}


?>