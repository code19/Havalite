<?php 
include("hava_head.php"); 

if(isset($_POST['postId'])) $postIdPost = $_POST['postId'];
if(isset($_GET['postId'])) $postIdGet = $_GET['postId'];

if(isset($postIdGet)){ // Edit Post ---------------------
	$postId = $postIdGet;
	
	if($postRes = hava_all_queries("SELECT * FROM posts WHERE id = ?", array($postId))){
	
		foreach($postRes as $row){ 
			$postTitle 	= $row['title'];
			$postText	= $row['text']; 
			$postCat	= $row['cat']; 
			$postTags	= $row['tags'];
			$postDesc	= $row['desc'];
			$postAuthor	= $row['author'];
			$postComments = $row['comments'];
			$postProp	= $row['prop'];
			$postDate	= $row['date'];
			$postSort	= $row['sort'];
			$postHeader = $row['header'];
			$postImg 	= $row['img'];
			// if draft => make a new date
			if($postProp == 0){ $postDate = date('Y-m-d H:i:s'); }
		}
	}
	else {
		$postTitle 	= '';	
		$postId 	= 'new';
		$postProp 	= 0;
		$postComments = 1;
		$postAuthor = $userName;
		$postDate = date('Y-m-d H:i:s');
	}
	
}
elseif(isset($postIdPost)){ // edit update post -------------------------------
	
	$postTitle 	= trim($_POST['postTitle']);
	$postText	= correctPost($_POST['editor1']);
	$postCat	= trim($_POST['postCat']);
	$postTags	= $_POST['postTags'];
	$postDesc	= $_POST['postDesc'];
	$postAuthor	= $_POST['postAuthor'];
	$postProp	= $_POST['postProp'];
	$postComments = '0';
	if(isset($_POST['postComments'])) $postComments = $_POST['postComments'];
	$postDate	= $_POST['postDate'];
	$postSort	= $_POST['postSort'];
	$postHeader = correctPost($_POST['postHeader']);
	$postImg	= $_POST['postImg'];

	
	// Check if table cat has this category 
	$catTableAmount	= hava_num_rows("SELECT * FROM cat WHERE name = ?", array($postCat));
	
	if($catTableAmount < 1){ // Add new CAT if not exists ----------------------------
		$thisCatSort = hava_single_query("SELECT * FROM cat ORDER BY sort DESC", 'all', 'sort');
		$thisCatSort++;
		saveSqlite("INSERT INTO cat (name, sort) VALUES (?, ?)", array($postCat, $thisCatSort)); 
	}
	
	if($postComments == 'on') $postComments = 1;
	else $postComments = 0;
			
	if($_POST['postId'] == 'new'){ // Add new post ----------------------------------------
		$SQL = "INSERT INTO posts (title, cat, tags, desc, comments, prop, author, text, date, sort, header, img) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$postData = array(str_replace("'", "&acute;", $postTitle), $postCat, $postTags, $postDesc, $postComments, $postProp, $postAuthor, $postText, $postDate, $postSort, $postHeader, $postImg);
		
		if($postId = saveSqlite($SQL, $postData, '1')){ saveSqlite("UPDATE options SET val = ? where opt = ?", array($postId, "latestPost"));  }
		else echo '<p id="red">Sorry, i could not save to database</p>';

?>
<script language="javascript">
$(document).ready(function() {
  post_notify('Insert new post: <b><?php echo $postTitle; ?></b>');
});
</script>
<?php
	}
	else { // Update post ----------------------------------------------
		
		$postId = $_POST['postId'];
		$SQL = "UPDATE posts SET title=?, cat=?, tags=?, desc=?, comments=?, prop=?, author=?, text=?, date=?, sort=?, header=?, img=? WHERE id=?";
		$postData = array(str_replace("'", "&acute;", $postTitle), $postCat, $postTags, $postDesc, $postComments, $postProp, $postAuthor, $postText, $postDate, $postSort, $postHeader, $postImg, $postId);
		
		if(saveSqlite($SQL, $postData)){ saveSqlite("UPDATE options SET val = ? where opt = ?", array($postId, "latestPost")); }
		else echo '<p id="red">Sorry, i could not save to database</p>';
?>
<script language="javascript">
$(document).ready(function() {
  post_notify('Update post: <b><?php echo $postTitle; ?></b>');
  
});
</script>
<?php
	}
}
else{ // New Post ----------------------------
	$postTitle 	= '';
	$postCat	= '';
	$postId 	= 'new';
	$postProp 	= 0;
	$postComments = 1;
	$postAuthor = $userName;
	$postDate = date('Y-m-d H:i:s');
	$postImg 	= '';
}


?>


<script>
$(function() {
	$( "#postDate" ).datetimepicker({ dateFormat: 'yy-mm-dd' }); 
});

var contentChanged = false;
$(window).bind("beforeunload",function(event) {
    if(contentChanged) return "You have unsaved changes";
});

// check post title and category name -----------------------------
function formSubmission(){
	var postTitle 	= $('#postTitle').val();
	var postCat 	= $('#postCat').val();
	var holderTitle = '<?php echo $hava_lang['postTitle']; ?>';
	var holderCat	= '<?php echo $hava_lang['category']; ?>';
	
	postTitle = jQuery.trim(postTitle);
	postCat = jQuery.trim(postCat);
	
	if(postTitle == '' || postTitle == holderTitle){
		zebraDialog('<?php echo $hava_lang['needTitle']; ?>', 'Warning', 'warning');
		$("#postTitle").focus();
		return false;
	}
	else if(postCat.match(/[#&"']/)) {
		zebraDialog('<?php echo $hava_lang['alphaNummeric']; ?>', 'Warning', 'warning');
		$("#postCat").focus();
		return false;
	}
	else if(postCat == '' || postCat == holderCat){
		zebraDialog('<?php echo $hava_lang['needCat']; ?>', 'Warning', 'warning');
		$("#postCat").focus();
		return false;
	}
	else{ 
		contentChanged = false; //allow to leave
		return true; 
	}
	
}

// list of all categories --------------------------------------
var availableTags = [ <?php echo hava_cat_array(); ?> ];
$().ready(function() {
	$("#postCat").autocomplete(availableTags, {
		minChars: 0,
		highlight: false,
		scroll: true,
		scrollHeight: 300
	});
});

// show when edited --------
function saveNotify(){
	$('.cke_button_save span').css({ boxShadow:'0px 0px 3px 0px #ff0000', backgroundImage: 'url(sys/editor/plugins/ajaxsave/ajaxsavered.png)' });
	contentChanged = true;
}

</script>
<script type="text/javascript" >

/********** Save As New Post ***********/
var bindto = '#postTitle';

$(document).ready(function(){
	$(bindto).bind('contextmenu',function(e){
		$('<div class="overlay"></div>').css({left:'0px', top:'0px', position:'absolute', width:'100%', height:'100%', zIndex:'100' }).click(function() {
			$(this).remove();
			$('.vmenu').hide();
		}).bind('contextmenu', function(){return false;}).appendTo(document.body);
		$('.vmenu').css({left: e.pageX, top: e.pageY, zIndex:'101' }).show(); 
		
		return false;    
	});
	
	$('.vmenu .first_li').live('click',function(){
		if( $(this).children().size() == 1 ){
			rightClickCommand($(this).children().text()); 
			$('.vmenu').hide();
		}
	});
	
	$(".first_li span").hover(function(){
		$(this).css({backgroundColor:'#E0EDFE', cursor:'pointer'}); if($(this).children().size() >0) $(this).css({cursor:'default'}); }, 
		function(){ $(this).css('background-color', '#fff');
	});
	
	function rightClickCommand(command){
		if(formSubmission() == true){
			if(command == '<?php echo $hava_lang['save']; ?>'){ $('#saveDataForm').submit(); }
			else if(command == '<?php echo $hava_lang['saveAs']; ?>'){
				$('input[name=postId]').val('new');
				$('#saveDataForm').submit();
			}
		}
	}
	
	postImage();
});

/***********************************************/
</script>

<style type="text/css">
.vmenu{border:1px solid #aaa;position:absolute;background:#fff;	display:none;font-size:0.75em;}
.vmenu .first_li span{width:100px;display:block;padding:5px 10px;cursor:pointer}
</style>


<div class="vmenu">
	   <div class="first_li"><span><?php echo $hava_lang['save']; ?></span></div>
	   <div class="first_li"><span><?php echo $hava_lang['saveAs']; ?></span></div>
</div>

<form action="hava_post.php" method="post" id="saveDataForm" onsubmit="return formSubmission();">
  <input type="hidden" name="postId" id="postId" value="<?php echo $postId; ?>" />
  <table width="100%" border="0" cellspacing="5" cellpadding="0">
    <tr><td><div id="tabs">

			<ul>
				<li><a href="#tabs-1"><?php echo $hava_lang['editPost']; ?></a></li>
				<li><a href="#tabs-2"><?php echo $hava_lang['keywords']; ?></a></li>
				<li><a href="#tabs-3"><?php echo $hava_lang['miscellaneous']; ?></a></li>
			</ul>
			<div id="tabs-1"><table width="100%" border="0" cellspacing="5" cellpadding="0">
			<tr><td width="30%" valign="bottom">
			  <input name="postTitle" type="text" id="postTitle" value="<?php echo htmlspecialchars(str_replace("&acute;", "'", $postTitle)); ?>" onchange="saveNotify();" placeholder="<?php echo $hava_lang['postTitle']; ?>" style="direction:<?php echo $hava_lang['direction']; ?>;" /></td>
      <td width="1%" valign="bottom"> 
        <input name="postCat" type="text" id="postCat" value="<?php echo $postCat; ?>" placeholder="<?php echo $hava_lang['category']; ?>" onchange="saveNotify();" style="direction:<?php echo $hava_lang['direction']; ?>;"></td>
  
	  <!--<td width="1%" valign="bottom"><input type="submit" value="  <?php echo $hava_lang['save']; ?>  " id="saveSubmit" style="background-image:url(sys/img/save1.png); background-repeat:no-repeat; background-position:2px; color:#666666;" title="<?php echo $hava_lang['save']; ?>" /></td> -->
	  
      <td valign="bottom" style="direction:<?php echo $hava_lang['direction']; ?>; text-align:left;"><span id="postProp">
      <label><input onchange="saveNotify();" name="postProp" id="postProp0" type="radio" value="0"<?php if($postProp ==0) echo ' checked'; ?>> <?php echo $hava_lang['draft']; ?> </label>
	  <label><input onchange="saveNotify();" name="postProp" id="postProp1" type="radio" value="1"<?php if($postProp ==1) echo ' checked'; ?>> <?php echo $hava_lang['public']; ?></label>
      <label><input onchange="saveNotify();" name="postComments" type="checkbox" id="postComments" <?php if($postComments ==1) echo ' checked'; ?>> 
      <?php echo $hava_lang['allow']; ?> <?php echo $hava_lang['comments']; ?></label> <!--<a style="padding:0 2px;" id="submit" href="../?p=<?php echo $postId; ?>&preview=<?php echo $userLog; ?>" target="_blank" title="<?php echo $hava_lang['preview']; ?>"><img src="sys/img/preview.png" border="0" /></a>  --></span></td>
    </tr>
			</table>
			</div>
<link href="sys/jquery/tagIt/jquery.tagit.css" rel="stylesheet" type="text/css">
<link href="sys/jquery/tagIt/tagit.ui-zendesk.css" rel="stylesheet" type="text/css">
<script src="sys/jquery/tagIt/tag-it.min.js" type="text/javascript" charset="utf-8"></script>
<script>
<?php
if(hava_options('keywords') != ""){
	
	$optkeywords = preg_split('/[ ]*,[ ]*/', hava_options('keywords'));

	$kwres = 'var sampleTags = [';
	foreach($optkeywords as $optkw){
		if(!empty($optkw)) $kwres .= "'".trim($optkw)."',";
	}
	
	$kwres = substr($kwres, 0, -1);
	echo $kwres.'];';
}
?>

$(function(){
	$('#postTags').tagit();	
});
function allKeywords(){
	for(var i =0; i<sampleTags.length; i++) $('#postTags').tagit('createTag', sampleTags[i]);
}
function allDescription(){
	$('#postDesc').val('<?php if(hava_options('description') != "") echo hava_options('description'); ?>');
}

// show dialogBox for additional scripts
function dialogBoxScripts(){
	$('#dialog1').dialog('open');
	return false;
}

function postImage(){
	$('#postImg').css({'background': 'url(' +$('#postImg').val()+ ') no-repeat top left / 28px 28px '});
}
</script>

			<div id="tabs-2"><table width="100%">
			  <tr>
			  <td width="60"><a href="#" onclick="allKeywords(); return false;"><img src="sys/img/ques.png" width="42" height="42" border="0" title="<?php echo $hava_lang['keywords']; ?>" /></a></td>
			  <td><input name="postTags" cols="70" rows="1" id="postTags" style="width:100%;padding:3px; border:1px solid #ccc; color:#CC6699; direction:<?php echo $hava_lang['direction']; ?>;" title="<?php echo $hava_lang['keywords']; ?>" onchange="saveNotify();" value="<?php if(isset($postTags)) echo $postTags; ?>"  /></td>
			  <td width="60" align="center"><a href="#" onclick="allDescription(); return false;"><img src="sys/img/desc.png" width="42" height="42" border="0" title="<?php echo $hava_lang['description']; ?>" /></a></td>
			  <td><textarea maxlength="<?php echo hava_options('post_desc'); ?>" name="postDesc" title="<?php echo $hava_lang['description']; ?>" cols="70" rows="1" id="postDesc" style="width:100%;padding:3px; border:1px solid #ccc; color:#CC6699; direction:<?php echo $hava_lang['direction']; ?>;" onchange="saveNotify();"><?php if(isset($postDesc)) echo $postDesc; ?></textarea></td>
			  </tr>
			  </table>
		  </div>

		  <div id="tabs-3" style="direction:<?php echo $hava_lang['direction']; ?>;">
          <table width="100%" cellspacing="5">
          <tr><td width="50" valign="top"><img src="sys/img/miscell.png" alt="<?php echo $hava_lang['author']; ?>" width="48" height="48" /></td>
          
<?php if($userLvl < 2){ /* only Admins can change NAME and DATE */ ?> 
			<td width="60" valign="bottom"><?php echo $hava_lang['author']; ?>: <br /><input name="postAuthor" type="text" id="postAuthor" value="<?php echo $postAuthor; ?>" onchange="saveNotify();" class="miscellaneous" size="10" /></td>
			<td width="60" valign="bottom"><?php echo $hava_lang['date']; ?>: <br /><input name="postDate" type="text" id="postDate" value="<?php echo $postDate; ?>" onchange="saveNotify();" class="miscellaneous" /></td>
<?php } else{ ?>
			<td width="60" valign="bottom"><input name="postAuthor" type="hidden" id="postAuthor" value="<?php echo $postAuthor; ?>"><b><?php echo $postAuthor; ?></b></td>
			<td width="60" valign="bottom"><?php echo $hava_lang['date']; ?>: <input name="postDate" type="hidden" id="postDate" value="<?php echo $postDate; ?>" /><b><?php echo $postDate; ?></b></td>
<?php } ?>
			   
			<td width="30" valign="bottom">
			  <?php echo $hava_lang['sort']; ?>: <br />
			  <input name="postSort" type="text" id="postSort" value="<?php if(isset($postSort)) echo $postSort; ?>" size="3" onchange="saveNotify();" class="miscellaneous" /> 
              
<script>
// allow only numeric for sort field
$("input#postSort").keyup(function() {
    var jThis=$(this);
    var notNumber=new RegExp("[^0-9]","g");
    var val=jThis.val();
    if(val.match(notNumber)){ jThis.val(val.replace(notNumber,"")); }
}).keyup();
</script>
              
              
              </td>
              <td width="60" valign="bottom"><?php echo $hava_lang['postImg']; ?>:<br /><input name="postImg" type="text" id="postImg" value="<?php echo $postImg; ?>" onchange="saveNotify();" onblur="postImage();" class="miscellaneous" style="padding-left:30px;" /></td>
              <td valign="bottom">
              <br />
				<button id="submit" type="button" style="height:28px;" onclick="dialogBoxScripts(); return false;"><?php echo $hava_lang['postAdds']; if(!empty($postHeader)) echo ': <b>&radic;</b>'; ?></button> 
                <!-- <textarea name="postHeader" id="postHeader" onchange="saveNotify();" rows="1" class="miscellaneous" style="width:100%;"><?php if(isset($postHeader)) echo $postHeader; ?></textarea> -->
                <input type="hidden" name="postHeader" id="postHeader" onchange="saveNotify();" value="<?php if(isset($postHeader)) echo $postHeader; ?>" />
		  </td>
          </tr>
          </table>
          </div>
</div>

</td>
	<tr><td><textarea class="ckeditor" cols="80" id="editor1" name="editor1" rows="10"><?php if(isset($postText)) echo htmlspecialchars($postText); ?></textarea>
<script type="text/javascript">
//<![CDATA[
// This call can be placed at any point after the
// <textarea>, or inside a <head><script> in a
// window.onload event handler.
// Replace the <textarea id="editor"> with an CKEditor
// instance, using default configurations.
// http://www.mixedwaves.com/2010/02/integrating-fckeditor-filemanager-in-ckeditor/


var previewuser = '<?php echo $userLog; ?>';
var previewid = $('#postId').val();


CKEDITOR.replace( 'editor1', {
	<?php if(hava_options('editorMax') == 'on') echo "on: {'instanceReady': function (evt) { evt.editor.execCommand('maximize'); }},"; ?>
	extraPlugins :'ajaxsave,previewpage,saveas',
	filebrowserBrowseUrl :'hava_img_browser.php',
	uiColor : '<?php echo $sysColor; ?>',
	contentsLangDirection : '<?php echo $hava_lang['direction']; ?>',
	height : '<?php $editorHeight = hava_options('editorHeight'); if($editorHeight < 100){ $editorHeight = 100; } echo $editorHeight; ?>px'<?php 
	$toolbar = trim(hava_options('editorConfig')); 
	if($toolbar) echo ', toolbar:['.recorrectQuotes($toolbar).']';
	?>
	//filebrowserImageBrowseUrl : 'sys/editor/filemanager/browser/default/browser.html?Type=Image&Connector=http://kodemaster.co.cc/filemanager_in_ckeditor/js/ckeditor/filemanager/connectors/php/connector.php',
	//filebrowserFlashBrowseUrl :'sys/editor/filemanager/browser/default/browser.html?Type=Flash&Connector=http://kodemaster.co.cc/filemanager_in_ckeditor/js/ckeditor/filemanager/connectors/php/connector.php',
	//filebrowserUploadUrl  :'http://kodemaster.co.cc/filemanager_in_ckeditor/js/ckeditor/filemanager/connectors/php/upload.php?Type=File',
	//filebrowserImageUploadUrl : 'http://kodemaster.co.cc/filemanager_in_ckeditor/js/ckeditor/filemanager/connectors/php/upload.php?Type=Image',
	//filebrowserFlashUploadUrl : 'http://kodemaster.co.cc/filemanager_in_ckeditor/js/ckeditor/filemanager/connectors/php/upload.php?Type=Flash'
});


CKEDITOR.stylesSet.add( 'default', [
	<?php 
	echo recorrectQuotes(hava_options('editorStyles').', '.hava_plugin_style());

	?>
]);

function beforeUnload(e){
	if(CKEDITOR.instances.editor1.checkDirty() || contentChanged){
		return e.returnValue = "You will lose the changes made in the editor.";
	}
}

if(window.addEventListener) window.addEventListener( 'beforeunload', beforeUnload, false );
else saveNotify(); //window.attachEvent( 'onbeforeunload', beforeUnload );

CKEDITOR.instances['editor1'].on('key', function () {
	saveNotify();
});
//]]>
</script></td></tr>
	</tr>
</table>
</form>
<div id="dialog1" title="<?php echo $hava_lang['postAdds']; ?>">
 <textarea name="postscript" id="postscript" rows="12" style="width:100%; min-height:90%;"><?php if(isset($postHeader)) echo $postHeader; ?></textarea>
</div>

<?php 

include("hava_foot.php"); 
?>
