<?php
require('hava_func.php');

if(isset($_GET['cat'])) $cat = $_GET['cat']; 	else $cat = hava_single_query("SELECT * FROM images ORDER BY date DESC", 'all', 'cat');
if(isset($_GET['CKEditor'])) $CKEditor = $_GET['CKEditor'];
if(isset($_GET['CKEditorFuncNum'])) $CKEditorFuncNum = $_GET['CKEditorFuncNum'];
if(isset($_GET['langCode'])) $langCode = $_GET['langCode'];

?><!--Force IE6 into quirks mode with this comment tag-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Havalite Image Browser</title>

<script type="text/javascript" src="sys/jquery/js/jquery.js"></script>
<script type="text/javascript" src="sys/jquery/js/jquery-ui-1.8.16.custom.min.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.12/themes/start/jquery-ui.css" />
<script type="text/javascript" src="sys/jquery/jquery.cookie.js"></script>
<link href="sys/jquery/dynatree/src/skin/ui.dynatree.css" rel="stylesheet" type="text/css" id="skinSheet">
<script type="text/javascript" src="sys/jquery/dynatree/src/jquery.dynatree.js"></script>

<script type="text/javascript" src="sys/jquery/spinner/ui.spinner.js"></script>

<script language="javascript">

function changeValues(){
	var imgEff = $('#imgEff').val();

	$('#imgValue').spinner('disable');
	$('#imgAlpha').spinner('disable');
	
	if(imgEff.match(/(un)*(sharp)/)){
		$('#imgValue').spinner({ min: 0, max: 10, increment: 'fast' }); $('#imgValue').spinner('enable');
	}
	else if(imgEff == 'gaussian'){
		$('#imgValue').spinner({ min: 0, max: 50 }); $('#imgValue').spinner('enable');
	}
	else if(imgEff.match(/(bright|contrast|blur|smooth|gauss|removal)/)){
		$('#imgValue').spinner({ min: -127, max: 127 }); $('#imgValue').spinner('enable');
	}
	else if(imgEff == 'pixelate'){
		$('#imgValue').spinner({ min: 1, max: 127 }); $('#imgValue').spinner('enable');
	}
	else if(imgEff == 'gray'){
		$('#imgValue').spinner({ min: -127, max: 127 }); $('#imgValue').spinner('enable');
		$('#imgAlpha').spinner({ min: -127, max: 127 }); $('#imgAlpha').spinner('enable');
	}
	else if(imgEff == 'colorize'){
		$('#imgValue').val('ff0000'); 
		$('#imgAlpha').spinner({ min: 0, max: 127 }); $('#imgAlpha').spinner('enable');
	}

/*
        <option value="colorize">colorize</option>
*/
}

jQuery().ready(function($) {
	$('#imgValue').spinner({ min: 0, max: 10 });
	$('#imgAlpha').spinner({ min: 0, max: 10 });
	changeValues();
});

function GetUrlParam( paramName ){
	var oRegex = new RegExp( '[\?&]' + paramName + '=([^&]+)', 'i' ) ;
	var oMatch = oRegex.exec( window.top.location.search ) ;

	if ( oMatch && oMatch.length > 1 )
		return decodeURIComponent( oMatch[1] ) ;
	else
		return '' ;
}

function OpenFile(fileId, fileType){
	var blogUrl		= '<?php echo hava_options('url');?>';
	
	if(fileType == 'swf'){
		var fileUrl = blogUrl + '/havalite/swf.php?id=' + fileId;
	}
	else{
		var imgEff		= $('#imgEff').val();
		var imgValue	= $('#imgValue').val();
		var imgAlpha	= $('#imgAlpha').val();
		
		var fileUrl = blogUrl + '/havalite/img.php?' + getChecked() + '=' + fileId;
		if(imgEff) fileUrl = fileUrl + '&eff=' + imgEff;
		if(imgValue) fileUrl = fileUrl + '&value=' + imgValue;
		if(imgAlpha) fileUrl = fileUrl + '&alpha=' + imgAlpha;
	}
	
	funcNum = GetUrlParam('CKEditorFuncNum') ;	
	
	window.top.opener.CKEDITOR.tools.callFunction( funcNum, fileUrl);
	
	///////////////////////////////////
	window.top.close() ;
	window.top.opener.focus() ;
}

function getChecked(){
	var obj = document.imgForm.imgSize;	
	var res = 'thumb';
	for (i = 0; i <obj.length; i++) {
		if (obj[i].checked) { res = obj[i].value; }
	}
	return res;
}


</script>
<script type="text/javascript">
// TREEEEEE ------------------------------------------
$(function(){
	$("#tree").dynatree({    	
		onActivate: function(node){ 
			getImages(node.data.title);	
			alert(sourceNode.data.id);
		},
		
		dnd: { // Drag and Drop -----------------------------
			onDragStart: function(node) {
				logMsg("tree.onDragStart(%o)", node);
				return true;
			},
			onDragStop: function(node) {
				logMsg("tree.onDragStop(%o)", node);
			},
			autoExpandMS: 1000,
			preventVoidMoves: true,
			onDragEnter: function(node, sourceNode) {
				logMsg("tree.onDragEnter(%o, %o)", node, sourceNode);
			return true;
			},
			onDragOver: function(node, sourceNode, hitMode) {
				logMsg("tree.onDragOver(%o, %o, %o)", node, sourceNode, hitMode);
				if(node.isDescendantOf(sourceNode))
				return false;
			},
			onDrop: function(node, sourceNode, hitMode, ui, draggable) {
				logMsg("tree.onDrop(%o, %o, %s)", node, sourceNode, hitMode);
				sourceNode.move(node, hitMode);  
				
				var lis = '';
				$('#tree li').each(function(index) {
					lis += index + " : " + $(this).text() + "\r\n";
				});
				
				alert(lis + "\r\n" + sourceNode.data.key + ":" + sourceNode.data.title + " - " + node.data.key + ":" + node.data.title);
			},
			onDragLeave: function(node, sourceNode) {
				logMsg("tree.onDragLeave(%o, %o)", node, sourceNode);
			}
		}
	});
	
	  <!-- (Irrelevant source removed.) -->
});

function getImages(folder){
	if(folder=="") folder = $('#folderName').text();
	var imgSize = $('#imgSize:checked').val();
	var imgEff = $('#imgEff').val();
	var imgValue = $('#imgValue').val();
	var imgAlpha = $('#imgAlpha').val();

	$.post("hava_ajax_response.php", { imgCatBrows:folder, imgSize:imgSize, imgEff:imgEff, imgValue:imgValue, imgAlpha:imgAlpha }, function(data) {
		data = data.replace(/&amp;/, "&");

		$('#imagesContainer').html(data);
		$('#folderName').text(folder);
	});
}
</script>

</head>
<style type="text/css">

body{
	margin: 0; padding: 0; border: 0; overflow: hidden; height: 100%;  max-height: 100%;
	font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#333333;
}

#framecontentLeft, #framecontentTop{
	position: absolute; top: 0; left: 0; 
	height: 100%; overflow: hidden; /*Disable scrollbars. Set to "scroll" to enable*/
}

#framecontentLeft{ overflow:auto;}
#framecontentTop{ 
	left: 203px; /*Set left value to WidthOfLeftFrameDiv*/ 
	right: 0; width: auto;
	height: 38px; /*Height of top frame div*/
	overflow: hidden; /*Disable scrollbars. Set to "scroll" to enable*/
	background-image: url(sys/img/backTop.png); background-repeat:repeat-x; 
	border-bottom:3px double #999;
	min-width:500px;
}
#maincontent{ position: fixed; left: 200px; /*Set left value to WidthOfLeftFrameDiv*/	top: 40px; /*Set top value to HeightOfTopFrameDiv*/	right: 0; bottom: 0; overflow: auto; }
.innertube{ margin: 2px 0 0 9px; min-width:500px; /*Margins for inner DIV inside each DIV (to provide padding)*/ }
* html body{ /*IE6 hack*/ padding: 38px 0 0 200px; /*Set value to (HeightOfTopFrameDiv 0 0 WidthOfLeftFrameDiv)*/ }
* html #maincontent{ /*IE6 hack*/ height: 100%;  width: 100%;  }
* html #framecontentTop{ /*IE6 hack*/ width: 100%; margin-left:-3px; }
#leftBorder{ position:absolute; margin:0px; border-right:3px double #999; display:block; width:200px; height:1200px; overflow:hidden; left:0px; top:0px; }
select{ width:80px; color:#3399CC; font-size:12px; }
input{ color:#3399CC; font-size:10px; text-align:center; }
a{text-decoration:none; color:#336699; }
a:hover{ color:#FF9900; }
#imagesContainer label{ display:block; margin:8px; text-align:center; width:210px; height:227px; float:left; }
#imagesContainer span{ 
	display:block; border:1px solid #E8E8E8; padding:6px;  width:198px; height:195px; margin:0 0 2px 0;
	-webkit-border-radius: 7px;
	-moz-border-radius: 7px;
	border-radius: 7px; 
	-webkit-box-shadow: 1px 1px 3px 0px #666;
-moz-box-shadow: 1px 1px 3px 0px #666;
box-shadow: 1px 1px 3px 0px #666; background:url(sys/img/browserBg.png); 
}
#imagesContainer img{ max-height:190px; max-width:190px; }

/******* dynatree ****************************/
.dynatree-has-children span.dynatree-icon{
	background-image: url(sys/img/folder_new.gif);
    background-position: 0 0;
}

.dynatree-ico-cf span.dynatree-icon{ 
	background-image:url(sys/img/folder.gif); 
	background-position:0 0;
}
span.dynatree-active a, span.dynatree-active a:hover{
	font-weight:bold;
	background-color: #ccc !important; /* reddish */
}
</style>

<body>
<div id="leftBorder"></div>
<div id="framecontentLeft">
<div id="tree" class="innertube">
<ul><li id=" " class="expanded folder">D:
<?php

function catMenuArray(){
	$firstRes = hava_all_queries("SELECT * FROM images_cat ORDER BY sort");
	foreach($firstRes as $ro){
		$postAmount = hava_num_rows("SELECT * FROM images WHERE cat = ?", array($ro['name']));
		$menu_array[$ro['id']] = array('id' => $ro['id'], 'name' => $ro['name'], 'sub' => $ro['sub'], 'desc' =>$ro['desc'], 'posts' =>$postAmount);
	}
	return $menu_array;
}

$catMenuRes = '';
$menu_array = catMenuArray();

// generate menu in UL Tag ---------------------------------------------------------
function generate_menu($parent){
	$has_childs = false;
	global $menu_array, $catMenuRes;
	$count= 0;

	foreach($menu_array as $key => $value){
		// expand first folder ----
		if($count == 0) $class = ' class="expanded folder"';
		else $class = ' class="folder"';
		$count++;
		// ------------------------
		if ($value['sub'] == $parent) {       
			if ($has_childs === false){
				$has_childs = true;
				$catMenuRes .= '<ul>
				';
			}
			$catMenuRes .= '<li id="'.$value['id'].'" '.$class.'><a title="'.$value['desc'].'" href="?catId='.$value['id'].'&subId='.$value['sub'].'">'.$value['name'].'</a> <a id="itemsCount" href="hava_all_posts.php?cat='.$value['name'].'">-&gt; '.$value['posts'].'</a>';
			generate_menu($key);
			$catMenuRes .= '</li>
			';
		}
	}
	if ($has_childs === true) $catMenuRes .= '</ul>';
	return $catMenuRes;
}


echo generate_menu(0);

if(isset($catArray['sort'])){ $thisCatSort = $catArray['sort']; }
else {
	$thisCatSort = hava_single_query("SELECT * FROM images_cat ORDER BY sort DESC", 'all', 'sort');
	$thisCatSort++;
}
?> 






</li></ul>

</div>
</div>

<div id="framecontentTop">


<form id="imgForm" name="imgForm" onsubmit="return false;">
<table class="innertube" border="0" cellspacing="5">
      <tr>
	  <td width="180" valign="top">
	  <label><input name="imgSize" type="radio" value="id" id="imgSize" checked="checked" onchange="getImages('');" /> 
      Normal Size</label> <label><input name="imgSize" id="imgSize" type="radio" value="thumb" onchange="getImages('');" /> 
      Thumbnail</label>
	  </td>
	  <td valign="top">

	  <select name="select" id="imgEff" onchange="getImages(''); changeValues();">
        <option value="">Effects</option>
        <option value="sharp">sharp</option>
        <option value="unsharp">unsharp</option>
        <option value="bright">bright</option>
        <option value="contrast">contrast</option>
        <!-- <option value="colorize">colorize</option> -->
        <option value="blur">blur</option>
        <option value="smooth">smooth</option>
        <option value="gauss">gauss</option>
        <option value="gaussian">gaussian</option>
        <option value="gray">gray</option>
        <option value="invert">invert</option>
        <option value="edge">edge</option>
        <option value="emboss">emboss</option>
        <option value="pixelate">pixelate</option>
        <option value="removal">removal</option>
      </select>

	  </td>
	  <td valign="top"><label>value <input name="imgValue" type="text" id="imgValue"  size="5" onchange="getImages('');" /> </label>
	  </td>
	  <td valign="top"><label>Alpha <input name="imgAlpha" type="text" id="imgAlpha" size="5" onchange="getImages('');" /></label>
	  </td>
	  <td valign="top"><span id="folderName"><?php if(isset($cat)) echo $cat; ?></span>	  </td>
	  </tr>
</table>
  </form>


</div>


<div id="maincontent">
<div class="innertube">

<div id="imagesContainer">
<?php

$imgRes = hava_all_queries("SELECT * FROM images WHERE cat=? ORDER BY date DESC", array($cat));
foreach($imgRes as $ro){
	if($ro['type'] == 'swf') $src = 'sys/img/swf_small.png'; 
	else  $src = 'img.php?id='.$ro['id']; 
?>

<label title="<?php echo $ro['desc']; ?>"><a href="#" onclick="OpenFile('<?php echo $ro['id']; ?>', '<?php echo $ro['type']; ?>'); return false;"><span><img src="<?php echo $src; ?>" border="0" /></span><?php echo $ro['name']; ?></a></label>

<?php
}
?></div>

</div>
</div>


</body>
</html>